<?php
declare(strict_types=1);

final class StockMovementLabel
{
    public static function findEntry(PDO $pdo, int $materialId, int $movementId, string $entryNumber = ''): string
    {
        if (!$movementId && $entryNumber === '') {
            return '';
        }

        $stmt = $pdo->prepare('SELECT movement_number FROM erp_stock_movements
            WHERE item_type="raw_material" AND item_id=? AND movement_type="Entrada"
            AND '.($movementId ? 'id=?' : 'movement_number=?'));
        $stmt->execute([$materialId, $movementId ?: $entryNumber]);
        $number = (string) $stmt->fetchColumn();
        if ($movementId && $number === '') {
            http_response_code(404);
            exit('Movimento de entrada não encontrado para esta matéria-prima.');
        }
        return $number;
    }
}
