<?php
declare(strict_types=1);

if (defined('GESTISSER_ERP_MIGRATIONS_LOADED')) {
    return;
}
define('GESTISSER_ERP_MIGRATIONS_LOADED', true);

// Bump this value whenever the phase-one schema below changes.  The marker lets
// normal page requests stay read-only instead of re-running hundreds of
// CREATE/INSERT/UPDATE statements and competing with the backup process.
define('GESTISSER_ERP_SCHEMA_VERSION', '2026110501');

/** PHP 7.0's SQLite driver does not automatically reprepare after schema changes. */
function gt_erp_schema_select(PDO $pdo, string $sql, array $params = []): PDOStatement
{
    for ($attempt = 0; $attempt < 2; $attempt++) {
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $exception) {
            if ($attempt > 0 || (int)($exception->errorInfo[1] ?? 0) !== 17) {
                throw $exception;
            }
        }
    }
    throw new RuntimeException('Não foi possível consultar o esquema SQLite.');
}

function gt_erp_schema_is_current(PDO $pdo): bool
{
    if (!gt_erp_migration_table_exists($pdo, 'gestisser_erp_schema_migrations')) {
        return false;
    }

    $stmt = gt_erp_schema_select($pdo, 'SELECT 1 FROM gestisser_erp_schema_migrations WHERE version=? LIMIT 1', [GESTISSER_ERP_SCHEMA_VERSION]);
    return (bool) $stmt->fetchColumn();
}

function gt_erp_migration_table_exists(PDO $pdo, string $table): bool
{
    $stmt = gt_erp_schema_select($pdo, "SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1", [$table]);
    return (bool) $stmt->fetchColumn();
}

function gt_erp_migration_column_exists(PDO $pdo, string $table, string $column): bool
{
    foreach (gt_erp_schema_select($pdo, 'PRAGMA table_info(' . $table . ')')->fetchAll(PDO::FETCH_ASSOC) as $info) {
        if ((string) $info['name'] === $column) { return true; }
    }
    return false;
}

/**
 * Installs the ink classification independently from the large phase-one migration.
 *
 * config.php may already have marked the phase-one migration as executed before an
 * ERP route is loaded. Keeping this small migration idempotent prevents a rolling
 * deployment from querying a table that has not reached the database yet.
 */
function erp_migrate_ink_types(PDO $pdo)
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS erp_ink_types (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, icon TEXT NOT NULL DEFAULT "bi-droplet-fill", is_active INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
    if (gt_erp_migration_table_exists($pdo, 'erp_raw_materials')) {
        foreach (['is_water_based_ink'=>'INTEGER NOT NULL DEFAULT 0','is_solvent_based_ink'=>'INTEGER NOT NULL DEFAULT 0','ink_type_id'=>'INTEGER REFERENCES erp_ink_types(id) ON DELETE SET NULL'] as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo, 'erp_raw_materials', $column)) $pdo->exec('ALTER TABLE erp_raw_materials ADD COLUMN '.$column.' '.$definition);
        }
    }
    $save=$pdo->prepare('INSERT OR IGNORE INTO erp_ink_types(code,name,icon,is_active) VALUES (?,?,?,1)');
    $save->execute(['AGUA','Tinta de água','bi-droplet-fill']);
    $save->execute(['SOLVENTE','Tinta de solvente','bi-bucket-fill']);
    if (gt_erp_migration_table_exists($pdo, 'erp_raw_materials')) {
        $pdo->exec('UPDATE erp_raw_materials SET ink_type_id=(SELECT id FROM erp_ink_types WHERE code="AGUA") WHERE ink_type_id IS NULL AND is_water_based_ink=1');
        $pdo->exec('UPDATE erp_raw_materials SET ink_type_id=(SELECT id FROM erp_ink_types WHERE code="SOLVENTE") WHERE ink_type_id IS NULL AND is_solvent_based_ink=1');
    }
}

/**
 * Installs the editable production overhead catalogue shown in ERP settings.
 *
 * This is intentionally independent from the large phase-one migration so an
 * existing installation receives the table as soon as the settings page is
 * opened.
 */
function gt_erp_migrate_production_cost_settings(PDO $pdo)
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS erp_production_cost_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cost_key TEXT NOT NULL UNIQUE,
        report_cost_key TEXT,
        label TEXT NOT NULL,
        unit TEXT NOT NULL,
        unit_cost REAL NOT NULL DEFAULT 0 CHECK(unit_cost >= 0),
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_required INTEGER NOT NULL DEFAULT 0,
        updated_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
    )');

    $insert = $pdo->prepare('INSERT OR IGNORE INTO erp_production_cost_settings(cost_key,report_cost_key,label,unit,sort_order,is_required) VALUES (?,?,?,?,?,1)');
    foreach ([
        ['caixa', 'caixas', 'Caixa', '€/un.', 10],
        ['palete', null, 'Palete', '€/un.', 20],
        ['diluente', 'diluente', 'Diluente', '€/L', 30],
        ['mao_obra_maquina', 'impressora', 'Preço mão de obra máquinas', '€/h', 40],
        ['mao_obra_colaborador', 'corte_e_cose', 'Preço mão de obra colaborador', '€/h', 50],
        ['energia_saco', 'energia', 'Custo energético por saco', '€/saco', 60],
    ] as $cost) {
        $insert->execute($cost);
    }
}

function gt_erp_migrate_supplier_columns(PDO $pdo)
{
    $supplierColumns = [
        'address_2'=>'TEXT', 'postal_code'=>'TEXT', 'mobile'=>'TEXT', 'contact_name'=>'TEXT',
        'salesperson'=>'TEXT', 'website'=>'TEXT', 'notes'=>'TEXT', 'discount_percent'=>'REAL NOT NULL DEFAULT 0',
        'credit_limit'=>'REAL NOT NULL DEFAULT 0', 'pefc_certified'=>'INTEGER NOT NULL DEFAULT 0',
        'stock_order_control'=>'INTEGER NOT NULL DEFAULT 0', 'include_osaf'=>'INTEGER NOT NULL DEFAULT 0',
        // SQLite cannot add a non-constant default to a table that already contains rows.
        'created_at'=>'DATETIME', 'updated_at'=>'DATETIME'
    ];
    foreach ($supplierColumns as $column=>$definition) {
        if (!gt_erp_migration_column_exists($pdo, 'erp_suppliers', $column)) {
            $pdo->exec('ALTER TABLE erp_suppliers ADD COLUMN '.$column.' '.$definition);
        }
    }

    $pdo->exec('UPDATE erp_suppliers SET created_at=COALESCE(created_at,CURRENT_TIMESTAMP), updated_at=COALESCE(updated_at,CURRENT_TIMESTAMP)');
    $pdo->exec('CREATE TRIGGER IF NOT EXISTS erp_suppliers_insert_timestamps AFTER INSERT ON erp_suppliers
        WHEN NEW.created_at IS NULL OR NEW.updated_at IS NULL
        BEGIN
            UPDATE erp_suppliers SET created_at=COALESCE(NEW.created_at,CURRENT_TIMESTAMP), updated_at=COALESCE(NEW.updated_at,CURRENT_TIMESTAMP) WHERE id=NEW.id;
        END');
}

function gt_erp_migrate_material_type_columns(PDO $pdo)
{
    if (!gt_erp_migration_column_exists($pdo, 'erp_material_types', 'is_active')) {
        $pdo->exec('ALTER TABLE erp_material_types ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1');
    }
}

function gt_erp_migrate_work_centers(PDO $pdo)
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS erp_printers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, network_uri TEXT NOT NULL UNIQUE, location TEXT, driver_name TEXT, is_active INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
    $columns = [
        'center_type' => 'TEXT NOT NULL DEFAULT "administrative"',
        'machine_id' => 'INTEGER REFERENCES erp_machines(id) ON DELETE RESTRICT',
        'default_printer_id' => 'INTEGER REFERENCES erp_printers(id) ON DELETE SET NULL',
        'daily_capacity_minutes' => 'INTEGER NOT NULL DEFAULT 480',
        'efficiency_percent' => 'REAL NOT NULL DEFAULT 100',
    ];
    foreach ($columns as $column => $definition) {
        if (!gt_erp_migration_column_exists($pdo, 'erp_work_centers', $column)) {
            $pdo->exec('ALTER TABLE erp_work_centers ADD COLUMN ' . $column . ' ' . $definition);
        }
    }
    $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_erp_work_centers_machine ON erp_work_centers(machine_id) WHERE machine_id IS NOT NULL');
    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_work_centers_printer ON erp_work_centers(default_printer_id)');
}

function gt_erp_migrate_document_catalog(PDO $pdo)
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS erp_document_catalog (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, document_number TEXT NOT NULL UNIQUE, name TEXT NOT NULL, module TEXT NOT NULL, output_format TEXT NOT NULL, generation_route TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1, updated_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL)');
    $document = $pdo->prepare('INSERT OR IGNORE INTO erp_document_catalog(code,document_number,name,module,output_format,generation_route) VALUES (?,?,?,?,?,?)');
    foreach ([
        ['technical_sheet','DOC-ERP-001','Ficha técnica do artigo','ERP','PDF / impressão','erp_technical_sheet.php'], ['production_dossier','DOC-PRD-001','Dossier de produção','Produção','PDF','production_dossier.php'], ['production_label','DOC-PRD-002','Etiqueta de produção','Produção','Etiqueta / impressão','production_label.php'], ['inventory_export','DOC-ERP-002','Mapa de inventário','ERP','XLSX','erp.php?action=export_inventory'], ['customer_export','DOC-ERP-003','Listagem de clientes','ERP','XLS','erp_customer_export.php'], ['customer_import_template','DOC-ERP-004','Modelo de importação de clientes','ERP','XLSX','erp_customer_template.php'], ['supplier_import_template','DOC-ERP-005','Modelo de importação de fornecedores','ERP','XLS','erp_supplier_template.php'], ['article_import_template','DOC-ERP-006','Modelo de importação de artigos','ERP','XLSX','erp_article_template.php'], ['raw_material_import_template','DOC-ERP-007','Modelo de importação de matérias-primas','ERP','XLSX','erp_raw_material_template.php'], ['stock_movement_import_template','DOC-ERP-008','Modelo de movimentos de stock','ERP','XLSX','erp_stock_movement_template.php'], ['organization_chart','DOC-RH-001','Organograma','Recursos Humanos','PDF','hr_organogram_pdf.php'], ['job_description','DOC-RH-002','Caderno de função','Recursos Humanos','PDF / impressão','hr_job_descriptions.php?pdf={id}'], ['employee_evaluation','DOC-RH-003','Avaliação do colaborador','Recursos Humanos','PDF','hr_evaluations.php'], ['evaluation_history','DOC-RH-004','Histórico de avaliações','Recursos Humanos','PDF','hr_evaluation_history.php'], ['hr_alert','DOC-RH-005','Alerta de Recursos Humanos','Recursos Humanos','PDF','hr_alert_preview_pdf.php'], ['hr_calendar_template','DOC-RH-006','Modelo de calendário de RH','Recursos Humanos','CSV','hr_calendar.php?action=template'], ['vacation_payroll','DOC-RH-007','Mapa de férias para processamento','Recursos Humanos','CSV','hr_vacations.php'], ['payroll_export','DOC-RH-008','Exportação de payroll','Recursos Humanos','XLSX','payroll.php?action=export'], ['hour_bank_template','DOC-RH-009','Modelo de ajustes do banco de horas','Recursos Humanos','XLS','hr_bank.php'], ['users_template','DOC-ADM-001','Modelo de importação de utilizadores','Administração','XLS','users.php'], ['bi_orders_export','DOC-BI-001','Exportação de ordens do BI','Business Intelligence','CSV','business_intelligence.php?action=export'], ['daily_report','DOC-PRD-003','Relatório diário','Produção','PDF / impressão','daily_report_view.php'], ['company_calendar','DOC-RH-010','Calendário da empresa','Recursos Humanos','ICS','shopfloor_company_calendar.php'], ['absence_reasons_template','DOC-PRD-004','Modelo de motivos de ausência','Produção','XLS','shopfloor_absence_reasons.php'], ['sage_payroll','DOC-RH-011','Ficheiro de payroll Sage','Recursos Humanos','TXT','resultados.php']
    ] as $controlledDocument) { $document->execute($controlledDocument); }
}

function gt_erp_backup_database_once(PDO $pdo)
{
    static $backupPath = null;
    if ($backupPath !== null) {
        return $backupPath;
    }
    $dbPath = __DIR__ . '/database.sqlite';
    if (!is_file($dbPath)) {
        return null;
    }
    $dir = __DIR__ . '/backups';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $backupPath = $dir . '/erp_phase1_' . date('Ymd_His') . '.sqlite';
    @copy($dbPath, $backupPath);
    return $backupPath;
}

function gt_erp_run_phase1_migrations(PDO $pdo)
{
    static $ran = false;
    if ($ran) {
        return;
    }
    if (gt_erp_schema_is_current($pdo)) {
        $ran = true;
        return;
    }

    if (gt_erp_schema_is_current($pdo)) {
        return;
    }

    $needsBackup = !gt_erp_migration_table_exists($pdo, 'erp_stock_movements') || !gt_erp_migration_table_exists($pdo, 'erp_raw_materials');
    if ($needsBackup) {
        gt_erp_backup_database_once($pdo);
    }

    $pdo->beginTransaction();
    try {
        $sql = [
            'CREATE TABLE IF NOT EXISTS erp_permissions (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, label TEXT NOT NULL, description TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)',
            'CREATE TABLE IF NOT EXISTS erp_role_permissions (profile TEXT NOT NULL, permission_code TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(profile, permission_code), FOREIGN KEY(permission_code) REFERENCES erp_permissions(code) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_user_permissions (user_id INTEGER NOT NULL, permission_code TEXT NOT NULL, is_allowed INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id, permission_code), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(permission_code) REFERENCES erp_permissions(code) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER, old_values_json TEXT, new_values_json TEXT, ip_address TEXT, reason TEXT, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_number_sequences (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, prefix TEXT NOT NULL, next_number INTEGER NOT NULL DEFAULT 1, padding INTEGER NOT NULL DEFAULT 5, suffix TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)',
            'CREATE TABLE IF NOT EXISTS erp_settings (key TEXT PRIMARY KEY, value TEXT, updated_by INTEGER, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_material_features (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, description TEXT NOT NULL, material_type_id INTEGER, is_active INTEGER NOT NULL DEFAULT 1, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(material_type_id) REFERENCES erp_material_types(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_inks (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, description TEXT NOT NULL, pantone TEXT, is_water_based INTEGER NOT NULL DEFAULT 0, last_price REAL NOT NULL DEFAULT 0, preferred_supplier_id INTEGER, notes TEXT, is_active INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(preferred_supplier_id) REFERENCES erp_suppliers(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_ink_types (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, icon TEXT NOT NULL DEFAULT "bi-droplet-fill", is_active INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)',
            'CREATE TABLE IF NOT EXISTS erp_location_types (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, description TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1)',
            'CREATE TABLE IF NOT EXISTS erp_locations (id INTEGER PRIMARY KEY AUTOINCREMENT, warehouse_id INTEGER NOT NULL, code TEXT NOT NULL, description TEXT, location_type_id INTEGER, zone TEXT, aisle TEXT, rack TEXT, shelf TEXT, is_active INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(warehouse_id, code), FOREIGN KEY(warehouse_id) REFERENCES erp_warehouses(id) ON DELETE CASCADE, FOREIGN KEY(location_type_id) REFERENCES erp_location_types(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_raw_materials (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, description TEXT NOT NULL, material_type_id INTEGER, material_feature_id INTEGER, width REAL, grammage REAL, thickness REAL, color_id INTEGER, primary_unit_id INTEGER, secondary_unit_id INTEGER, weight_per_unit REAL, length REAL, min_stock REAL NOT NULL DEFAULT 0, max_stock REAL NOT NULL DEFAULT 0, reorder_point REAL NOT NULL DEFAULT 0, lead_time_days INTEGER NOT NULL DEFAULT 0, preferred_supplier_id INTEGER, average_price REAL NOT NULL DEFAULT 0, last_price REAL NOT NULL DEFAULT 0, standard_price REAL NOT NULL DEFAULT 0, preferred_location_id INTEGER, lot_controlled INTEGER NOT NULL DEFAULT 1, roll_controlled INTEGER NOT NULL DEFAULT 1, allow_partial_consumption INTEGER NOT NULL DEFAULT 1, is_water_based_ink INTEGER NOT NULL DEFAULT 0, is_solvent_based_ink INTEGER NOT NULL DEFAULT 0, ink_type_id INTEGER, status TEXT NOT NULL DEFAULT "Ativo", notes TEXT, created_by INTEGER, updated_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(material_type_id) REFERENCES erp_material_types(id) ON DELETE SET NULL, FOREIGN KEY(material_feature_id) REFERENCES erp_material_features(id) ON DELETE SET NULL, FOREIGN KEY(color_id) REFERENCES erp_colors(id) ON DELETE SET NULL, FOREIGN KEY(primary_unit_id) REFERENCES erp_units(id) ON DELETE SET NULL, FOREIGN KEY(secondary_unit_id) REFERENCES erp_units(id) ON DELETE SET NULL, FOREIGN KEY(preferred_supplier_id) REFERENCES erp_suppliers(id) ON DELETE SET NULL, FOREIGN KEY(preferred_location_id) REFERENCES erp_locations(id) ON DELETE SET NULL, FOREIGN KEY(ink_type_id) REFERENCES erp_ink_types(id) ON DELETE SET NULL, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_finished_products (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, customer_product_code TEXT, customer_id INTEGER, product_type_id INTEGER, material_type_id INTEGER, material_feature_id INTEGER, width REAL, length REAL, grammage TEXT, colors_per_face TEXT NOT NULL DEFAULT "0", description TEXT NOT NULL, unit_id INTEGER, min_stock REAL NOT NULL DEFAULT 0, max_stock REAL NOT NULL DEFAULT 0, proof_reference TEXT, artwork_file TEXT, proof_status TEXT DEFAULT "Pendente", printer_roll_measure TEXT, composition TEXT, theoretical_weight REAL, sale_price REAL NOT NULL DEFAULT 0, standard_cost REAL NOT NULL DEFAULT 0, standard_margin REAL NOT NULL DEFAULT 0, has_handle INTEGER NOT NULL DEFAULT 0, has_holes INTEGER NOT NULL DEFAULT 0, has_gusset INTEGER NOT NULL DEFAULT 0, centered_gusset INTEGER NOT NULL DEFAULT 0, gusset_length REAL, anti_slip_ink INTEGER NOT NULL DEFAULT 0, anti_slip_mesh INTEGER NOT NULL DEFAULT 0, thread_color TEXT, perforation_type TEXT, seam_type TEXT, lot_identification_rule TEXT, status TEXT NOT NULL DEFAULT "Ativo", notes TEXT, created_by INTEGER, updated_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(customer_id) REFERENCES erp_customers(id) ON DELETE SET NULL, FOREIGN KEY(product_type_id) REFERENCES erp_product_types(id) ON DELETE SET NULL, FOREIGN KEY(material_type_id) REFERENCES erp_material_types(id) ON DELETE SET NULL, FOREIGN KEY(material_feature_id) REFERENCES erp_material_features(id) ON DELETE SET NULL, FOREIGN KEY(unit_id) REFERENCES erp_units(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_product_colors (id INTEGER PRIMARY KEY AUTOINCREMENT, finished_product_id INTEGER NOT NULL, color_id INTEGER, color_order INTEGER NOT NULL DEFAULT 1, face TEXT, pantone TEXT, ink_type TEXT, planned_quantity REAL, actual_quantity REAL, notes TEXT, FOREIGN KEY(finished_product_id) REFERENCES erp_finished_products(id) ON DELETE CASCADE, FOREIGN KEY(color_id) REFERENCES erp_colors(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_product_features (id INTEGER PRIMARY KEY AUTOINCREMENT, finished_product_id INTEGER NOT NULL, feature_key TEXT NOT NULL, feature_value TEXT, FOREIGN KEY(finished_product_id) REFERENCES erp_finished_products(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_article_materials (id INTEGER PRIMARY KEY AUTOINCREMENT, finished_product_id INTEGER NOT NULL, raw_material_id INTEGER NOT NULL, quantity_per_unit REAL NOT NULL CHECK(quantity_per_unit > 0), waste_percent REAL NOT NULL DEFAULT 0 CHECK(waste_percent >= 0), notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(finished_product_id, raw_material_id), FOREIGN KEY(finished_product_id) REFERENCES erp_finished_products(id) ON DELETE CASCADE, FOREIGN KEY(raw_material_id) REFERENCES erp_raw_materials(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_customer_delivery_addresses (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, label TEXT NOT NULL, address TEXT NOT NULL, postal_code TEXT, city TEXT, country TEXT NOT NULL DEFAULT "Portugal", transporter TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(customer_id) REFERENCES erp_customers(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_stock_alert_log (id INTEGER PRIMARY KEY AUTOINCREMENT, raw_material_id INTEGER NOT NULL, available_qty REAL NOT NULL, threshold_qty REAL NOT NULL, recipient_email TEXT NOT NULL, delivery_status TEXT NOT NULL, error_message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(raw_material_id) REFERENCES erp_raw_materials(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_product_documents (id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, document_type TEXT NOT NULL, title TEXT NOT NULL, file_url TEXT, version TEXT, author_user_id INTEGER, is_required INTEGER NOT NULL DEFAULT 0, valid_until TEXT, status TEXT NOT NULL DEFAULT "Ativo", notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(author_user_id) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_stock_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, movement_number TEXT NOT NULL UNIQUE, movement_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, movement_type TEXT NOT NULL, item_type TEXT NOT NULL CHECK(item_type IN ("raw_material","finished_product")), item_id INTEGER NOT NULL, lot TEXT, roll_id INTEGER, quantity REAL NOT NULL, weight REAL NOT NULL DEFAULT 0, warehouse_from_id INTEGER, location_from_id INTEGER, warehouse_to_id INTEGER, location_to_id INTEGER, unit_cost REAL NOT NULL DEFAULT 0, total_cost REAL NOT NULL DEFAULT 0, source_type TEXT, source_id INTEGER, reversal_of_id INTEGER, reason TEXT, notes TEXT, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY(warehouse_from_id) REFERENCES erp_warehouses(id) ON DELETE SET NULL, FOREIGN KEY(warehouse_to_id) REFERENCES erp_warehouses(id) ON DELETE SET NULL, FOREIGN KEY(location_from_id) REFERENCES erp_locations(id) ON DELETE SET NULL, FOREIGN KEY(location_to_id) REFERENCES erp_locations(id) ON DELETE SET NULL, FOREIGN KEY(reversal_of_id) REFERENCES erp_stock_movements(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_purchase_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, order_number TEXT NOT NULL UNIQUE, supplier_id INTEGER NOT NULL, order_date TEXT NOT NULL, expected_date TEXT, supplier_reference TEXT, status TEXT NOT NULL DEFAULT "Aberta" CHECK(status IN ("Rascunho","Aberta","Parcial","Recebida","Cancelada")), notes TEXT, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(supplier_id) REFERENCES erp_suppliers(id) ON DELETE RESTRICT, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_purchase_order_lines (id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_order_id INTEGER NOT NULL, line_number INTEGER NOT NULL, item_type TEXT NOT NULL, item_id INTEGER NOT NULL, description TEXT, quantity REAL NOT NULL, unit_original TEXT, unit_normalized TEXT, unit_price REAL, line_total REAL, expected_date TEXT, FOREIGN KEY(purchase_order_id) REFERENCES erp_purchase_orders(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_order_imports (id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_order_id INTEGER, original_filename TEXT NOT NULL, stored_filename TEXT NOT NULL, mime_type TEXT NOT NULL, file_size INTEGER NOT NULL, file_hash TEXT NOT NULL UNIQUE, raw_extracted_text TEXT NOT NULL, parsed_data_json TEXT, validated_data_json TEXT, status TEXT NOT NULL DEFAULT "prepared", uploaded_by INTEGER, uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP, validated_by INTEGER, validated_at DATETIME, error_message TEXT, FOREIGN KEY(purchase_order_id) REFERENCES erp_purchase_orders(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_order_import_line_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, import_id INTEGER NOT NULL, line_number INTEGER, field_name TEXT NOT NULL, detected_value TEXT, final_value TEXT, user_id INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(import_id) REFERENCES erp_order_imports(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_supplier_item_mappings (id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER NOT NULL, supplier_reference TEXT NOT NULL, item_type TEXT NOT NULL, item_id INTEGER NOT NULL, confirmed_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(supplier_id,supplier_reference), FOREIGN KEY(supplier_id) REFERENCES erp_suppliers(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_stock_balances (item_type TEXT NOT NULL, item_id INTEGER NOT NULL, warehouse_id INTEGER, location_id INTEGER, lot TEXT, physical_qty REAL NOT NULL DEFAULT 0, reserved_qty REAL NOT NULL DEFAULT 0, blocked_qty REAL NOT NULL DEFAULT 0, ordered_qty REAL NOT NULL DEFAULT 0, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(item_type, item_id, warehouse_id, location_id, lot))'
        ];
        foreach ($sql as $statement) { $pdo->exec($statement); }
        $pdo->exec('CREATE TABLE IF NOT EXISTS erp_purchase_order_emails (id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_order_id INTEGER NOT NULL REFERENCES erp_purchase_orders(id), recipient TEXT NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL, snapshot_json TEXT NOT NULL, pdf_content BLOB NOT NULL, pdf_sha256 TEXT NOT NULL, dispatch_key TEXT NOT NULL UNIQUE, status TEXT NOT NULL, error_message TEXT, created_by INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_purchase_order_emails_order ON erp_purchase_order_emails(purchase_order_id,id)');
        /* The original material type table only contained code and name. Settings now
           allows administrators to deactivate types, including on legacy databases. */
        gt_erp_migrate_material_type_columns($pdo);
        gt_erp_migrate_work_centers($pdo);
        /* Supplier master data used by Purchasing. Keep the original compact table
           compatible while extending it with the fields from the current supplier sheet. */
        gt_erp_migrate_supplier_columns($pdo);
        if (!gt_erp_migration_column_exists($pdo, 'erp_stock_movements', 'order_reference')) {
            $pdo->exec('ALTER TABLE erp_stock_movements ADD COLUMN order_reference TEXT');
        }
        if (!gt_erp_migration_column_exists($pdo, 'erp_stock_movements', 'purchase_order_line_id')) {
            $pdo->exec('ALTER TABLE erp_stock_movements ADD COLUMN purchase_order_line_id INTEGER REFERENCES erp_purchase_order_lines(id)');
        }
        if (!gt_erp_migration_column_exists($pdo, 'erp_stock_movements', 'labels_to_print')) {
            $pdo->exec('ALTER TABLE erp_stock_movements ADD COLUMN labels_to_print INTEGER NOT NULL DEFAULT 0');
        }
        $supplierSeed = [
            ['CIF','CIF - COMPAGNIE INDUSTRIELLE','DOUAR HJAR NHAL','','90.025 WILAYA DE TANGER','MARROCOS','','','','','','','',0,0,0,0,0,''],
            ['DAMAN0201','KANDIL FABRICS PVT LTD','406 - LOTUS HOUSE 4TH FLOOR, 33A NEW MARINE LINE,','','MUMBAI - 400020','INDIA','0091 2266338751','','dpf@damanpolyfabs.com','Niranjan','','','',0,0,0,0,0,''],
            ['FERTIPLAST','FERTIPLAST FERTILIZANTES Y PL','POL. IND. HACIENDA DOLORES C/2 N.º 39B','','41500 SEVILHA','ESPANHA','','034954186024','','','','','B91003228',0,0,0,0,0,''],
            ['HUBER','HUBERGROUP SPAIN, SA','CPTICA 13','','08755 CASTELLBISBAL','ESPANHA','','','','','','','A61285938',0,0,0,0,0,''],
            ['KAO','KAO CHIMIGRAF S.L.U','C/COMPOSITOR CARCASSI, 6 - 8','','08191 RUBI (BARCELONA)','ESPANHA','','','','','','','B66842618',0,0,0,0,0,''],
            ['KAYPEE','KAYPEE POLYFAB PVT, LTD','GUJARAT','','','INDIA','','','','','','','',0,0,0,0,0,''],
            ['LINCON','LINCON POLYMERS PVT LTD','308 SHANTI MALL NEAR SARTHAK SCHOOL','','380061 GHATLODIA, AHMEDABAD','INDIA','','00917927461493','','','','','',0,0,0,0,0,''],
            ['MAURICIO201','MAVURJI ROVENS PVT. LTD','BLOCK NO 1485, MOTI BHOYAN, KALOL - KHATRAJ ROAD','','KALOL, DIST. GANDHINAGAR, GUJ','INDIA','0091 2712797051','','marketing@mavurjacks.com','Somaraj','','','',0,0,0,0,1,''],
            ['MULTISAC001','MULTISAC S.A','LOT 34 ET 36 ZONE INDUSTRIELLE, BOUSKINA','','BENSLIMANE','MARROCOS','','','','','','','03385554',0,0,0,0,1,''],
            ['PLASTENE','PLASTENE INDIA LIMITED','SURVEY NO 1551, AHMEDABAD MEHSANA HIGHWAY','','382715 GUJARAT - INDIA','INDIA','','','','','','','',0,0,0,0,0,''],
            ['REI&REI','REI & REI, LDA','RUA DO COMERCIO ESPINHEIRA','','3060-285 COVOES - CANTANHEDE','PORTUGAL','234756284','935029134 / 935029131','geral@reirei.pt','','','','502897970',0,0,0,0,0,''],
            ['SATYENDRA','SATYENDRA','INDIA','','','INDIA','','','','','','','',0,0,0,0,0,''],
            ['SINTIGRAF','SINTIGRAF','','','','','','','','','','','',0,0,0,0,0,''],
            ['TISSER0001','TISSER UNIPESSOAL LDA','','','','','','','','','','','508757509',0,0,0,0,1,'STOCK EXISTENTE'],
            ['TRADIBAG','TRADIBAG, LTD','28 LOWER MAIN ST ARKLOW','CO.WICKLOW Y14 X8D2','','IRLANDA','','','','','','','3504134KH',0,0,0,0,1,'']
        ];
        $seedSupplier=$pdo->prepare('INSERT OR IGNORE INTO erp_suppliers(code,name,address,address_2,postal_code,country,phone,mobile,email,contact_name,salesperson,website,tax_number,discount_percent,credit_limit,pefc_certified,stock_order_control,include_osaf,notes,is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)');
        foreach($supplierSeed as $supplier){$seedSupplier->execute($supplier);}
        /* Routing is versioned and copied to the OF.  Existing operation/OF tables are
           extended rather than replaced so installations already in production remain valid. */
        $routingSql = [
            'CREATE TABLE IF NOT EXISTS erp_operation_machines (operation_id INTEGER NOT NULL, machine_id INTEGER NOT NULL, is_default INTEGER NOT NULL DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(operation_id,machine_id), FOREIGN KEY(operation_id) REFERENCES erp_operations(id) ON DELETE CASCADE, FOREIGN KEY(machine_id) REFERENCES erp_machines(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_operation_documents (id INTEGER PRIMARY KEY AUTOINCREMENT, operation_id INTEGER NOT NULL, title TEXT NOT NULL, file_url TEXT NOT NULL, mime_type TEXT, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(operation_id) REFERENCES erp_operations(id) ON DELETE CASCADE, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_article_routings (id INTEGER PRIMARY KEY AUTOINCREMENT, finished_product_id INTEGER NOT NULL, name TEXT NOT NULL DEFAULT "Routing principal", created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(finished_product_id) REFERENCES erp_finished_products(id) ON DELETE CASCADE, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_routing_templates (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT, snapshot_json TEXT NOT NULL, source_routing_version_id INTEGER, is_active INTEGER NOT NULL DEFAULT 1, created_by INTEGER, updated_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(source_routing_version_id) REFERENCES erp_article_routing_versions(id) ON DELETE SET NULL, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_article_routing_versions (id INTEGER PRIMARY KEY AUTOINCREMENT, routing_id INTEGER NOT NULL, version_no INTEGER NOT NULL, status TEXT NOT NULL DEFAULT "draft" CHECK(status IN ("draft","active","archived")), effective_from TEXT, notes TEXT, based_on_version_id INTEGER, created_by INTEGER, activated_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, activated_at DATETIME, UNIQUE(routing_id,version_no), FOREIGN KEY(routing_id) REFERENCES erp_article_routings(id) ON DELETE CASCADE, FOREIGN KEY(based_on_version_id) REFERENCES erp_article_routing_versions(id) ON DELETE SET NULL, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY(activated_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_article_routing_steps (id INTEGER PRIMARY KEY AUTOINCREMENT, routing_version_id INTEGER NOT NULL, operation_id INTEGER NOT NULL, operation_no INTEGER NOT NULL, sort_order INTEGER NOT NULL, work_center_id INTEGER, primary_machine_id INTEGER, operators_count INTEGER NOT NULL DEFAULT 1 CHECK(operators_count>0), setup_time REAL NOT NULL DEFAULT 0 CHECK(setup_time>=0), run_value REAL NOT NULL DEFAULT 0 CHECK(run_value>=0), calculation_unit TEXT NOT NULL DEFAULT "minutes_per_unit", base_quantity REAL NOT NULL DEFAULT 1 CHECK(base_quantity>0), waste_percent REAL NOT NULL DEFAULT 0 CHECK(waste_percent>=0), wait_minutes REAL NOT NULL DEFAULT 0 CHECK(wait_minutes>=0), transfer_minutes REAL NOT NULL DEFAULT 0 CHECK(transfer_minutes>=0), parallel_allowed INTEGER NOT NULL DEFAULT 0, specific_instructions TEXT, quality_points TEXT, confirmation_required INTEGER NOT NULL DEFAULT 1, requires_good_quantity INTEGER NOT NULL DEFAULT 1, is_active INTEGER NOT NULL DEFAULT 1, operation_snapshot_json TEXT NOT NULL, UNIQUE(routing_version_id,sort_order), FOREIGN KEY(routing_version_id) REFERENCES erp_article_routing_versions(id) ON DELETE CASCADE, FOREIGN KEY(operation_id) REFERENCES erp_operations(id) ON DELETE RESTRICT, FOREIGN KEY(work_center_id) REFERENCES erp_work_centers(id) ON DELETE SET NULL, FOREIGN KEY(primary_machine_id) REFERENCES erp_machines(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_routing_step_machines (routing_step_id INTEGER NOT NULL, machine_id INTEGER NOT NULL, PRIMARY KEY(routing_step_id,machine_id), FOREIGN KEY(routing_step_id) REFERENCES erp_article_routing_steps(id) ON DELETE CASCADE, FOREIGN KEY(machine_id) REFERENCES erp_machines(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_routing_step_work_centers (routing_step_id INTEGER NOT NULL, work_center_id INTEGER NOT NULL, PRIMARY KEY(routing_step_id,work_center_id), FOREIGN KEY(routing_step_id) REFERENCES erp_article_routing_steps(id) ON DELETE CASCADE, FOREIGN KEY(work_center_id) REFERENCES erp_work_centers(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_routing_step_materials (id INTEGER PRIMARY KEY AUTOINCREMENT, routing_step_id INTEGER NOT NULL, material_id INTEGER NOT NULL, quantity_per_unit REAL NOT NULL CHECK(quantity_per_unit>0), reserve_on_order INTEGER NOT NULL DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(routing_step_id,material_id), FOREIGN KEY(routing_step_id) REFERENCES erp_article_routing_steps(id) ON DELETE CASCADE, FOREIGN KEY(material_id) REFERENCES erp_raw_materials(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_production_order_material_reservations (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL, production_order_operation_id INTEGER NOT NULL, material_id INTEGER NOT NULL, material_category TEXT NOT NULL, required_qty REAL NOT NULL CHECK(required_qty>0), reserved_qty REAL NOT NULL DEFAULT 0 CHECK(reserved_qty>=0), warehouse_id INTEGER NOT NULL DEFAULT 0, location_id INTEGER NOT NULL DEFAULT 0, lot TEXT NOT NULL DEFAULT "", created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(production_order_id,production_order_operation_id,material_id,warehouse_id,location_id,lot), FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(production_order_operation_id) REFERENCES erp_production_order_operations(id) ON DELETE CASCADE, FOREIGN KEY(material_id) REFERENCES erp_raw_materials(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_routing_step_dependencies (routing_step_id INTEGER NOT NULL, predecessor_step_id INTEGER NOT NULL, PRIMARY KEY(routing_step_id,predecessor_step_id), CHECK(routing_step_id<>predecessor_step_id), FOREIGN KEY(routing_step_id) REFERENCES erp_article_routing_steps(id) ON DELETE CASCADE, FOREIGN KEY(predecessor_step_id) REFERENCES erp_article_routing_steps(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_routing_step_documents (id INTEGER PRIMARY KEY AUTOINCREMENT, routing_step_id INTEGER NOT NULL, title TEXT NOT NULL, file_url TEXT NOT NULL, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(routing_step_id) REFERENCES erp_article_routing_steps(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_production_order_routing_snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL UNIQUE, source_routing_version_id INTEGER, version_no INTEGER NOT NULL, effective_from TEXT, snapshot_json TEXT NOT NULL, total_planned_minutes REAL NOT NULL DEFAULT 0, override_reason TEXT, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(source_routing_version_id) REFERENCES erp_article_routing_versions(id) ON DELETE SET NULL, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_operation_execution_operators (time_entry_id INTEGER NOT NULL, user_id INTEGER NOT NULL, PRIMARY KEY(time_entry_id,user_id), FOREIGN KEY(time_entry_id) REFERENCES erp_operation_time_entries(id) ON DELETE CASCADE, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_operation_stoppages (id INTEGER PRIMARY KEY AUTOINCREMENT, time_entry_id INTEGER NOT NULL, reason TEXT NOT NULL, started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ended_at DATETIME, created_by INTEGER, FOREIGN KEY(time_entry_id) REFERENCES erp_operation_time_entries(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_operation_waste (id INTEGER PRIMARY KEY AUTOINCREMENT, time_entry_id INTEGER NOT NULL, quantity REAL NOT NULL CHECK(quantity>=0), reason TEXT NOT NULL, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(time_entry_id) REFERENCES erp_operation_time_entries(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_operation_quality_checks (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_operation_id INTEGER NOT NULL, checkpoint TEXT NOT NULL, result TEXT NOT NULL CHECK(result IN ("pass","fail","na")), notes TEXT, checked_by INTEGER, checked_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_operation_id) REFERENCES erp_production_order_operations(id) ON DELETE CASCADE)',
            'CREATE TABLE IF NOT EXISTS erp_operation_checklist_responses (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_operation_id INTEGER NOT NULL, time_entry_id INTEGER, checklist_template_id INTEGER NOT NULL, user_id INTEGER NOT NULL, phase TEXT NOT NULL CHECK(phase IN ("start","end","first")), response_json TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_operation_id) REFERENCES erp_production_order_operations(id) ON DELETE CASCADE, FOREIGN KEY(time_entry_id) REFERENCES erp_operation_time_entries(id) ON DELETE SET NULL, FOREIGN KEY(checklist_template_id) REFERENCES checklist_templates(id) ON DELETE RESTRICT, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_routing_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, before_json TEXT, after_json TEXT, reason TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)'
        ];
        foreach ($routingSql as $statement) { $pdo->exec($statement); }
        $pdo->exec('CREATE TABLE IF NOT EXISTS erp_operation_types (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL UNIQUE, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
        $operationColumns=['description'=>'TEXT','operation_type'=>'TEXT NOT NULL DEFAULT "production"','default_instructions'=>'TEXT','default_confirmation_required'=>'INTEGER NOT NULL DEFAULT 1','setup_minutes'=>'REAL NOT NULL DEFAULT 0','time_per_unit'=>'REAL NOT NULL DEFAULT 0','time_unit'=>'TEXT NOT NULL DEFAULT "seconds"','production_unit'=>'TEXT NOT NULL DEFAULT "unit"','min_operators'=>'INTEGER NOT NULL DEFAULT 1','requires_good_quantity'=>'INTEGER NOT NULL DEFAULT 1','requires_waste'=>'INTEGER NOT NULL DEFAULT 1','requires_waste_reason'=>'INTEGER NOT NULL DEFAULT 1','requires_quality'=>'INTEGER NOT NULL DEFAULT 0','labour_time_only'=>'INTEGER NOT NULL DEFAULT 0','product_label_enabled'=>'INTEGER NOT NULL DEFAULT 0','checklist_template_id'=>'INTEGER REFERENCES checklist_templates(id) ON DELETE SET NULL','checklist_timing'=>'TEXT','notes'=>'TEXT','created_by'=>'INTEGER REFERENCES users(id) ON DELETE SET NULL','updated_by'=>'INTEGER REFERENCES users(id) ON DELETE SET NULL','created_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP','updated_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP'];
        foreach($operationColumns as $column=>$definition){if(!gt_erp_migration_column_exists($pdo,'erp_operations',$column))$pdo->exec('ALTER TABLE erp_operations ADD COLUMN '.$column.' '.$definition);}
        // Prepare this statement after the ALTER TABLE statements. Older SQLite/PDO
        // combinations do not always recompile a prepared statement after a schema change.
        $insertOperationType=$pdo->prepare('INSERT OR IGNORE INTO erp_operation_types(code,name) VALUES (?,?)');
        foreach([['production','Produção'],['control','Controlo'],['transport','Transporte'],['wait','Espera'],['subcontract','Subcontratação'],['other','Outro']] as $operationType)$insertOperationType->execute($operationType);
        foreach($pdo->query('SELECT DISTINCT operation_type FROM erp_operations WHERE operation_type IS NOT NULL AND trim(operation_type)<>""')->fetchAll(PDO::FETCH_COLUMN) as $operationTypeCode)$insertOperationType->execute([(string)$operationTypeCode,ucfirst((string)$operationTypeCode)]);
        $routingStepHadQuantity=gt_erp_migration_column_exists($pdo,'erp_article_routing_steps','requires_good_quantity');
        $routingStepColumns=['machine_required'=>'INTEGER NOT NULL DEFAULT 1','requires_good_quantity'=>'INTEGER NOT NULL DEFAULT 1'];
        foreach($routingStepColumns as $column=>$definition){if(!gt_erp_migration_column_exists($pdo,'erp_article_routing_steps',$column))$pdo->exec('ALTER TABLE erp_article_routing_steps ADD COLUMN '.$column.' '.$definition);}
        if(!$routingStepHadQuantity)$pdo->exec('UPDATE erp_article_routing_steps SET requires_good_quantity=COALESCE((SELECT requires_good_quantity FROM erp_operations WHERE erp_operations.id=erp_article_routing_steps.operation_id),1)');
        $pdo->exec('INSERT OR IGNORE INTO erp_routing_step_work_centers(routing_step_id,work_center_id) SELECT id,work_center_id FROM erp_article_routing_steps WHERE work_center_id IS NOT NULL');
        $poOperationColumns=['routing_step_id'=>'INTEGER REFERENCES erp_article_routing_steps(id) ON DELETE SET NULL','operation_code'=>'TEXT','operation_name'=>'TEXT','work_center_id'=>'INTEGER REFERENCES erp_work_centers(id) ON DELETE SET NULL','primary_machine_id'=>'INTEGER REFERENCES erp_machines(id) ON DELETE SET NULL','selected_machine_id'=>'INTEGER REFERENCES erp_machines(id) ON DELETE SET NULL','allowed_machine_ids_json'=>'TEXT','allowed_work_center_ids_json'=>'TEXT','machine_required'=>'INTEGER NOT NULL DEFAULT 1','operators_count'=>'INTEGER NOT NULL DEFAULT 1','setup_minutes'=>'REAL NOT NULL DEFAULT 0','run_value'=>'REAL NOT NULL DEFAULT 0','calculation_unit'=>'TEXT','base_quantity'=>'REAL NOT NULL DEFAULT 1','waste_percent'=>'REAL NOT NULL DEFAULT 0','wait_minutes'=>'REAL NOT NULL DEFAULT 0','transfer_minutes'=>'REAL NOT NULL DEFAULT 0','parallel_allowed'=>'INTEGER NOT NULL DEFAULT 0','instructions'=>'TEXT','quality_points'=>'TEXT','confirmation_required'=>'INTEGER NOT NULL DEFAULT 1','requires_good_quantity'=>'INTEGER NOT NULL DEFAULT 1','labour_time_only'=>'INTEGER NOT NULL DEFAULT 0','checklist_template_id'=>'INTEGER REFERENCES checklist_templates(id) ON DELETE SET NULL','checklist_timing'=>'TEXT','snapshot_json'=>'TEXT'];
        foreach($poOperationColumns as $column=>$definition){if(!gt_erp_migration_column_exists($pdo,'erp_production_order_operations',$column))$pdo->exec('ALTER TABLE erp_production_order_operations ADD COLUMN '.$column.' '.$definition);}
        foreach(['selected_machine_id'=>'INTEGER REFERENCES erp_machines(id) ON DELETE SET NULL','status'=>'TEXT NOT NULL DEFAULT "running"','paused_at'=>'DATETIME','pause_seconds'=>'INTEGER NOT NULL DEFAULT 0','corrected_by'=>'INTEGER REFERENCES users(id) ON DELETE SET NULL','corrected_at'=>'DATETIME'] as $column=>$definition){if(!gt_erp_migration_column_exists($pdo,'erp_operation_time_entries',$column))$pdo->exec('ALTER TABLE erp_operation_time_entries ADD COLUMN '.$column.' '.$definition);}
        foreach(['idx_routing_article ON erp_article_routings(finished_product_id)','idx_routing_version_status ON erp_article_routing_versions(routing_id,status,effective_from)','idx_routing_steps_version ON erp_article_routing_steps(routing_version_id,sort_order)','idx_po_operations_order ON erp_production_order_operations(production_order_id,sequence_no)','idx_execution_open ON erp_operation_time_entries(production_order_operation_id,ended_at)'] as $index){$pdo->exec('CREATE INDEX IF NOT EXISTS '.$index);}
        $customerColumns = [
            'country_prefix'=>'TEXT', 'mobile'=>'TEXT', 'address_2'=>'TEXT', 'city'=>'TEXT',
            'postal_code'=>'TEXT', 'fax'=>'TEXT', 'contact_name'=>'TEXT', 'salesperson'=>'TEXT',
            'notes'=>'TEXT', 'balance'=>'REAL NOT NULL DEFAULT 0', 'credit_limit'=>'REAL NOT NULL DEFAULT 0',
            'updated_at'=>'DATETIME DEFAULT CURRENT_TIMESTAMP'
        ];
        foreach ($customerColumns as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo,'erp_customers',$column)) { $pdo->exec('ALTER TABLE erp_customers ADD COLUMN '.$column.' '.$definition); }
        }
        /* Article master data owns every stable value used by a technical sheet. Order-only
           values stay on the OF and the generated snapshot, preserving historical documents. */
        $articleColumns = [
            'material' => 'TEXT', 'bag_color' => 'TEXT', 'width_tolerance' => 'TEXT',
            'length_tolerance' => 'TEXT', 'front_colors' => 'TEXT', 'back_colors' => 'TEXT',
            'of_front_colors' => 'TEXT', 'of_back_colors' => 'TEXT',
            'of_colors_match_technical' => 'INTEGER NOT NULL DEFAULT 0',
            'printer_roll_measure' => 'TEXT',
            'pallet_dimensions' => 'TEXT', 'pallet_lid' => 'TEXT', 'pallet_straps' => 'INTEGER',
            'pallet_film' => 'TEXT', 'pallet_weight' => 'REAL', 'pallet_quantity' => 'REAL',
            'microperforation' => 'INTEGER NOT NULL DEFAULT 0',
            'analysis_grammage' => 'TEXT', 'analysis_total_weight' => 'TEXT',
            'analysis_apparent_width' => 'TEXT', 'analysis_gusset_width' => 'TEXT',
            'analysis_bag_height' => 'TEXT', 'analysis_break_height' => 'TEXT',
            'analysis_break_length' => 'TEXT', 'analysis_seam_strength' => 'TEXT',
            'analysis_static_friction' => 'TEXT', 'analysis_dynamic_friction' => 'TEXT',
            'analysis_air_permeability' => 'TEXT'
        ];
        foreach ($articleColumns as $column => $definition) {
            if (!gt_erp_migration_column_exists($pdo, 'erp_finished_products', $column)) {
                $pdo->exec('ALTER TABLE erp_finished_products ADD COLUMN ' . $column . ' ' . $definition);
            }
        }
        $rawMaterialColumns = [
            'standard_warehouse_id' => 'INTEGER REFERENCES erp_warehouses(id) ON DELETE SET NULL',
            'alert_email' => 'TEXT', 'alert_enabled' => 'INTEGER NOT NULL DEFAULT 1',
            'product_category' => 'TEXT NOT NULL DEFAULT "raw_material"',
            'is_water_based_ink' => 'INTEGER NOT NULL DEFAULT 0',
            'is_solvent_based_ink' => 'INTEGER NOT NULL DEFAULT 0',
            'ink_type_id' => 'INTEGER REFERENCES erp_ink_types(id) ON DELETE SET NULL'
        ];
        foreach ($rawMaterialColumns as $column => $definition) {
            if (!gt_erp_migration_column_exists($pdo, 'erp_raw_materials', $column)) {
                $pdo->exec('ALTER TABLE erp_raw_materials ADD COLUMN ' . $column . ' ' . $definition);
            }
        }
        erp_migrate_ink_types($pdo);
        if (!gt_erp_migration_column_exists($pdo, 'erp_production_orders', 'finished_product_id')) {
            $pdo->exec('ALTER TABLE erp_production_orders ADD COLUMN finished_product_id INTEGER REFERENCES erp_finished_products(id)');
        }
        foreach (['delivery_address_id'=>'INTEGER REFERENCES erp_customer_delivery_addresses(id) ON DELETE SET NULL', 'delivery_address_snapshot'=>'TEXT', 'transporter'=>'TEXT'] as $column => $definition) {
            if (!gt_erp_migration_column_exists($pdo, 'erp_production_orders', $column)) {
                $pdo->exec('ALTER TABLE erp_production_orders ADD COLUMN ' . $column . ' ' . $definition);
            }
        }
        $pdo->exec('CREATE TABLE IF NOT EXISTS erp_technical_sheets (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL UNIQUE, finished_product_id INTEGER NOT NULL, snapshot_json TEXT NOT NULL, created_by INTEGER, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(finished_product_id) REFERENCES erp_finished_products(id), FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)');
        /* Production dossier: master versions are immutable once approved and each OF
           points at the version/snapshot that was valid when it was created. */
        $dossierSql = [
            'CREATE TABLE IF NOT EXISTS erp_article_technical_sheet_versions (id INTEGER PRIMARY KEY AUTOINCREMENT, finished_product_id INTEGER NOT NULL, version_no INTEGER NOT NULL, status TEXT NOT NULL DEFAULT "draft" CHECK(status IN ("draft","approved","obsolete")), effective_from TEXT, snapshot_json TEXT NOT NULL, notes TEXT, created_by INTEGER, approved_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, approved_at DATETIME, UNIQUE(finished_product_id,version_no), FOREIGN KEY(finished_product_id) REFERENCES erp_finished_products(id) ON DELETE CASCADE, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY(approved_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_production_order_snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL UNIQUE, technical_sheet_version_id INTEGER, snapshot_json TEXT NOT NULL, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(technical_sheet_version_id) REFERENCES erp_article_technical_sheet_versions(id) ON DELETE RESTRICT, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_production_cost_rates (id INTEGER PRIMARY KEY AUTOINCREMENT, cost_type TEXT NOT NULL, reference_type TEXT, reference_id INTEGER, description TEXT NOT NULL, hourly_rate REAL NOT NULL DEFAULT 0, unit_rate REAL NOT NULL DEFAULT 0, energy_kwh REAL NOT NULL DEFAULT 0, valid_from TEXT NOT NULL, valid_until TEXT, is_active INTEGER NOT NULL DEFAULT 1, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, CHECK(hourly_rate>=0 AND unit_rate>=0 AND energy_kwh>=0), FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_production_order_costs (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL, production_order_operation_id INTEGER, category TEXT NOT NULL, description TEXT NOT NULL, planned_amount REAL NOT NULL DEFAULT 0, actual_amount REAL NOT NULL DEFAULT 0, source_type TEXT, source_id INTEGER, calculated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(production_order_id,category,description,source_type,source_id), FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(production_order_operation_id) REFERENCES erp_production_order_operations(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_production_order_closures (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL UNIQUE, metrics_json TEXT NOT NULL, total_planned_cost REAL NOT NULL DEFAULT 0, total_actual_cost REAL NOT NULL DEFAULT 0, override_reason TEXT, closed_by INTEGER NOT NULL, closed_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE RESTRICT, FOREIGN KEY(closed_by) REFERENCES users(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_production_order_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL, user_id INTEGER, action TEXT NOT NULL, old_value_json TEXT, new_value_json TEXT, reason TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)',
            'CREATE TABLE IF NOT EXISTS erp_production_order_close_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL UNIQUE, report_json TEXT NOT NULL, updated_by INTEGER NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_production_labels (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL, label_type TEXT NOT NULL CHECK(label_type IN ("roll","ink")), reference_key TEXT NOT NULL, values_json TEXT NOT NULL, validated_by INTEGER NOT NULL, validated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(production_order_id,label_type,reference_key), FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(validated_by) REFERENCES users(id) ON DELETE RESTRICT)',
            'CREATE TABLE IF NOT EXISTS erp_production_label_history (id INTEGER PRIMARY KEY AUTOINCREMENT, production_label_id INTEGER NOT NULL, values_json TEXT NOT NULL, validated_by INTEGER NOT NULL, validated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_label_id) REFERENCES erp_production_labels(id) ON DELETE CASCADE, FOREIGN KEY(validated_by) REFERENCES users(id) ON DELETE RESTRICT)'
        ];
        foreach ($dossierSql as $statement) { $pdo->exec($statement); }
        /* Roll labels identify received raw material. They deliberately have no
           production-order or finished-product foreign key. */
        $pdo->exec('CREATE TABLE IF NOT EXISTS erp_raw_material_roll_labels (id INTEGER PRIMARY KEY AUTOINCREMENT, raw_material_id INTEGER NOT NULL, entry_number TEXT NOT NULL, supplier_lot TEXT NOT NULL, metres REAL NOT NULL, weight_kg REAL NOT NULL, barcode TEXT NOT NULL UNIQUE, label_date TEXT NOT NULL, validated_by INTEGER NOT NULL, validated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(raw_material_id) REFERENCES erp_raw_materials(id) ON DELETE RESTRICT, FOREIGN KEY(validated_by) REFERENCES users(id) ON DELETE RESTRICT)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_raw_material_roll_labels_material ON erp_raw_material_roll_labels(raw_material_id,label_date,entry_number)');
        $pdo->exec('CREATE TABLE IF NOT EXISTS erp_raw_material_roll_consumptions (id INTEGER PRIMARY KEY AUTOINCREMENT, source_label_id INTEGER NOT NULL, resulting_label_id INTEGER NOT NULL, production_order_id INTEGER NOT NULL, consumed_metres REAL NOT NULL DEFAULT 0, consumed_weight_kg REAL NOT NULL DEFAULT 0, created_by INTEGER NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(source_label_id) REFERENCES erp_raw_material_roll_labels(id) ON DELETE RESTRICT, FOREIGN KEY(resulting_label_id) REFERENCES erp_raw_material_roll_labels(id) ON DELETE RESTRICT, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE RESTRICT, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_raw_material_roll_consumptions_source ON erp_raw_material_roll_consumptions(source_label_id,created_at)');
        $pdo->exec('CREATE TABLE IF NOT EXISTS erp_raw_material_ink_labels (id INTEGER PRIMARY KEY AUTOINCREMENT, raw_material_id INTEGER NOT NULL, entry_number TEXT NOT NULL, supplier_lot TEXT NOT NULL, weight_kg REAL NOT NULL, barcode TEXT NOT NULL UNIQUE, label_date TEXT NOT NULL, validated_by INTEGER NOT NULL, validated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(raw_material_id) REFERENCES erp_raw_materials(id) ON DELETE RESTRICT, FOREIGN KEY(validated_by) REFERENCES users(id) ON DELETE RESTRICT)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_raw_material_ink_labels_material ON erp_raw_material_ink_labels(raw_material_id,label_date,entry_number)');
        /* A label is the existing physical stock-unit identity.  Keep its barcode
           stable and add lifecycle fields instead of introducing a parallel unit table. */
        foreach (['initial_metres'=>'REAL','initial_weight_kg'=>'REAL','status'=>'TEXT NOT NULL DEFAULT "AVAILABLE"','warehouse_id'=>'INTEGER REFERENCES erp_warehouses(id) ON DELETE SET NULL','location_id'=>'INTEGER REFERENCES erp_locations(id) ON DELETE SET NULL'] as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo,'erp_raw_material_roll_labels',$column)) $pdo->exec('ALTER TABLE erp_raw_material_roll_labels ADD COLUMN '.$column.' '.$definition);
        }
        foreach (['initial_weight_kg'=>'REAL','status'=>'TEXT NOT NULL DEFAULT "AVAILABLE"','warehouse_id'=>'INTEGER REFERENCES erp_warehouses(id) ON DELETE SET NULL','location_id'=>'INTEGER REFERENCES erp_locations(id) ON DELETE SET NULL'] as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo,'erp_raw_material_ink_labels',$column)) $pdo->exec('ALTER TABLE erp_raw_material_ink_labels ADD COLUMN '.$column.' '.$definition);
        }
        $pdo->exec('UPDATE erp_raw_material_roll_labels SET initial_metres=metres WHERE initial_metres IS NULL');
        $pdo->exec('UPDATE erp_raw_material_roll_labels SET initial_weight_kg=weight_kg WHERE initial_weight_kg IS NULL');
        $pdo->exec('UPDATE erp_raw_material_ink_labels SET initial_weight_kg=weight_kg WHERE initial_weight_kg IS NULL');
        foreach (['validated_at'=>'DATETIME','updated_at'=>'DATETIME'] as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo,'erp_production_labels',$column)) $pdo->exec('ALTER TABLE erp_production_labels ADD COLUMN '.$column.' '.$definition);
        }
        if (!gt_erp_migration_column_exists($pdo,'erp_production_label_history','validated_at')) $pdo->exec('ALTER TABLE erp_production_label_history ADD COLUMN validated_at DATETIME');
        foreach (['technical_sheet_version_id'=>'INTEGER REFERENCES erp_article_technical_sheet_versions(id) ON DELETE RESTRICT','snapshot_id'=>'INTEGER REFERENCES erp_production_order_snapshots(id) ON DELETE RESTRICT','public_token'=>'TEXT','planned_production_date'=>'TEXT','customer_order_reference'=>'TEXT'] as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo,'erp_production_orders',$column)) $pdo->exec('ALTER TABLE erp_production_orders ADD COLUMN '.$column.' '.$definition);
        }
        if (!gt_erp_migration_column_exists($pdo, 'erp_production_orders', 'planning_priority')) {
            $pdo->exec('ALTER TABLE erp_production_orders ADD COLUMN planning_priority INTEGER');
            $pdo->exec('UPDATE erp_production_orders SET planning_priority=id WHERE planning_priority IS NULL');
        }
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_production_planning_priority ON erp_production_orders(planning_priority, due_date)');
        foreach (['raw_material_id'=>'INTEGER REFERENCES erp_raw_materials(id) ON DELETE RESTRICT','production_order_operation_id'=>'INTEGER REFERENCES erp_production_order_operations(id) ON DELETE SET NULL','lot'=>'TEXT','planned_quantity'=>'REAL NOT NULL DEFAULT 0','source_movement_id'=>'INTEGER REFERENCES erp_stock_movements(id) ON DELETE SET NULL'] as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo,'erp_production_consumptions',$column)) $pdo->exec('ALTER TABLE erp_production_consumptions ADD COLUMN '.$column.' '.$definition);
        }
        foreach (['consumption_type'=>'TEXT NOT NULL DEFAULT "DIRECT"','stock_unit_type'=>'TEXT','stock_unit_id'=>'INTEGER','quantity_before'=>'REAL','quantity_after'=>'REAL','unit_code'=>'TEXT','workstation_id'=>'INTEGER REFERENCES erp_work_centers(id) ON DELETE SET NULL','completed_at'=>'DATETIME','idempotency_key'=>'TEXT'] as $column=>$definition) {
            if (!gt_erp_migration_column_exists($pdo,'erp_production_consumptions',$column)) $pdo->exec('ALTER TABLE erp_production_consumptions ADD COLUMN '.$column.' '.$definition);
        }
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_production_consumptions_operation ON erp_production_consumptions(production_order_operation_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_production_consumptions_unit ON erp_production_consumptions(stock_unit_type,stock_unit_id)');
        $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_erp_production_consumptions_idempotency ON erp_production_consumptions(idempotency_key) WHERE idempotency_key IS NOT NULL');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_sheet_versions_article ON erp_article_technical_sheet_versions(finished_product_id,status,effective_from)');
        $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_erp_orders_public_token ON erp_production_orders(public_token) WHERE public_token IS NOT NULL');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_order_costs_order ON erp_production_order_costs(production_order_id,category)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_production_labels_order ON erp_production_labels(production_order_id,label_type,reference_key)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_stock_movements_item ON erp_stock_movements(item_type, item_id, movement_date)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_purchase_orders_status ON erp_purchase_orders(status, expected_date)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_purchase_order_lines_order ON erp_purchase_order_lines(purchase_order_id, line_number)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_stock_movements_purchase_line ON erp_stock_movements(purchase_order_line_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_raw_materials_status ON erp_raw_materials(status, code)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_finished_products_customer ON erp_finished_products(customer_id, status)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_article_materials_article ON erp_article_materials(finished_product_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_routing_step_materials_step ON erp_routing_step_materials(routing_step_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_order_material_reservations_order ON erp_production_order_material_reservations(production_order_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_erp_customer_delivery_addresses_customer ON erp_customer_delivery_addresses(customer_id, id)');

        $perm = $pdo->prepare('INSERT OR IGNORE INTO erp_permissions(code,label,description) VALUES (?,?,?)');
        foreach (gt_erp_default_permissions() as $code => $label) { $perm->execute([$code, $label, $label]); }
        $rolePermission=$pdo->prepare('INSERT OR IGNORE INTO erp_role_permissions(profile,permission_code) VALUES (?,?)');
        foreach(['Produção','Chefias'] as $role){foreach(['erp.operations.view','erp.routings.view','erp.shopfloor.execute'] as $permission)$rolePermission->execute([$role,$permission]);}
        $rolePermission->execute(['Chefias','erp.bi.view']);
        foreach(['erp.operations.manage','erp.routings.edit','erp.routings.activate','erp.work_order_routing.edit','erp.execution.correct'] as $permission)$rolePermission->execute(['Chefias',$permission]);
        $seq = $pdo->prepare('INSERT OR IGNORE INTO erp_number_sequences(code,prefix,next_number,padding) VALUES (?,?,?,?)');
        foreach ([['stock_movement','MOV-',1,6],['purchase_order','ENC-',1,5],['raw_material','MP-',1,5],['subsidiary','SUB-',1,5],['consumable','CON-',1,5],['finished_product','PA-',1,5],['customer','CLI-',1,4],['supplier','FOR-',1,4],['work_order','OF-',1,5]] as $s) { $seq->execute($s); }
        gt_erp_migrate_document_catalog($pdo);
        $set = $pdo->prepare('INSERT OR IGNORE INTO erp_settings(key,value) VALUES (?,?)');
        $set->execute(['allow_negative_stock','0']);
        $set->execute(['raw_material_code_pattern','{tipo}{caracteristica}{largura}{gramagem}{seq}']);
        $set->execute(['labor_hourly_rate','0.00']);
        $set->execute(['bi_tv_refresh_seconds','300']);
        $set->execute(['bi_tv_rotate_seconds','30']);
        $pdo->exec('UPDATE erp_settings SET value="30" WHERE key="bi_tv_rotate_seconds" AND CAST(value AS INTEGER)<30');
        $set->execute(['bi_target_deadline_percent','95']);
        $set->execute(['bi_warning_deadline_percent','85']);
        $set->execute(['bi_target_waste_percent','3']);
        $set->execute(['bi_warning_waste_percent','6']);
        $set->execute(['order_import_max_bytes','10485760']);
        $set->execute(['order_import_match_threshold','90']);

        foreach ([['BOB','Bobina'],['PAL','Palete'],['PRD','Produção'],['EXP','Expedição']] as $lt) { $pdo->prepare('INSERT OR IGNORE INTO erp_location_types(code,description) VALUES (?,?)')->execute($lt); }
        foreach ([['BL','Branco laminado'],['BNL','Branco não laminado'],['TL','Transparente laminado'],['TNL','Transparente não laminado'],['R30','R30'],['R50','R50']] as $mf) { $pdo->prepare('INSERT OR IGNORE INTO erp_material_features(code,description) VALUES (?,?)')->execute($mf); }
        $pdo->exec('INSERT OR IGNORE INTO erp_locations(warehouse_id, code, description) SELECT id, "GERAL", "Localização geral" FROM erp_warehouses');
        $pdo->exec('CREATE TABLE IF NOT EXISTS gestisser_erp_schema_migrations (version TEXT PRIMARY KEY, applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)');
        $marker = $pdo->prepare('INSERT OR IGNORE INTO gestisser_erp_schema_migrations(version) VALUES (?)');
        $marker->execute([GESTISSER_ERP_SCHEMA_VERSION]);
        $pdo->commit();
        $ran = true;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function gt_erp_default_permissions(): array
{
    return [
        'erp.view'=>'Ver ERP','erp.master_data'=>'Gerir dados mestre','erp.customers'=>'Gerir clientes','erp.suppliers'=>'Gerir fornecedores','erp.purchases'=>'Gerir compras','erp.purchase_approve'=>'Aprovar compras','erp.receipts'=>'Registar receções','erp.sales'=>'Gerir vendas','erp.confirm_orders'=>'Confirmar encomendas','erp.work_orders_create'=>'Criar OF','erp.work_orders_release'=>'Libertar OF','erp.planning'=>'Planear produção','erp.production_register'=>'Registar produção','erp.consumptions'=>'Registar consumos','erp.stock_move'=>'Movimentar stock','erp.stock_adjust'=>'Ajustar stock','erp.inventory_approve'=>'Aprovar inventários','erp.shipments_prepare'=>'Preparar expedições','erp.shipments_confirm'=>'Confirmar expedições','erp.quality'=>'Gerir qualidade','erp.costs_view'=>'Consultar custos','erp.costs_edit'=>'Alterar custos','erp.period_close'=>'Fechar períodos','erp.reports_export'=>'Exportar relatórios','erp.documents_cancel'=>'Anular documentos',
        'erp.operations.view'=>'Consultar operações','erp.operations.manage'=>'Gerir operações','erp.routings.view'=>'Consultar routings','erp.routings.edit'=>'Criar/editar routings','erp.routings.activate'=>'Ativar versões de routing','erp.work_order_routing.edit'=>'Alterar routing de uma OF','erp.shopfloor.execute'=>'Executar operações no Shopfloor','erp.execution.correct'=>'Corrigir registos de execução',
        'erp.bi.view'=>'Consultar Business Intelligence','erp.bi.financial'=>'Consultar indicadores financeiros no BI',
        'erp.order_import'=>'Preparar importações de encomendas','erp.order_import_confirm'=>'Confirmar importações de encomendas','erp.supplier_mapping_edit'=>'Alterar mappings de fornecedores'
    ];
}

function gt_erp_user_can(PDO $pdo, array $user, string $permission): bool
{
    if ((int)($user['is_admin'] ?? 0) === 1) { return true; }
    $profile = (string)($user['access_profile'] ?? '');
    if (in_array($profile, ['Produção','Chefias','RH'], true) && $permission === 'erp.view') { return true; }
    $stmt = $pdo->prepare('SELECT is_allowed FROM erp_user_permissions WHERE user_id=? AND permission_code=? LIMIT 1');
    $stmt->execute([(int)$user['id'], $permission]);
    $specific = $stmt->fetchColumn();
    if ($specific !== false) { return (int)$specific === 1; }
    $stmt = $pdo->prepare('SELECT 1 FROM erp_role_permissions WHERE profile=? AND permission_code=? LIMIT 1');
    $stmt->execute([$profile, $permission]);
    return (bool)$stmt->fetchColumn();
}

function gt_erp_audit(PDO $pdo, $userId, string $action, string $entity, $entityId, array $oldValues = [], array $newValues = [], $reason = null)
{
    $stmt = $pdo->prepare('INSERT INTO erp_audit_log(user_id, action, entity, entity_id, old_values_json, new_values_json, ip_address, reason) VALUES (?,?,?,?,?,?,?,?)');
    $stmt->execute([$userId, $action, $entity, $entityId, json_encode($oldValues, JSON_UNESCAPED_UNICODE), json_encode($newValues, JSON_UNESCAPED_UNICODE), (string)($_SERVER['REMOTE_ADDR'] ?? ''), $reason]);
}
