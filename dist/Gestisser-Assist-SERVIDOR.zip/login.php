<?php
require_once __DIR__ . '/helpers.php';

if (is_logged_in()) {
    $loggedUser = current_user($pdo);
    if ($loggedUser) {
        redirect(authenticated_home_url($loggedUser));
    }

    redirect('logout.php');
}

$error = null;
$rememberedEmail = trim((string) ($_COOKIE['gestisser_remembered_email'] ?? ''));
if ($rememberedEmail !== '' && filter_var($rememberedEmail, FILTER_VALIDATE_EMAIL) === false) {
    $rememberedEmail = '';
}
$email = trim((string) ($_POST['email'] ?? $rememberedEmail));
$directPinLogin = isset($_GET['mode']) && (string) $_GET['mode'] === 'pin';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string) ($_POST['pin_entry'] ?? '') === '1') {
    $directPinLogin = true;
}

// Shared Shopfloor terminals return directly to the keypad when an operator
// changes user. Prefer the active shared gateway, even without its own PIN;
// only a successfully verified employee PIN establishes the session below.
if ($directPinLogin && trim((string) ($_POST['email'] ?? '')) === '') {
    $pinGatewayStmt = $pdo->query(
        'SELECT email FROM users
         WHERE is_active = 1
           AND (LOWER(TRIM(email)) = "shopfloor@tisser.pt"
                OR TRIM(COALESCE(pin_code_hash, "")) <> ""
                OR TRIM(COALESCE(pin_code, "")) <> "")
         ORDER BY CASE WHEN LOWER(TRIM(email)) = "shopfloor@tisser.pt" THEN 0 ELSE 1 END, pin_only_login DESC, id ASC
         LIMIT 1'
    );
    $email = trim((string) ($pinGatewayStmt->fetchColumn() ?: ''));
}
$rememberLogin = $_SERVER['REQUEST_METHOD'] === 'POST'
    ? isset($_POST['remember_login'])
    : $rememberedEmail !== '';
$loginMode = $directPinLogin ? 'pin' : 'identify';
$pendingUser = null;
$requestIp = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');

function safe_log_app_event(PDO $pdo, $userId, string $eventType, string $description, array $context = [])
{
    try {
        log_app_event($pdo, $userId, $eventType, $description, $context);
    } catch (Throwable $exception) {
        error_log('[GesTisser] Não foi possível registar evento de login: ' . $exception->getMessage());
    }
}

function update_remembered_login(string $email, bool $remember)
{
    $expiresAt = $remember ? time() + (90 * 24 * 60 * 60) : time() - 3600;
    $value = $remember ? $email : '';
    $isSecure = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';

    if (PHP_VERSION_ID >= 70300) {
        setcookie('gestisser_remembered_email', $value, [
            'expires' => $expiresAt,
            'path' => '/',
            'secure' => $isSecure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        return;
    }

    setcookie('gestisser_remembered_email', $value, $expiresAt, '/; SameSite=Lax', '', $isSecure, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validate_csrf_or_abort(true);
    $action = trim((string) ($_POST['action'] ?? 'identify_user'));
    $identifier = strtolower($email !== '' ? $email : 'unknown');

    if (RateLimiter::tooManyLoginAttempts($pdo, $identifier, $requestIp)) {
        $error = 'Demasiadas tentativas de login. Tente novamente em 15 minutos.';
    }

    if ($error === null && $email === '') {
        $error = 'Indique um email válido.';
    } elseif ($error === null) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE LOWER(TRIM(email)) = LOWER(TRIM(?)) AND is_active = 1 LIMIT 1');
        $stmt->execute([$email]);
        $pendingUser = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pendingUser) {
            RateLimiter::recordLoginAttempt($pdo, $identifier, $requestIp, false);
            safe_log_app_event($pdo, null, 'auth.login_failed', 'Tentativa de login falhada (email não encontrado ou inativo).', ['email' => $email]);
            $error = 'Credenciais inválidas.';
        } else {
            $loginMode = $directPinLogin || (int) ($pendingUser['pin_only_login'] ?? 0) === 1 ? 'pin' : 'password';

            if ($action === 'login_password') {
                $password = trim((string) ($_POST['password'] ?? ''));
                if (password_verify($password, (string) ($pendingUser['password'] ?? ''))) {
                    update_remembered_login($email, $rememberLogin);
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = (int) $pendingUser['id'];
                    $_SESSION['login_at'] = date('Y-m-d H:i:s');
                    $_SESSION['login_mode'] = 'password';
                    unset($_SESSION['shopfloor_gateway_user_id']);
                    RateLimiter::recordLoginAttempt($pdo, $identifier, $requestIp, true);
                    $pdo->prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int) $pendingUser['id']]);
                    AuditLog::write($pdo, (int) $pendingUser['id'], 'auth.login_success', ['mode' => 'password']);
                    safe_log_app_event($pdo, (int) $pendingUser['id'], 'auth.login_success', 'Login com sucesso.');
                    redirect(authenticated_home_url($pendingUser));
                }

                RateLimiter::recordLoginAttempt($pdo, $identifier, $requestIp, false);
                safe_log_app_event($pdo, (int) $pendingUser['id'], 'auth.login_failed', 'Tentativa de login falhada.', ['email' => $email]);
                $error = 'Credenciais inválidas.';
            }

            if ($action === 'login_pin' && $loginMode === 'pin') {
                $pin = preg_replace('/\D+/', '', (string) ($_POST['pin'] ?? ''));

                // O endereço shopfloor funciona como porta de entrada partilhada:
                // qualquer colaborador ativo com um PIN definido pode identificar-se
                // aqui, mesmo que também tenha login normal por password.
                $pinUsersStmt = $pdo->query(
                    'SELECT * FROM users
                     WHERE is_active = 1
                       AND (TRIM(COALESCE(pin_code_hash, "")) <> ""
                            OR TRIM(COALESCE(pin_code, "")) <> "")'
                );
                $pinUsers = $pinUsersStmt->fetchAll(PDO::FETCH_ASSOC);

                $matchedPinUser = null;
                foreach ($pinUsers as $pinUser) {
                    if (verify_pin_code($pinUser, $pin)) {
                        $matchedPinUser = $pinUser;
                        break;
                    }
                }

                if ($matchedPinUser) {
                    update_remembered_login($email, $rememberLogin);
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = (int) $matchedPinUser['id'];
                    $_SESSION['login_at'] = date('Y-m-d H:i:s');
                    $_SESSION['login_mode'] = 'pin';
                    unset($_SESSION['shopfloor_gateway_user_id']);
                    if(strtolower(trim((string)$pendingUser['email']))==='shopfloor@tisser.pt')$_SESSION['shopfloor_gateway_user_id']=(int)$pendingUser['id'];
                    RateLimiter::recordLoginAttempt($pdo, $identifier, $requestIp, true);
                    $pdo->prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([(int) $matchedPinUser['id']]);
                    AuditLog::write($pdo, (int) $matchedPinUser['id'], 'auth.login_success', ['mode' => 'pin']);
                    safe_log_app_event(
                        $pdo,
                        (int) $matchedPinUser['id'],
                        'auth.login_success',
                        'Login com PIN efetuado com sucesso.',
                        ['login_email' => $email]
                    );
                    redirect('shopfloor.php');
                }

                RateLimiter::recordLoginAttempt($pdo, $identifier, $requestIp, false);
                safe_log_app_event($pdo, (int) $pendingUser['id'], 'auth.login_failed', 'Tentativa de login com PIN falhada.', ['email' => $email]);
                $error = 'PIN inválido.';
            }

            if ($action === 'login_pin' && $loginMode !== 'pin') {
                $error = 'Este utilizador utiliza autenticação por password.';
            }
        }
    }
}

$logoLight = app_setting($pdo, 'logo_navbar_light');
$logoDark = app_setting($pdo, 'logo_report_dark');
$hasLightLogo = !empty($logoLight);
$hasDarkLogo = !empty($logoDark);

$pageTitle = 'Login';
require __DIR__ . '/partials/header.php';
?>
<div class="row justify-content-center align-items-center auth-row">
    <div class="col-md-6 col-lg-5">
        <div class="card shadow-sm auth-card">
            <div class="card-body p-4 p-md-5">
                <div class="text-center mb-4">
                    <?php if ($hasDarkLogo): ?>
                        <img src="<?= h($logoDark) ?>" alt="Logótipo empresa" class="auth-logo mb-3">
                    <?php elseif ($hasLightLogo): ?>
                        <img src="<?= h($logoLight) ?>" alt="Logótipo empresa" class="auth-logo mb-3">
                    <?php endif; ?>
                    <h1 class="h4 mb-1">Entrar</h1>
                    <p class="text-secondary small mb-0">Bem-vindo de volta ao GesTisser.</p>
                </div>

                <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>

                <?php if ($loginMode === 'identify'): ?>
                    <form method="post" class="vstack gap-3" id="identifyOrPasswordForm">
                        <?= csrf_input() ?>
                        <input type="hidden" name="action" value="identify_user" id="identifyActionInput">
                        <input class="form-control form-control-lg" type="email" name="email" id="identifyEmailInput" placeholder="Email" value="<?= h((string) $email) ?>" autocomplete="username" autofocus required>
                        <div id="identifyPasswordWrapper" class="d-none">
                            <input class="form-control form-control-lg" type="password" name="password" id="identifyPasswordInput" placeholder="Password" autocomplete="current-password">
                        </div>
                        <div class="form-check auth-remember">
                            <input class="form-check-input" type="checkbox" name="remember_login" value="1" id="identifyRememberLogin" <?= $rememberLogin ? 'checked' : '' ?>>
                            <label class="form-check-label" for="identifyRememberLogin">Memorizar o meu email neste dispositivo</label>
                        </div>
                        <button class="btn btn-primary btn-lg" id="identifySubmitButton">Continuar</button>
                    </form>
                    <script>
                        (() => {
                            const emailInput = document.getElementById('identifyEmailInput');
                            const passwordWrapper = document.getElementById('identifyPasswordWrapper');
                            const passwordInput = document.getElementById('identifyPasswordInput');
                            const actionInput = document.getElementById('identifyActionInput');
                            const submitButton = document.getElementById('identifySubmitButton');

                            const updateLoginFlowByEmail = () => {
                                const normalizedEmail = (emailInput.value || '').trim().toLowerCase();
                                const hasAtSymbol = normalizedEmail.includes('@');
                                const shouldUsePassword = hasAtSymbol && !normalizedEmail.startsWith('shopfloor@');

                                passwordWrapper.classList.toggle('d-none', !shouldUsePassword);
                                passwordInput.required = shouldUsePassword;
                                actionInput.value = shouldUsePassword ? 'login_password' : 'identify_user';
                                submitButton.textContent = shouldUsePassword ? 'Login' : 'Continuar';
                            };

                            emailInput.addEventListener('input', updateLoginFlowByEmail);
                            updateLoginFlowByEmail();
                        })();
                    </script>
                <?php elseif ($loginMode === 'password'): ?>
                    <form method="post" class="vstack gap-3">
                        <?= csrf_input() ?>
                        <input type="hidden" name="action" value="login_password">
                        <input class="form-control form-control-lg" type="email" name="email" value="<?= h((string) $email) ?>" autocomplete="username" readonly required>
                        <input class="form-control form-control-lg" type="password" name="password" placeholder="Password" autocomplete="current-password" autofocus required>
                        <div class="form-check auth-remember">
                            <input class="form-check-input" type="checkbox" name="remember_login" value="1" id="passwordRememberLogin" <?= $rememberLogin ? 'checked' : '' ?>>
                            <label class="form-check-label" for="passwordRememberLogin">Memorizar o meu email neste dispositivo</label>
                        </div>
                        <button class="btn btn-primary btn-lg">Login</button>
                    </form>
                    <div class="text-center mt-3"><a href="login.php" class="small">Trocar de utilizador</a></div>
                <?php else: ?>
                    <form method="post" class="vstack gap-3" id="pinLoginForm">
                        <?= csrf_input() ?>
                        <input type="hidden" name="action" value="login_pin">
                        <?php if ($directPinLogin): ?><input type="hidden" name="pin_entry" value="1"><?php endif; ?>
                        <input type="hidden" name="email" value="<?= h((string) $email) ?>">
                        <?php if ($rememberLogin): ?><input type="hidden" name="remember_login" value="1"><?php endif; ?>
                        <input type="password" class="form-control form-control-lg text-center" name="pin" id="pinInput" inputmode="numeric" pattern="\d{6}" maxlength="6" placeholder="PIN de 6 dígitos" readonly required>
                        <div class="d-grid gap-2" style="grid-template-columns: repeat(3, 1fr); display:grid;">
                            <?php for ($digit = 1; $digit <= 9; $digit++): ?>
                                <button type="button" class="btn btn-outline-secondary btn-lg pin-key" data-value="<?= $digit ?>"><?= $digit ?></button>
                            <?php endfor; ?>
                            <button type="button" class="btn btn-outline-danger btn-lg" id="pinClear">Limpar</button>
                            <button type="button" class="btn btn-outline-secondary btn-lg pin-key" data-value="0">0</button>
                            <button type="submit" class="btn btn-primary btn-lg">Entrar</button>
                        </div>
                    </form>
                    <div class="text-center mt-3"><a href="login.php" class="small">Trocar de utilizador</a></div>
                    <script>
                        (() => {
                            const pinInput = document.getElementById('pinInput');
                            document.querySelectorAll('.pin-key').forEach((button) => {
                                button.addEventListener('click', () => {
                                    if (pinInput.value.length < 6) {
                                        pinInput.value += button.dataset.value;
                                    }
                                });
                            });
                            document.getElementById('pinClear')?.addEventListener('click', () => {
                                pinInput.value = '';
                            });
                        })();
                    </script>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
