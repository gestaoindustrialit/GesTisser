<?php
/** Static bootstrap repairs: do not acquire a SQLite writer when no row needs repair. */
function gt_bootstrap_repair(PDO $pdo, string $sql)
{
    if (!preg_match('/^UPDATE ([a-z_]+) SET .*? WHERE (.*)$/s', $sql, $match)) {
        throw new InvalidArgumentException('Bootstrap repair requires a bounded UPDATE.');
    }
    $probe=$pdo->query('SELECT 1 FROM '.$match[1].' WHERE '.$match[2].' LIMIT 1');
    $needed=$probe->fetchColumn()!==false;$probe->closeCursor();
    if ($needed) $pdo->exec($sql);
}
function gt_bootstrap_seed(PDO $pdo, string $table, string $columns, array $values)
{
    if (!preg_match('/^[a-z_]+$/',$table)||!preg_match('/^[a-z_,]+$/',$columns)) throw new InvalidArgumentException('Invalid bootstrap seed.');
    $key=explode(',',$columns)[0];
    $probe=$pdo->prepare('SELECT 1 FROM '.$table.' WHERE '.$key.'=? LIMIT 1');$probe->execute([$values[0]]);
    $exists=$probe->fetchColumn()!==false;$probe->closeCursor();
    if (!$exists) $pdo->prepare('INSERT OR IGNORE INTO '.$table.'('.$columns.') VALUES ('.implode(',',array_fill(0,count($values),'?')).')')->execute($values);
}
