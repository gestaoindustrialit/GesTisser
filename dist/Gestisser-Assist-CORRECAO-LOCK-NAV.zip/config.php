<?php
require_once __DIR__ . '/bootstrap/app.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Europe/Lisbon');

if (!function_exists('taskforce_error_id')) {
    function taskforce_error_id(): string
    {
        try {
            if (function_exists('random_bytes')) {
                return strtoupper(substr(bin2hex(random_bytes(6)), 0, 12));
            }
        } catch (Throwable $exception) {
            // Fallback below.
        }

        return strtoupper(substr(sha1(uniqid((string) mt_rand(), true)), 0, 12));
    }
}

if (!function_exists('taskforce_log_bootstrap_error')) {
    function taskforce_log_bootstrap_error(string $message)
    {
        error_log($message);

        $logLine = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
        @file_put_contents(__DIR__ . '/bootstrap_errors.log', $logLine, FILE_APPEND);
    }
}

if (!function_exists('taskforce_render_internal_error')) {
    function taskforce_render_internal_error(string $errorId)
    {
        $forceVisibleError = isset($_GET['tf_debug_error']) && $_GET['tf_debug_error'] === '1';

        if (!headers_sent()) {
            http_response_code($forceVisibleError ? 200 : 500);
            header('Content-Type: text/html; charset=UTF-8');
            if ($forceVisibleError) {
                header('X-GesTisser-Debug-Error: ' . $errorId);
            }
        }

        echo '<h1>Erro interno (500)</h1>';
        echo '<p>Ocorreu um erro inesperado ao processar o pedido.</p>';
        if ($forceVisibleError) {
            echo '<p><strong>Modo diagnóstico ativo:</strong> status HTTP devolvido como 200 para evitar página genérica do servidor.</p>';
        }
        echo '<p>Referência do erro: <code>' . htmlspecialchars($errorId, ENT_QUOTES, 'UTF-8') . '</code></p>';
        exit;
    }
}

if (!function_exists('taskforce_sqlite_index_exists')) {
    function taskforce_sqlite_index_exists(PDO $pdo, string $indexName): bool
    {
        $statement = $pdo->prepare("SELECT 1 FROM sqlite_master WHERE type = 'index' AND name = ? LIMIT 1");
        $statement->execute([$indexName]);

        return (bool) $statement->fetchColumn();
    }
}

if (!defined('TASKFORCE_ERROR_HANDLERS_REGISTERED')) {
    define('TASKFORCE_ERROR_HANDLERS_REGISTERED', true);

    set_exception_handler(static function (Throwable $exception) {
        try {
            $errorId = taskforce_error_id();
            taskforce_log_bootstrap_error('[GesTisser][' . $errorId . '] Exceção não tratada: ' . $exception->getMessage() . ' em ' . $exception->getFile() . ':' . $exception->getLine());
            taskforce_render_internal_error($errorId);
        } catch (Throwable $handlerException) {
            if (!headers_sent()) {
                http_response_code(500);
                header('Content-Type: text/plain; charset=UTF-8');
            }
            echo 'Erro interno (500).';
            exit;
        }
    });

    register_shutdown_function(static function () {
        try {
            $lastError = error_get_last();
            if ($lastError === null) {
                return;
            }

            $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
            if (!in_array($lastError['type'] ?? 0, $fatalTypes, true)) {
                return;
            }

            $errorId = taskforce_error_id();
            $message = $lastError['message'] ?? 'Erro fatal desconhecido';
            $file = $lastError['file'] ?? 'ficheiro desconhecido';
            $line = (int) ($lastError['line'] ?? 0);

            taskforce_log_bootstrap_error('[GesTisser][' . $errorId . '] Erro fatal: ' . $message . ' em ' . $file . ':' . $line);
            taskforce_render_internal_error($errorId);
        } catch (Throwable $handlerException) {
            if (!headers_sent()) {
                http_response_code(500);
                header('Content-Type: text/plain; charset=UTF-8');
            }
            echo 'Erro interno (500).';
            exit;
        }
    });
}

$dbFile = __DIR__ . '/database.sqlite';
if (!extension_loaded('pdo_sqlite')) {
    http_response_code(500);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<h1>Erro de configuração</h1>';
    echo '<p>A extensão <code>pdo_sqlite</code> não está ativa neste servidor.</p>';
    exit;
}

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_TIMEOUT, 5);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA busy_timeout = 5000');
    $pdo->exec('PRAGMA journal_mode = WAL');
} catch (Throwable $exception) {
    error_log('[GesTisser] Falha ao iniciar base de dados SQLite: ' . $exception->getMessage());
    http_response_code(500);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<h1>Erro de configuração</h1>';
    echo '<p>Não foi possível iniciar a base de dados SQLite.</p>';
    echo '<p>Verifique permissões de escrita para o ficheiro <code>database.sqlite</code> e para a pasta da aplicação.</p>';
    exit;
}

require_once __DIR__ . '/includes/sqlite_bootstrap_writes.php';
$GLOBALS['pdo'] = $pdo;
if (function_exists('taskforce_ensure_security_tables')) {
    taskforce_ensure_security_tables($pdo);
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )'
);

$userColumns = $pdo->query('PRAGMA table_info(users)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('is_admin', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN is_admin INTEGER DEFAULT 0');
}
if (!in_array('username', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN username TEXT');
}
if (!in_array('access_profile', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN access_profile TEXT DEFAULT "Utilizador"');
}
if (!in_array('is_active', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1');
}
if (!in_array('must_change_password', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN must_change_password INTEGER DEFAULT 0');
}
if (!in_array('user_type', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN user_type TEXT DEFAULT "Funcionário"');
}
if (!in_array('user_number', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN user_number TEXT');
}
if (!in_array('title', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN title TEXT');
}
if (!in_array('short_name', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN short_name TEXT');
}
if (!in_array('initials', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN initials TEXT');
}
if (!in_array('email_notifications_active', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN email_notifications_active INTEGER DEFAULT 1');
}
if (!in_array('sms_notifications_active', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN sms_notifications_active INTEGER DEFAULT 0');
}
if (!in_array('profession', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN profession TEXT');
}
if (!in_array('last_login_at', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN last_login_at DATETIME');
}
if (!in_array('category', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN category TEXT');
}
if (!in_array('manager_name', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN manager_name TEXT');
}
if (!in_array('department', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN department TEXT');
}
if (!in_array('hire_date', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN hire_date TEXT');
}
if (!in_array('birth_date', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN birth_date TEXT');
}
if (!in_array('termination_date', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN termination_date TEXT');
}
if (!in_array('timezone', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN timezone TEXT DEFAULT "Europe/Lisbon"');
}
if (!in_array('phone', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN phone TEXT');
}
if (!in_array('mobile', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN mobile TEXT');
}
if (!in_array('notes', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN notes TEXT');
}
if (!in_array('send_access_email', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN send_access_email INTEGER DEFAULT 0');
}
if (!in_array('department_id', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN department_id INTEGER');
}
if (!in_array('schedule_id', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN schedule_id INTEGER');
}
if (!in_array('pin_code_hash', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN pin_code_hash TEXT');
}
if (!in_array('pin_code', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN pin_code TEXT');
}
if (!in_array('pin_only_login', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN pin_only_login INTEGER DEFAULT 0');
}
if (!in_array('crm_enabled', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN crm_enabled INTEGER NOT NULL DEFAULT 1');
}
if (!in_array('award_profile', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN award_profile TEXT DEFAULT "operador"');
}
if (!in_array('award_eligible', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN award_eligible INTEGER NOT NULL DEFAULT 1');
}

// Personal and civil data kept alongside the user account so the employee
// record no longer needs to be maintained in a separate spreadsheet.
$userPersonalColumns = [
    'personal_email', 'tax_number', 'social_security_number', 'address', 'postal_code', 'parish',
    'municipality', 'district', 'place_of_birth', 'nationality',
    'citizen_card_number', 'citizen_card_expiry_date', 'marital_status',
];
foreach ($userPersonalColumns as $column) {
    if (!in_array($column, $userColumns, true)) {
        $pdo->exec('ALTER TABLE users ADD COLUMN ' . $column . ' TEXT');
    }
}
if (!in_array('dependents_count', $userColumns, true)) {
    $pdo->exec('ALTER TABLE users ADD COLUMN dependents_count INTEGER DEFAULT 0');
}

gt_bootstrap_repair($pdo, 'UPDATE users SET username = email WHERE username IS NULL OR TRIM(username) = ""');
gt_bootstrap_repair($pdo, 'UPDATE users SET access_profile = "Utilizador" WHERE access_profile IS NULL OR TRIM(access_profile) = ""');
gt_bootstrap_repair($pdo, 'UPDATE users SET is_active = 1 WHERE is_active IS NULL');
gt_bootstrap_repair($pdo, 'UPDATE users SET must_change_password = 0 WHERE must_change_password IS NULL');
gt_bootstrap_repair($pdo, 'UPDATE users SET user_type = "Funcionário" WHERE user_type IS NULL OR TRIM(user_type) = ""');
gt_bootstrap_repair($pdo, 'UPDATE users SET email_notifications_active = 1 WHERE email_notifications_active IS NULL');
gt_bootstrap_repair($pdo, 'UPDATE users SET sms_notifications_active = 0 WHERE sms_notifications_active IS NULL');
gt_bootstrap_repair($pdo, 'UPDATE users SET timezone = "Europe/Lisbon" WHERE timezone IS NULL OR TRIM(timezone) = ""');
gt_bootstrap_repair($pdo, 'UPDATE users SET send_access_email = 0 WHERE send_access_email IS NULL');
gt_bootstrap_repair($pdo, 'UPDATE users SET pin_only_login = 0 WHERE pin_only_login IS NULL');
gt_bootstrap_repair($pdo, 'UPDATE users SET crm_enabled = 1 WHERE crm_enabled IS NULL');
// PIN-only accounts are restricted to Shopfloor, including imported records.
gt_bootstrap_repair($pdo, 'UPDATE users SET crm_enabled = 0 WHERE pin_only_login = 1 AND crm_enabled <> 0');
gt_bootstrap_repair($pdo, 'UPDATE users SET award_profile = "operador" WHERE award_profile IS NULL OR TRIM(award_profile) = ""');
gt_bootstrap_repair($pdo, 'UPDATE users SET award_eligible = 1 WHERE award_eligible IS NULL');

$pdo->exec('CREATE TABLE IF NOT EXISTS user_documents (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, original_name TEXT NOT NULL, file_path TEXT NOT NULL, document_type TEXT, notes TEXT, uploaded_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE SET NULL)');

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_citizen_card_expiry_email_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        expiry_date TEXT NOT NULL,
        recipient_email TEXT NOT NULL,
        sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(user_id, expiry_date, recipient_email)
    )'
);
$pdo->exec('CREATE INDEX IF NOT EXISTS idx_hr_cc_expiry_email_log_user_date ON hr_citizen_card_expiry_email_log(user_id, expiry_date)');


$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_greeting_images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        greeting_type TEXT NOT NULL CHECK(greeting_type IN ("birthday", "work_anniversary")),
        title TEXT NOT NULL,
        file_path TEXT NOT NULL,
        original_name TEXT,
        mime_type TEXT,
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        uploaded_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);
$pdo->exec('CREATE INDEX IF NOT EXISTS idx_hr_greeting_images_type_active ON hr_greeting_images(greeting_type, is_active, sort_order)');
$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_greeting_email_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        greeting_type TEXT NOT NULL,
        event_date TEXT NOT NULL,
        greeting_image_id INTEGER,
        recipient_email TEXT NOT NULL,
        sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(greeting_image_id) REFERENCES hr_greeting_images(id) ON DELETE SET NULL,
        UNIQUE(user_id, greeting_type, event_date)
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_department_groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        group_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(group_id) REFERENCES hr_department_groups(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        second_start_time TEXT,
        second_end_time TEXT,
        break_minutes INTEGER NOT NULL DEFAULT 0,
        weekdays_mask TEXT NOT NULL DEFAULT "1,2,3,4,5",
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )'
);

$hrSchedulesColumnsStmt = $pdo->query('PRAGMA table_info(hr_schedules)');
$hrSchedulesColumns = array_column($hrSchedulesColumnsStmt->fetchAll(PDO::FETCH_ASSOC), 'name');
if (!in_array('second_start_time', $hrSchedulesColumns, true)) {
    $pdo->exec('ALTER TABLE hr_schedules ADD COLUMN second_start_time TEXT');
}
if (!in_array('second_end_time', $hrSchedulesColumns, true)) {
    $pdo->exec('ALTER TABLE hr_schedules ADD COLUMN second_end_time TEXT');
}
if (!in_array('parent_schedule_id', $hrSchedulesColumns, true)) {
    $pdo->exec('ALTER TABLE hr_schedules ADD COLUMN parent_schedule_id INTEGER');
}

// A row linked through parent_schedule_id is another daily period of the same
// shift, not a shift that can be assigned independently. Keep old assignments
// consistent with that model when upgrading databases created by earlier
// versions, where those rows were exposed as "variants".
$pdo->exec(
    'UPDATE users
     SET schedule_id = (
        SELECT child.parent_schedule_id
        FROM hr_schedules child
        WHERE child.id = users.schedule_id
          AND child.parent_schedule_id IS NOT NULL
     )
     WHERE schedule_id IN (
        SELECT id FROM hr_schedules WHERE parent_schedule_id IS NOT NULL
     )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_vacation_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT "Aprovado",
        notes TEXT,
        created_by INTEGER,
        total_days REAL NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$vacationEventColumns = $pdo->query('PRAGMA table_info(hr_vacation_events)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('total_days', $vacationEventColumns, true)) {
    $pdo->exec('ALTER TABLE hr_vacation_events ADD COLUMN total_days REAL NOT NULL DEFAULT 0');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_vacation_balances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        year INTEGER NOT NULL,
        assigned_days REAL NOT NULL DEFAULT 0,
        employee_number TEXT,
        shift_time TEXT NOT NULL DEFAULT "08:00",
        is_active INTEGER NOT NULL DEFAULT 1,
        updated_by INTEGER,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, year),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        alert_type TEXT NOT NULL,
        recipient_email TEXT NOT NULL,
        send_time TEXT NOT NULL,
        weekdays_mask TEXT NOT NULL DEFAULT "1,2,3,4,5",
        schedule_frequency TEXT NOT NULL DEFAULT "weekly",
        monthly_day INTEGER NOT NULL DEFAULT 1,
        selected_user_ids TEXT NOT NULL DEFAULT "",
        last_sent_at DATETIME,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$hrAlertColumns = $pdo->query('PRAGMA table_info(hr_alerts)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('schedule_frequency', $hrAlertColumns, true)) {
    $pdo->exec('ALTER TABLE hr_alerts ADD COLUMN schedule_frequency TEXT NOT NULL DEFAULT "weekly"');
}
if (!in_array('monthly_day', $hrAlertColumns, true)) {
    $pdo->exec('ALTER TABLE hr_alerts ADD COLUMN monthly_day INTEGER NOT NULL DEFAULT 1');
}
if (!in_array('selected_user_ids', $hrAlertColumns, true)) {
    $pdo->exec('ALTER TABLE hr_alerts ADD COLUMN selected_user_ids TEXT NOT NULL DEFAULT ""');
}
if (!in_array('last_sent_at', $hrAlertColumns, true)) {
    $pdo->exec('ALTER TABLE hr_alerts ADD COLUMN last_sent_at DATETIME');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_hour_banks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL UNIQUE,
        balance_hours REAL NOT NULL DEFAULT 0,
        notes TEXT,
        updated_by INTEGER,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);


$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_bh_overrides (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        work_date TEXT NOT NULL,
        bh_minutes INTEGER NOT NULL,
        reason TEXT,
        updated_by INTEGER,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, work_date),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_bh_override_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        work_date TEXT NOT NULL,
        previous_bh_minutes INTEGER,
        new_bh_minutes INTEGER NOT NULL,
        reason TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_time_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        entry_type TEXT NOT NULL,
        note TEXT,
        validated_by INTEGER,
        validated_at DATETIME,
        occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(validated_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_break_reasons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL,
        label TEXT NOT NULL,
        notes TEXT,
        planned_seconds INTEGER NOT NULL DEFAULT 0,
        break_type TEXT NOT NULL DEFAULT "Pausa",
        requires_comment INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);
$pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_shopfloor_break_reasons_code ON shopfloor_break_reasons(code)');

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_break_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        break_reason_id INTEGER NOT NULL,
        break_type TEXT NOT NULL DEFAULT "Pausa",
        comment TEXT,
        started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        ended_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(break_reason_id) REFERENCES shopfloor_break_reasons(id) ON DELETE RESTRICT
    )'
);
$pdo->exec('CREATE INDEX IF NOT EXISTS idx_shopfloor_break_entries_user_day ON shopfloor_break_entries(user_id, started_at)');

$timeEntryColumns = $pdo->query('PRAGMA table_info(shopfloor_time_entries)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('validated_by', $timeEntryColumns, true)) {
    $pdo->exec('ALTER TABLE shopfloor_time_entries ADD COLUMN validated_by INTEGER');
}
if (!in_array('validated_at', $timeEntryColumns, true)) {
    $pdo->exec('ALTER TABLE shopfloor_time_entries ADD COLUMN validated_at DATETIME');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_calendar_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        event_type TEXT NOT NULL DEFAULT "Feriado",
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        color TEXT NOT NULL DEFAULT "#d63384",
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_hour_bank_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        delta_minutes INTEGER NOT NULL,
        reason TEXT NOT NULL,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$hourBankLogColumnsStmt = $pdo->query('PRAGMA table_info(hr_hour_bank_logs)');
$hourBankLogColumns = $hourBankLogColumnsStmt ? $hourBankLogColumnsStmt->fetchAll(PDO::FETCH_COLUMN, 1) : [];
if (!in_array('action_type', $hourBankLogColumns, true)) {
    try {
        $pdo->exec("ALTER TABLE hr_hour_bank_logs ADD COLUMN action_type TEXT NOT NULL DEFAULT 'credito'");
    } catch (PDOException $e) {
        // Mantém compatibilidade com instalações que já tenham migração parcial.
    }
}
if (!in_array('action_date', $hourBankLogColumns, true)) {
    try {
        $pdo->exec('ALTER TABLE hr_hour_bank_logs ADD COLUMN action_date TEXT');
    } catch (PDOException $e) {
        // Mantém compatibilidade com instalações que já tenham migração parcial.
    }
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_absence_reasons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reason_type TEXT NOT NULL DEFAULT "Ausência",
        code TEXT,
        reason_code TEXT,
        sage_code TEXT,
        label TEXT NOT NULL,
        color TEXT NOT NULL DEFAULT "#2563eb",
        show_in_shopfloor INTEGER NOT NULL DEFAULT 1,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$absenceReasonColumns = $pdo->query('PRAGMA table_info(shopfloor_absence_reasons)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('code', $absenceReasonColumns, true)) {
    $pdo->exec('ALTER TABLE shopfloor_absence_reasons ADD COLUMN code TEXT');
}
if (!in_array('reason_code', $absenceReasonColumns, true)) {
    $pdo->exec('ALTER TABLE shopfloor_absence_reasons ADD COLUMN reason_code TEXT');
}
if (!in_array('sage_code', $absenceReasonColumns, true)) {
    $pdo->exec('ALTER TABLE shopfloor_absence_reasons ADD COLUMN sage_code TEXT');
}
if (!in_array('color', $absenceReasonColumns, true)) {
    $pdo->exec("ALTER TABLE shopfloor_absence_reasons ADD COLUMN color TEXT NOT NULL DEFAULT '#2563eb'");
}
if (!in_array('reason_type', $absenceReasonColumns, true)) {
    $pdo->exec("ALTER TABLE shopfloor_absence_reasons ADD COLUMN reason_type TEXT NOT NULL DEFAULT 'Ausência'");
}
if (!in_array('show_in_shopfloor', $absenceReasonColumns, true)) {
    $pdo->exec('ALTER TABLE shopfloor_absence_reasons ADD COLUMN show_in_shopfloor INTEGER NOT NULL DEFAULT 1');
}

$absenceReasonsCreateStmt = $pdo->query("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'shopfloor_absence_reasons' LIMIT 1");
$absenceReasonsCreateSql = $absenceReasonsCreateStmt ? (string) ($absenceReasonsCreateStmt->fetchColumn() ?: '') : '';
if ($absenceReasonsCreateSql !== '' && stripos($absenceReasonsCreateSql, 'label TEXT NOT NULL UNIQUE') !== false) {
    $pdo->exec('PRAGMA foreign_keys = OFF');
    try {
        $pdo->beginTransaction();
        $pdo->exec('ALTER TABLE shopfloor_absence_reasons RENAME TO shopfloor_absence_reasons_legacy');
        $pdo->exec(
            'CREATE TABLE shopfloor_absence_reasons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reason_type TEXT NOT NULL DEFAULT "Ausência",
                code TEXT,
                reason_code TEXT,
                sage_code TEXT,
                label TEXT NOT NULL,
                color TEXT NOT NULL DEFAULT "#2563eb",
                show_in_shopfloor INTEGER NOT NULL DEFAULT 1,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_by INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
            )'
        );
        $pdo->exec('INSERT INTO shopfloor_absence_reasons(id, reason_type, code, reason_code, sage_code, label, color, show_in_shopfloor, is_active, created_by, created_at) SELECT id, reason_type, code, reason_code, sage_code, label, color, show_in_shopfloor, is_active, created_by, created_at FROM shopfloor_absence_reasons_legacy');
        $pdo->commit();

        try {
            $pdo->exec('DROP TABLE shopfloor_absence_reasons_legacy');
        } catch (PDOException $dropException) {
            if (stripos((string) $dropException->getMessage(), 'locked') === false) {
                throw $dropException;
            }
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        if (stripos((string) $exception->getMessage(), 'locked') === false) {
            throw $exception;
        }
    } finally {
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
}

gt_bootstrap_repair($pdo, "UPDATE shopfloor_absence_reasons SET color = '#2563eb' WHERE color IS NULL OR TRIM(color) = ''");
gt_bootstrap_repair($pdo, "UPDATE shopfloor_absence_reasons SET reason_type = 'Ausência' WHERE reason_type IS NULL OR TRIM(reason_type) = ''");
gt_bootstrap_repair($pdo, 'UPDATE shopfloor_absence_reasons SET reason_code = COALESCE(NULLIF(TRIM(reason_code), ""), NULLIF(TRIM(code), "")) WHERE reason_code IS NOT COALESCE(NULLIF(TRIM(reason_code), ""), NULLIF(TRIM(code), ""))');
gt_bootstrap_repair($pdo, 'UPDATE shopfloor_absence_reasons SET sage_code = COALESCE(NULLIF(TRIM(sage_code), ""), NULLIF(TRIM(code), ""), NULLIF(TRIM(reason_code), "")) WHERE sage_code IS NOT COALESCE(NULLIF(TRIM(sage_code), ""), NULLIF(TRIM(code), ""), NULLIF(TRIM(reason_code), ""))');
gt_bootstrap_repair($pdo, 'UPDATE shopfloor_absence_reasons SET show_in_shopfloor = 1 WHERE show_in_shopfloor IS NULL');
$missingAbsenceReasonCodes = $pdo->query("SELECT id FROM shopfloor_absence_reasons WHERE reason_code IS NULL OR TRIM(reason_code) = '' ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);
if ($missingAbsenceReasonCodes) {
    $absenceReasonCodeUpdateStmt = $pdo->prepare('UPDATE shopfloor_absence_reasons SET reason_code = ? WHERE id = ?');
    foreach ($missingAbsenceReasonCodes as $absenceReasonId) {
        $absenceReasonCodeUpdateStmt->execute([sprintf('MOT-%03d', (int) $absenceReasonId), (int) $absenceReasonId]);
    }
}
gt_bootstrap_repair($pdo, 'UPDATE shopfloor_absence_reasons SET sage_code = reason_code WHERE sage_code IS NULL OR TRIM(sage_code) = ""');
gt_bootstrap_repair($pdo, "UPDATE shopfloor_absence_reasons SET sage_code = SUBSTR(TRIM(sage_code), 1, LENGTH(TRIM(sage_code)) - 2) WHERE TRIM(sage_code) LIKE '%.0'");
$absenceReasonCodeIndexExists = taskforce_sqlite_index_exists($pdo, 'idx_shopfloor_absence_reasons_reason_code');
if (!$absenceReasonCodeIndexExists) {
    $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_shopfloor_absence_reasons_reason_code ON shopfloor_absence_reasons(reason_code)');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS app_settings (
        setting_key TEXT PRIMARY KEY,
        setting_value TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )'
);

// Payroll is deliberately stored separately from live attendance: a closed
// processing keeps an immutable JSON snapshot while manual variables retain a
// complete author/update trail.
$pdo->exec('CREATE TABLE IF NOT EXISTS payroll_permissions (code TEXT PRIMARY KEY, label TEXT NOT NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS payroll_user_permissions (user_id INTEGER NOT NULL, permission_code TEXT NOT NULL, is_allowed INTEGER NOT NULL DEFAULT 1, updated_by INTEGER, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id, permission_code), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL)');
$payrollPermissionStmt = $pdo->prepare('INSERT OR IGNORE INTO payroll_permissions(code,label) VALUES (?,?)');
foreach ([
    'payroll.view' => 'Consultar Payroll', 'payroll.edit' => 'Editar Payroll',
    'payroll.export' => 'Exportar Payroll', 'payroll.close' => 'Fechar Payroll',
    'payroll.reopen' => 'Reabrir Payroll',
] as $payrollPermissionCode => $payrollPermissionLabel) {
    gt_bootstrap_seed($pdo, 'payroll_permissions', 'code,label', [$payrollPermissionCode, $payrollPermissionLabel]);
}
$pdo->exec('CREATE TABLE IF NOT EXISTS payroll_runs (id INTEGER PRIMARY KEY AUTOINCREMENT, payroll_year INTEGER NOT NULL, payroll_month INTEGER NOT NULL, status TEXT NOT NULL DEFAULT "Rascunho", filters_json TEXT, snapshot_json TEXT, validated_by INTEGER, validated_at DATETIME, closed_by INTEGER, closed_at DATETIME, reopened_by INTEGER, reopened_at DATETIME, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(payroll_year,payroll_month), FOREIGN KEY(validated_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY(closed_by) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY(reopened_by) REFERENCES users(id) ON DELETE SET NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS payroll_variables (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, payroll_year INTEGER NOT NULL, payroll_month INTEGER NOT NULL, variable_type TEXT NOT NULL, value REAL NOT NULL DEFAULT 0, observation TEXT, updated_by INTEGER NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id,payroll_year,payroll_month,variable_type), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE RESTRICT)');
$pdo->exec('CREATE TABLE IF NOT EXISTS payroll_audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, payroll_run_id INTEGER NOT NULL, action TEXT NOT NULL, user_id INTEGER, details TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(payroll_run_id) REFERENCES payroll_runs(id) ON DELETE CASCADE, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)');
$pdo->exec('CREATE INDEX IF NOT EXISTS idx_payroll_variables_period ON payroll_variables(payroll_year,payroll_month,user_id)');
$breakReasonSeedKey = 'shopfloor_break_reasons_seeded';
$breakReasonSeedStmt = $pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key = ? LIMIT 1');
$breakReasonSeedStmt->execute([$breakReasonSeedKey]);
$breakReasonSeedState = $breakReasonSeedStmt->fetchColumn();
$breakReasonCountStmt = $pdo->query('SELECT COUNT(*) FROM shopfloor_break_reasons');
$breakReasonCount = (int) ($breakReasonCountStmt ? $breakReasonCountStmt->fetchColumn() : 0);
if ($breakReasonSeedState === false && $breakReasonCount === 0) {
    $defaultBreakReasonStmt = $pdo->prepare('INSERT INTO shopfloor_break_reasons(code, label, notes, planned_seconds, break_type, requires_comment, is_active, created_by) VALUES (?, ?, ?, ?, ?, ?, 1, NULL)');
    foreach ([
        ['01', 'WC', null, 180, 'Paragem', 0],
        ['02', 'Pausa Manhã', null, 900, 'Pausa', 0],
        ['03', 'Pausa Tarde', null, 600, 'Pausa', 0],
        ['04', 'Limpeza de Posto - Diária', null, 180, 'Paragem', 0],
        ['05', 'Limpeza de Posto - Semanal', null, 900, 'Paragem', 0],
        ['06', 'Reunião', null, 600, 'Paragem', 1],
        ['07', 'Medicina de Trabalho', null, 600, 'Paragem', 0],
        ['08', 'Outra', null, 60, 'Paragem', 1],
    ] as $defaultBreakReason) {
        $defaultBreakReasonStmt->execute($defaultBreakReason);
    }
}
if ($breakReasonSeedState === false) {
    $breakReasonSeedInsertStmt = $pdo->prepare('INSERT INTO app_settings(setting_key, setting_value) VALUES (?, ?)');
    $breakReasonSeedInsertStmt->execute([$breakReasonSeedKey, '1']);
}

$absenceReasonSeedKey = 'shopfloor_absence_reasons_seeded';
$absenceReasonSeedStmt = $pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key = ? LIMIT 1');
$absenceReasonSeedStmt->execute([$absenceReasonSeedKey]);
$absenceReasonSeedState = $absenceReasonSeedStmt->fetchColumn();
$absenceReasonCountStmt = $pdo->query('SELECT COUNT(*) FROM shopfloor_absence_reasons');
$absenceReasonCount = (int) ($absenceReasonCountStmt ? $absenceReasonCountStmt->fetchColumn() : 0);

if ($absenceReasonSeedState === false && $absenceReasonCount === 0) {
    $defaultAbsenceReasonStmt = $pdo->prepare('INSERT OR IGNORE INTO shopfloor_absence_reasons(reason_type, reason_code, sage_code, label, color, show_in_shopfloor, is_active, created_by) VALUES (?, ?, ?, ?, ?, 1, 1, NULL)');
    foreach ([
        ['Ausência', 'MOT-001', '001', 'Falta sem perda de remuneração', '#0d6efd'],
        ['Ausência', 'MOT-002', '002', 'Consulta médica', '#198754'],
        ['Ausência', 'MOT-003', '003', 'Acompanhamento familiar', '#fd7e14'],
        ['Ausência', 'MOT-004', '004', 'Formação externa', '#6f42c1'],
        ['Ausência', 'MOT-005', '005', 'Outro motivo justificado', '#6c757d']
    ] as $defaultAbsenceReason) {
        $defaultAbsenceReasonStmt->execute($defaultAbsenceReason);
    }
}

if ($absenceReasonSeedState === false) {
    $absenceReasonSeedInsertStmt = $pdo->prepare('INSERT INTO app_settings(setting_key, setting_value) VALUES (?, ?)');
    $absenceReasonSeedInsertStmt->execute([$absenceReasonSeedKey, '1']);
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_absence_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        request_type TEXT NOT NULL DEFAULT "Dias inteiros",
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        start_time TEXT,
        end_time TEXT,
        reason TEXT NOT NULL,
        details TEXT,
        status TEXT NOT NULL DEFAULT "Pendente",
        reviewed_by INTEGER,
        reviewed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$absenceRequestColumnsStmt = $pdo->query('PRAGMA table_info(shopfloor_absence_requests)');
$absenceRequestColumns = $absenceRequestColumnsStmt ? $absenceRequestColumnsStmt->fetchAll(PDO::FETCH_COLUMN, 1) : [];
if (!in_array('request_type', $absenceRequestColumns, true)) {
    try {
        $pdo->exec("ALTER TABLE shopfloor_absence_requests ADD COLUMN request_type TEXT NOT NULL DEFAULT 'Dias inteiros'");
    } catch (PDOException $e) {
        // Mantém compatibilidade com instalações que já tenham migração parcial.
    }
}
if (!in_array('start_time', $absenceRequestColumns, true)) {
    try {
        $pdo->exec('ALTER TABLE shopfloor_absence_requests ADD COLUMN start_time TEXT');
    } catch (PDOException $e) {
        // Mantém compatibilidade com instalações que já tenham migração parcial.
    }
}
if (!in_array('end_time', $absenceRequestColumns, true)) {
    try {
        $pdo->exec('ALTER TABLE shopfloor_absence_requests ADD COLUMN end_time TEXT');
    } catch (PDOException $e) {
        // Mantém compatibilidade com instalações que já tenham migração parcial.
    }
}
if (!in_array('duration_type', $absenceRequestColumns, true)) {
    try {
        $pdo->exec("ALTER TABLE shopfloor_absence_requests ADD COLUMN duration_type TEXT NOT NULL DEFAULT 'Completa'");
    } catch (PDOException $e) {
        // Mantém compatibilidade com instalações que já tenham migração parcial.
    }
}
if (!in_array('duration_hours', $absenceRequestColumns, true)) {
    try {
        $pdo->exec('ALTER TABLE shopfloor_absence_requests ADD COLUMN duration_hours TEXT');
    } catch (PDOException $e) {
        // Mantém compatibilidade com instalações que já tenham migração parcial.
    }
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_justifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        absence_request_id INTEGER,
        event_date TEXT NOT NULL,
        description TEXT NOT NULL,
        attachment_path TEXT,
        status TEXT NOT NULL DEFAULT "Submetida",
        reviewed_by INTEGER,
        reviewed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(absence_request_id) REFERENCES shopfloor_absence_requests(id) ON DELETE SET NULL,
        FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_absence_time_allocations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        work_date TEXT NOT NULL,
        absence_request_id INTEGER NOT NULL,
        absence_code TEXT NOT NULL,
        absence_reason TEXT NOT NULL DEFAULT "",
        allocated_minutes INTEGER NOT NULL DEFAULT 0,
        updated_by INTEGER,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(absence_request_id) REFERENCES shopfloor_absence_requests(id) ON DELETE CASCADE,
        FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);
$pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_shopfloor_absence_time_allocations_user_day ON shopfloor_absence_time_allocations(user_id, work_date)');
$absenceAllocationColumns = $pdo->query('PRAGMA table_info(shopfloor_absence_time_allocations)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('absence_reason', $absenceAllocationColumns, true)) {
    $pdo->exec('ALTER TABLE shopfloor_absence_time_allocations ADD COLUMN absence_reason TEXT NOT NULL DEFAULT ""');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_vacation_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        total_days REAL,
        notes TEXT,
        status TEXT NOT NULL DEFAULT "Pendente",
        reviewed_by INTEGER,
        reviewed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        audience TEXT NOT NULL DEFAULT "shopfloor",
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_announcement_targets (
        announcement_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(announcement_id, user_id),
        FOREIGN KEY(announcement_id) REFERENCES shopfloor_announcements(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS shopfloor_announcement_acknowledgements (
        announcement_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        acknowledged_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(announcement_id, user_id),
        FOREIGN KEY(announcement_id) REFERENCES shopfloor_announcements(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$defaultGroupStmt = $pdo->prepare('INSERT OR IGNORE INTO hr_department_groups(name) VALUES (?)');
foreach (['Produção', 'Controlo', 'Administrativos'] as $defaultGroupName) {
    $defaultGroupStmt->execute([$defaultGroupName]);
}


require_once __DIR__ . '/erp_migrations.php';

// Módulo ERP: produção, armazém, turnos e tabelas auxiliares.
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_work_centers (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, hourly_rate REAL NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_operations (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, default_work_center_id INTEGER, standard_minutes INTEGER NOT NULL DEFAULT 0, hourly_rate REAL NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, FOREIGN KEY(default_work_center_id) REFERENCES erp_work_centers(id) ON DELETE SET NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_shift_templates (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, break_minutes INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_shift_assignments (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, shift_template_id INTEGER NOT NULL, work_date TEXT NOT NULL, work_center_id INTEGER, notes TEXT, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id, work_date), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(shift_template_id) REFERENCES erp_shift_templates(id) ON DELETE RESTRICT, FOREIGN KEY(work_center_id) REFERENCES erp_work_centers(id) ON DELETE SET NULL, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_customers (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, tax_number TEXT, country TEXT DEFAULT "Portugal", address TEXT, phone TEXT, email TEXT, discount_percent REAL NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, tax_number TEXT, country TEXT DEFAULT "Portugal", address TEXT, phone TEXT, email TEXT, is_active INTEGER NOT NULL DEFAULT 1)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_units (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, factor REAL NOT NULL DEFAULT 1)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_product_types (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_material_types (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_colors (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, pantone TEXT)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_warehouses (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, location TEXT, is_active INTEGER NOT NULL DEFAULT 1)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_products (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, customer_code TEXT, description TEXT NOT NULL, customer_id INTEGER, product_type_id INTEGER, material_type_id INTEGER, unit_id INTEGER, width REAL, length REAL, grammage REAL, color_id INTEGER, min_stock REAL NOT NULL DEFAULT 0, unit_cost REAL NOT NULL DEFAULT 0, unit_price REAL NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, FOREIGN KEY(customer_id) REFERENCES erp_customers(id) ON DELETE SET NULL, FOREIGN KEY(product_type_id) REFERENCES erp_product_types(id) ON DELETE SET NULL, FOREIGN KEY(material_type_id) REFERENCES erp_material_types(id) ON DELETE SET NULL, FOREIGN KEY(unit_id) REFERENCES erp_units(id) ON DELETE SET NULL, FOREIGN KEY(color_id) REFERENCES erp_colors(id) ON DELETE SET NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_inventory_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, movement_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, movement_type TEXT NOT NULL, product_id INTEGER NOT NULL, warehouse_from_id INTEGER, warehouse_to_id INTEGER, quantity REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, reference_type TEXT, reference_id INTEGER, notes TEXT, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(product_id) REFERENCES erp_products(id) ON DELETE RESTRICT, FOREIGN KEY(warehouse_from_id) REFERENCES erp_warehouses(id) ON DELETE SET NULL, FOREIGN KEY(warehouse_to_id) REFERENCES erp_warehouses(id) ON DELETE SET NULL, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_production_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, order_number TEXT NOT NULL UNIQUE, customer_id INTEGER, product_id INTEGER NOT NULL, planned_quantity REAL NOT NULL, produced_quantity REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT "Planeada", due_date TEXT, notes TEXT, estimated_material_cost REAL NOT NULL DEFAULT 0, estimated_labor_cost REAL NOT NULL DEFAULT 0, estimated_overhead_cost REAL NOT NULL DEFAULT 0, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(customer_id) REFERENCES erp_customers(id) ON DELETE SET NULL, FOREIGN KEY(product_id) REFERENCES erp_products(id) ON DELETE RESTRICT, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_production_order_documents (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL, title TEXT NOT NULL, document_url TEXT, body TEXT, is_required INTEGER NOT NULL DEFAULT 1, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_production_order_document_acknowledgements (document_id INTEGER NOT NULL, user_id INTEGER NOT NULL, acknowledged_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(document_id, user_id), FOREIGN KEY(document_id) REFERENCES erp_production_order_documents(id) ON DELETE CASCADE, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_production_order_operations (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL, operation_id INTEGER NOT NULL, sequence_no INTEGER NOT NULL DEFAULT 10, planned_minutes INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT "Pendente", FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(operation_id) REFERENCES erp_operations(id) ON DELETE RESTRICT)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_operation_time_entries (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_operation_id INTEGER NOT NULL, user_id INTEGER NOT NULL, started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ended_at DATETIME, quantity_good REAL NOT NULL DEFAULT 0, quantity_rejected REAL NOT NULL DEFAULT 0, notes TEXT, FOREIGN KEY(production_order_operation_id) REFERENCES erp_production_order_operations(id) ON DELETE CASCADE, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)');
$pdo->exec('CREATE TABLE IF NOT EXISTS erp_production_consumptions (id INTEGER PRIMARY KEY AUTOINCREMENT, production_order_id INTEGER NOT NULL, product_id INTEGER NOT NULL, warehouse_id INTEGER, quantity REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, created_by INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(production_order_id) REFERENCES erp_production_orders(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES erp_products(id) ON DELETE RESTRICT, FOREIGN KEY(warehouse_id) REFERENCES erp_warehouses(id) ON DELETE SET NULL, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL)');
foreach ([['U','Unidade',1],['Kg','Kilo',1],['L','Litro',1],['ML','Metro linear',1],['T','Tonelada',1000]] as $u) { gt_bootstrap_seed($pdo, 'erp_units', 'code,name,factor', $u); }
foreach ([['PROD','Produção'],['ARM','Armazém principal']] as $w) { gt_bootstrap_seed($pdo, 'erp_warehouses', 'code,name', $w); }
foreach ([['S','Sacos'],['C','Caixas']] as $t) { gt_bootstrap_seed($pdo, 'erp_product_types', 'code,name', $t); }
foreach ([['RF','Ráfia'],['PL','Plástico'],['SP','Saco de Papel'],['BP','BOPP']] as $m) { gt_bootstrap_seed($pdo, 'erp_material_types', 'code,name', $m); }
foreach ([['BR','Branco','000'],['AZLA','Azul Laminado',''],['TRLA','Transparente Laminado',''],['VMLA','Vermelho Laminado','']] as $c) { gt_bootstrap_seed($pdo, 'erp_colors', 'code,name,pantone', $c); }
foreach ([['GERAL','Turno geral','08:00','17:00',60],['MANHA','Manhã','06:00','14:00',30],['TARDE','Tarde','14:00','22:00',30],['NOITE','Noite','22:00','06:00',30]] as $s) { gt_bootstrap_seed($pdo, 'erp_shift_templates', 'code,name,start_time,end_time,break_minutes', $s); }
foreach ([['IMP','Impressora',45],['COR','Corte e Cose',45],['RET','Retratador',35]] as $wc) { gt_bootstrap_seed($pdo, 'erp_work_centers', 'code,name,hourly_rate', $wc); }
gt_erp_run_phase1_migrations($pdo);
require_once __DIR__ . '/company_mapper_migrations.php';
company_mapper_run_migrations($pdo);

$pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username_unique ON users(username)');

$hasAdmin = (int) $pdo->query('SELECT COUNT(*) FROM users WHERE is_admin = 1 AND COALESCE(pin_only_login, 0) = 0')->fetchColumn();
if ($hasAdmin === 0) {
    $firstUserId = $pdo->query('SELECT id FROM users WHERE COALESCE(pin_only_login, 0) = 0 ORDER BY id ASC LIMIT 1')->fetchColumn();
    if ($firstUserId) {
        $stmt = $pdo->prepare('UPDATE users SET is_admin = 1 WHERE id = ?');
        $stmt->execute([(int) $firstUserId]);
    }
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        created_by INTEGER NOT NULL,
        estimated_minutes INTEGER,
        actual_minutes INTEGER,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_members (
        team_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role TEXT DEFAULT "member",
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(team_id, user_id),
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        created_by INTEGER NOT NULL,
        leader_user_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(leader_user_id) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$projectColumns = $pdo->query('PRAGMA table_info(projects)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('leader_user_id', $projectColumns, true)) {
    $pdo->exec('ALTER TABLE projects ADD COLUMN leader_user_id INTEGER');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        parent_task_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        status TEXT NOT NULL DEFAULT "todo",
        priority TEXT NOT NULL DEFAULT "normal",
        due_date DATE,
        position INTEGER DEFAULT 0,
        created_by INTEGER NOT NULL,
        estimated_minutes INTEGER,
        actual_minutes INTEGER,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
        FOREIGN KEY(parent_task_id) REFERENCES tasks(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);


$taskColumns = $pdo->query('PRAGMA table_info(tasks)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('estimated_minutes', $taskColumns, true)) {
    $pdo->exec('ALTER TABLE tasks ADD COLUMN estimated_minutes INTEGER');
}
if (!in_array('actual_minutes', $taskColumns, true)) {
    $pdo->exec('ALTER TABLE tasks ADD COLUMN actual_minutes INTEGER');
}
if (!in_array('updated_at', $taskColumns, true)) {
    $pdo->exec('ALTER TABLE tasks ADD COLUMN updated_at DATETIME');
    gt_bootstrap_repair($pdo, 'UPDATE tasks SET updated_at = created_at WHERE updated_at IS NULL');
}
if (!in_array('updated_by', $taskColumns, true)) {
    $pdo->exec('ALTER TABLE tasks ADD COLUMN updated_by INTEGER');
    gt_bootstrap_repair($pdo, 'UPDATE tasks SET updated_by = created_by WHERE updated_by IS NULL');
}


$taskColumns = $pdo->query('PRAGMA table_info(tasks)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('assignee_user_id', $taskColumns, true)) {
    $pdo->exec('ALTER TABLE tasks ADD COLUMN assignee_user_id INTEGER');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS daily_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        report_date DATE NOT NULL,
        summary TEXT,
        html_content TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS app_settings (
        setting_key TEXT PRIMARY KEY,
        setting_value TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )'
);
$pdo->exec(
    'CREATE TABLE IF NOT EXISTS checklist_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        is_done INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS checklist_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS checklist_template_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        template_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        position INTEGER NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(template_id) REFERENCES checklist_templates(id) ON DELETE CASCADE
    )'
);

$checklistTemplateItemColumns = $pdo->query('PRAGMA table_info(checklist_template_items)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('field_type', $checklistTemplateItemColumns, true)) {
    $pdo->exec('ALTER TABLE checklist_template_items ADD COLUMN field_type TEXT NOT NULL DEFAULT "checkbox"');
}
if (!in_array('options_json', $checklistTemplateItemColumns, true)) {
    $pdo->exec('ALTER TABLE checklist_template_items ADD COLUMN options_json TEXT');
}
if (!in_array('is_required', $checklistTemplateItemColumns, true)) {
    $pdo->exec('ALTER TABLE checklist_template_items ADD COLUMN is_required INTEGER NOT NULL DEFAULT 1');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_forms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        department TEXT NOT NULL,
        fields_json TEXT,
        created_by INTEGER NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$teamFormColumns = $pdo->query('PRAGMA table_info(team_forms)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('fields_json', $teamFormColumns, true)) {
    $pdo->exec('ALTER TABLE team_forms ADD COLUMN fields_json TEXT');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_form_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        form_id INTEGER NOT NULL,
        payload_json TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        assignee_user_id INTEGER,
        status TEXT NOT NULL DEFAULT "open",
        completed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(form_id) REFERENCES team_forms(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(assignee_user_id) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$entryColumns = $pdo->query('PRAGMA table_info(team_form_entries)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('assignee_user_id', $entryColumns, true)) {
    $pdo->exec('ALTER TABLE team_form_entries ADD COLUMN assignee_user_id INTEGER');
}
if (!in_array('status', $entryColumns, true)) {
    $pdo->exec('ALTER TABLE team_form_entries ADD COLUMN status TEXT NOT NULL DEFAULT "open"');
}
if (!in_array('completed_at', $entryColumns, true)) {
    $pdo->exec('ALTER TABLE team_form_entries ADD COLUMN completed_at DATETIME');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_code TEXT NOT NULL UNIQUE,
        team_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        urgency TEXT NOT NULL DEFAULT "Média",
        due_date DATE,
        created_by INTEGER NOT NULL,
        assignee_user_id INTEGER,
        status TEXT NOT NULL DEFAULT "open",
        completed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(assignee_user_id) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_ticket_status_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER NOT NULL,
        from_status TEXT,
        to_status TEXT NOT NULL,
        changed_by INTEGER,
        changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(ticket_id) REFERENCES team_tickets(id) ON DELETE CASCADE,
        FOREIGN KEY(changed_by) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$ticketColumns = $pdo->query('PRAGMA table_info(team_tickets)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('assignee_user_id', $ticketColumns, true)) {
    $pdo->exec('ALTER TABLE team_tickets ADD COLUMN assignee_user_id INTEGER');
}
if (!in_array('status', $ticketColumns, true)) {
    $pdo->exec('ALTER TABLE team_tickets ADD COLUMN status TEXT NOT NULL DEFAULT "open"');
}
if (!in_array('completed_at', $ticketColumns, true)) {
    $pdo->exec('ALTER TABLE team_tickets ADD COLUMN completed_at DATETIME');
}
if (!in_array('estimated_minutes', $ticketColumns, true)) {
    $pdo->exec('ALTER TABLE team_tickets ADD COLUMN estimated_minutes INTEGER');
}
if (!in_array('actual_minutes', $ticketColumns, true)) {
    $pdo->exec('ALTER TABLE team_tickets ADD COLUMN actual_minutes INTEGER');
}

if (!in_array('estimated_minutes', $entryColumns, true)) {
    $pdo->exec('ALTER TABLE team_form_entries ADD COLUMN estimated_minutes INTEGER');
}
if (!in_array('actual_minutes', $entryColumns, true)) {
    $pdo->exec('ALTER TABLE team_form_entries ADD COLUMN actual_minutes INTEGER');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS task_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        note TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS task_creation_field_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        project_id INTEGER,
        field_key TEXT NOT NULL,
        is_visible INTEGER NOT NULL DEFAULT 1,
        is_required INTEGER NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(team_id, project_id, field_key),
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
    )'
);


$pdo->exec(
    'CREATE TABLE IF NOT EXISTS task_custom_fields (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        field_key TEXT NOT NULL,
        label TEXT NOT NULL,
        field_type TEXT NOT NULL DEFAULT "text",
        options_json TEXT,
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(team_id, field_key),
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$taskColumns = $pdo->query('PRAGMA table_info(tasks)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('custom_fields_json', $taskColumns, true)) {
    $pdo->exec('ALTER TABLE tasks ADD COLUMN custom_fields_json TEXT');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS app_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        event_type TEXT NOT NULL,
        description TEXT NOT NULL,
        context_json TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_raffle_prizes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_number INTEGER NOT NULL,
        title TEXT NOT NULL,
        image_path TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        removed_at DATETIME,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_raffle_draws (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        selected_group INTEGER NOT NULL,
        winning_group INTEGER NOT NULL,
        prize_id INTEGER,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(prize_id) REFERENCES hr_raffle_prizes(id) ON DELETE SET NULL,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS task_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        uploaded_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE,
        FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_ticket_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER NOT NULL,
        note TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(ticket_id) REFERENCES team_tickets(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_ticket_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        uploaded_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(ticket_id) REFERENCES team_tickets(id) ON DELETE CASCADE,
        FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_recurring_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        project_id INTEGER,
        assignee_user_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        weekday INTEGER,
        recurrence_type TEXT NOT NULL DEFAULT "weekly",
        start_date DATE,
        time_of_day TEXT,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL,
        FOREIGN KEY(assignee_user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_recurring_task_completions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        recurring_task_id INTEGER NOT NULL,
        occurrence_date DATE NOT NULL,
        completed_by INTEGER NOT NULL,
        completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(recurring_task_id) REFERENCES team_recurring_tasks(id) ON DELETE CASCADE,
        FOREIGN KEY(completed_by) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(recurring_task_id, occurrence_date)
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_recurring_task_statuses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        recurring_task_id INTEGER NOT NULL,
        occurrence_date DATE NOT NULL,
        status TEXT NOT NULL DEFAULT "todo",
        updated_by INTEGER NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(recurring_task_id) REFERENCES team_recurring_tasks(id) ON DELETE CASCADE,
        FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(recurring_task_id, occurrence_date)
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_recurring_task_overrides (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        recurring_task_id INTEGER NOT NULL,
        occurrence_date DATE NOT NULL,
        project_id INTEGER,
        assignee_user_id INTEGER,
        title TEXT NOT NULL,
        description TEXT,
        time_of_day TEXT,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(recurring_task_id) REFERENCES team_recurring_tasks(id) ON DELETE CASCADE,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL,
        FOREIGN KEY(assignee_user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(recurring_task_id, occurrence_date)
    )'
);

$recurringColumns = $pdo->query('PRAGMA table_info(team_recurring_tasks)')->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('recurrence_type', $recurringColumns, true)) {
    $pdo->exec('ALTER TABLE team_recurring_tasks ADD COLUMN recurrence_type TEXT NOT NULL DEFAULT "weekly"');
}
if (!in_array('start_date', $recurringColumns, true)) {
    $pdo->exec('ALTER TABLE team_recurring_tasks ADD COLUMN start_date DATE');
}
if (!in_array('project_id', $recurringColumns, true)) {
    $pdo->exec('ALTER TABLE team_recurring_tasks ADD COLUMN project_id INTEGER');
}
if (!in_array('assignee_user_id', $recurringColumns, true)) {
    $pdo->exec('ALTER TABLE team_recurring_tasks ADD COLUMN assignee_user_id INTEGER');
}
if (!in_array('checklist_template_id', $recurringColumns, true)) {
    $pdo->exec('ALTER TABLE team_recurring_tasks ADD COLUMN checklist_template_id INTEGER');
}
if (in_array('weekday', $recurringColumns, true)) {
    gt_bootstrap_repair($pdo, 'UPDATE team_recurring_tasks SET weekday = NULL WHERE weekday NOT BETWEEN 1 AND 7');
}

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_recurring_task_checklist_states (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        recurring_task_id INTEGER NOT NULL,
        occurrence_date DATE NOT NULL,
        checklist_state_json TEXT NOT NULL,
        updated_by INTEGER NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(recurring_task_id) REFERENCES team_recurring_tasks(id) ON DELETE CASCADE,
        FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(recurring_task_id, occurrence_date)
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_form_entry_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER NOT NULL,
        note TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(entry_id) REFERENCES team_form_entries(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_form_entry_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_id INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        uploaded_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(entry_id) REFERENCES team_form_entries(id) ON DELETE CASCADE,
        FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);


$pdo->exec(
    'CREATE TABLE IF NOT EXISTS project_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        uploaded_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
        FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS project_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        note TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS project_note_replies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_note_id INTEGER NOT NULL,
        reply TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(project_note_id) REFERENCES project_notes(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS team_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        note TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
    )'
);



$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_evaluation_rule_sets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        code TEXT,
        award_year INTEGER NOT NULL,
        profile_key TEXT NOT NULL,
        department_group_id INTEGER,
        department_id INTEGER,
        is_active INTEGER NOT NULL DEFAULT 1,
        priority INTEGER NOT NULL DEFAULT 100,
        notes TEXT,
        config_json TEXT NOT NULL,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_evaluations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        user_number TEXT,
        user_name TEXT NOT NULL,
        department_id INTEGER,
        department_name TEXT,
        award_profile TEXT NOT NULL,
        rule_set_id INTEGER,
        rule_set_name TEXT,
        award_year INTEGER NOT NULL,
        award_period TEXT NOT NULL,
        interview_date TEXT,
        performance_score INTEGER NOT NULL DEFAULT 0,
        performance_value REAL NOT NULL DEFAULT 0,
        performance_notes TEXT,
        behavior_score INTEGER NOT NULL DEFAULT 0,
        behavior_value REAL NOT NULL DEFAULT 0,
        behavior_notes TEXT,
        punctuality_count INTEGER NOT NULL DEFAULT 0,
        punctuality_value REAL NOT NULL DEFAULT 0,
        punctuality_notes TEXT,
        absence_count INTEGER NOT NULL DEFAULT 0,
        absence_value REAL NOT NULL DEFAULT 0,
        absence_notes TEXT,
        period_total REAL NOT NULL DEFAULT 0,
        max_period_total REAL NOT NULL DEFAULT 0,
        period_gap REAL NOT NULL DEFAULT 0,
        general_notes TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME,
        UNIQUE(user_id, award_year, award_period)
    )'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS hr_evaluation_year_closures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        user_number TEXT,
        user_name TEXT NOT NULL,
        department_id INTEGER,
        department_name TEXT,
        award_profile TEXT NOT NULL,
        rule_set_id INTEGER,
        rule_set_name TEXT,
        award_year INTEGER NOT NULL,
        final_absence_count INTEGER NOT NULL DEFAULT 0,
        final_bonus_value REAL NOT NULL DEFAULT 0,
        year_periods_total REAL NOT NULL DEFAULT 0,
        year_total_with_bonus REAL NOT NULL DEFAULT 0,
        max_year_total REAL NOT NULL DEFAULT 0,
        year_gap REAL NOT NULL DEFAULT 0,
        final_notes TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME,
        UNIQUE(user_id, award_year)
    )'
);

if (!taskforce_sqlite_index_exists($pdo, 'idx_hr_eval_rules_scope')) {
    $pdo->exec('CREATE INDEX idx_hr_eval_rules_scope ON hr_evaluation_rule_sets(award_year, profile_key, is_active, priority, id)');
}
if (!taskforce_sqlite_index_exists($pdo, 'idx_hr_eval_rules_department')) {
    $pdo->exec('CREATE INDEX idx_hr_eval_rules_department ON hr_evaluation_rule_sets(department_id, department_group_id)');
}
if (!taskforce_sqlite_index_exists($pdo, 'idx_hr_evaluations_user_year')) {
    $pdo->exec('CREATE INDEX idx_hr_evaluations_user_year ON hr_evaluations(user_id, award_year)');
}
if (!taskforce_sqlite_index_exists($pdo, 'idx_hr_year_closure_user_year')) {
    $pdo->exec('CREATE INDEX idx_hr_year_closure_user_year ON hr_evaluation_year_closures(user_id, award_year)');
}

$ruleSetsCount = (int) $pdo->query('SELECT COUNT(*) FROM hr_evaluation_rule_sets')->fetchColumn();
if ($ruleSetsCount === 0) {
    $seedYear = (int) date('Y');

    $defaultOperador = [
        'profile_key' => 'operador',
        'periods' => ['jan_abr' => 'Janeiro - Abril', 'mai_ago' => 'Maio - Agosto', 'set_dez' => 'Setembro - Dezembro'],
        'scores' => [
            'performance' => ['0' => 0, '1' => 12.5, '2' => 25, '3' => 0],
            'behavior' => ['0' => 0, '1' => 12.5, '2' => 25, '3' => 0],
        ],
        'counts' => [
            'punctuality' => ['zero_value' => 25, 'penalty_per_unit' => -2.5],
            'absence' => ['zero_value' => 50, 'penalty_per_unit' => -50],
            'final_absence_bonus' => ['0' => 250, '1' => 125, '2' => 62.5, '3_plus' => 0],
        ],
        'maximums' => ['period_total' => 125, 'year_total' => 625],
    ];

    $defaultResponsavel = [
        'profile_key' => 'responsavel_support',
        'periods' => ['jan_abr' => 'Janeiro - Abril', 'mai_ago' => 'Maio - Agosto', 'set_dez' => 'Setembro - Dezembro'],
        'scores' => [
            'performance' => ['0' => 0, '1' => 37.5, '2' => 75, '3' => 0],
            'behavior' => ['0' => 0, '1' => 12.5, '2' => 25, '3' => 0],
        ],
        'counts' => [
            'punctuality' => ['zero_value' => 50, 'penalty_per_unit' => -5],
            'absence' => ['zero_value' => 100, 'penalty_per_unit' => -100],
            'final_absence_bonus' => ['0' => 250, '1' => 125, '2' => 62.5, '3_plus' => 0],
        ],
        'maximums' => ['period_total' => 250, 'year_total' => 1000],
    ];

    $seedStmt = $pdo->prepare('INSERT INTO hr_evaluation_rule_sets(name, code, award_year, profile_key, department_group_id, department_id, priority, is_active, notes, config_json) VALUES (?, ?, ?, ?, NULL, NULL, 100, 1, ?, ?)');
    $seedStmt->execute(['Default Operadores', 'default_operador', $seedYear, 'operador', 'Seed automático inicial', json_encode($defaultOperador, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
    $seedStmt->execute(['Default Responsáveis / Support', 'default_responsavel_support', $seedYear, 'responsavel_support', 'Seed automático inicial', json_encode($defaultResponsavel, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
}


$timeStorageVersion = $pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key = ?');
$timeStorageVersion->execute(['time_storage_unit_version']);
$currentTimeStorageVersion = $timeStorageVersion->fetchColumn();

if ($currentTimeStorageVersion === 'minutes') {
    gt_bootstrap_repair($pdo, 'UPDATE tasks SET estimated_minutes = estimated_minutes * 60 WHERE estimated_minutes IS NOT NULL');
    gt_bootstrap_repair($pdo, 'UPDATE tasks SET actual_minutes = actual_minutes * 60 WHERE actual_minutes IS NOT NULL');
    gt_bootstrap_repair($pdo, 'UPDATE team_tickets SET estimated_minutes = estimated_minutes * 60 WHERE estimated_minutes IS NOT NULL');
    gt_bootstrap_repair($pdo, 'UPDATE team_tickets SET actual_minutes = actual_minutes * 60 WHERE actual_minutes IS NOT NULL');
    gt_bootstrap_repair($pdo, 'UPDATE team_form_entries SET estimated_minutes = estimated_minutes * 60 WHERE estimated_minutes IS NOT NULL');
    gt_bootstrap_repair($pdo, 'UPDATE team_form_entries SET actual_minutes = actual_minutes * 60 WHERE actual_minutes IS NOT NULL');

    $timeStorageUpdateStmt = $pdo->prepare('UPDATE app_settings SET setting_value = ? WHERE setting_key = ?');
    $timeStorageUpdateStmt->execute(['seconds', 'time_storage_unit_version']);

    if ($timeStorageUpdateStmt->rowCount() === 0) {
        $timeStorageInsertStmt = $pdo->prepare('INSERT INTO app_settings(setting_key, setting_value) VALUES (?, ?)');

        try {
            $timeStorageInsertStmt->execute(['time_storage_unit_version', 'seconds']);
        } catch (PDOException $exception) {
            $timeStorageUpdateStmt->execute(['seconds', 'time_storage_unit_version']);
        }
    }
} elseif ($currentTimeStorageVersion === false || $currentTimeStorageVersion === null) {
    $timeStorageUpdateStmt = $pdo->prepare('UPDATE app_settings SET setting_value = ? WHERE setting_key = ?');
    $timeStorageUpdateStmt->execute(['seconds', 'time_storage_unit_version']);

    if ($timeStorageUpdateStmt->rowCount() === 0) {
        $timeStorageInsertStmt = $pdo->prepare('INSERT INTO app_settings(setting_key, setting_value) VALUES (?, ?)');

        try {
            $timeStorageInsertStmt->execute(['time_storage_unit_version', 'seconds']);
        } catch (PDOException $exception) {
            $timeStorageUpdateStmt->execute(['seconds', 'time_storage_unit_version']);
        }
    }
}

// Shared hosting nem sempre permite configurar cron. Nesses ambientes, o
// primeiro pedido web após a hora programada executa a cópia em segurança.
if (PHP_SAPI !== 'cli') {
    $backupServiceFile = __DIR__ . '/app/Services/BackupManager.php';
    // Uma publicação parcial nunca deve deixar toda a aplicação indisponível.
    // O require só é feito depois de confirmar que o novo serviço foi enviado.
    if (is_file($backupServiceFile) && is_readable($backupServiceFile)) {
        try {
            require_once $backupServiceFile;
            if (class_exists('BackupScheduler', false)) {
                BackupScheduler::runDue($pdo, __DIR__);
            }
        } catch (Throwable $backupSchedulerException) {
            error_log('[GesTisser] Falha no agendador web de backups: ' . $backupSchedulerException->getMessage());
        }
    }
}
