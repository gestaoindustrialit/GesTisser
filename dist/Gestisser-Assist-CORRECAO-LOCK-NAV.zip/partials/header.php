<?php
$bootstrapPath = dirname(__DIR__) . '/bootstrap/app.php';
if (is_file($bootstrapPath)) {
    require_once $bootstrapPath;
} else {
    $helpersPath = dirname(__DIR__) . '/helpers.php';
    if (!is_file($helpersPath)) {
        $helpersPath = __DIR__ . '/helpers.php';
    }
    require_once $helpersPath;
}
if (app_config('env') === 'test' && !headers_sent()) {
    header('X-Robots-Tag: noindex, nofollow, noarchive');
}
$user = current_user($pdo);
$assistNav = null;
if ($user && is_file(dirname(__DIR__).'/app/Services/AssistService.php') && $pdo->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='assist_settings'")->fetchColumn()) {
    require_once dirname(__DIR__).'/app/Services/AssistService.php';
    $assistNav = AssistService::fromSession($pdo,$user);
}
$navbarLogo = app_setting($pdo, 'logo_navbar_light');
$showHrMenu = $user && ((int) ($user['is_admin'] ?? 0) === 1 || (string) ($user['access_profile'] ?? '') === 'RH');
$showBiMenu = $user && (int)($user['is_admin'] ?? 0) === 1;
$showCrmMenu = $user && (int) ($user['crm_enabled'] ?? 1) === 1 && (int) ($user['pin_only_login'] ?? 0) !== 1 && (int)($user['is_admin'] ?? 0) === 1;
if ($user && !$showBiMenu) {
    if (function_exists('gt_erp_user_can')) {
        $showBiMenu = gt_erp_user_can($pdo, $user, 'erp.bi.view');
    } else {
        $biPermissionTable = $pdo->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='erp_user_permissions'")->fetchColumn();
        if ($biPermissionTable) {
            $biPermission = $pdo->prepare('SELECT COALESCE((SELECT is_allowed FROM erp_user_permissions WHERE user_id=? AND permission_code="erp.bi.view"),(SELECT 1 FROM erp_role_permissions WHERE profile=? AND permission_code="erp.bi.view"))');
            $biPermission->execute([(int)$user['id'], (string)($user['access_profile'] ?? '')]);
            $showBiMenu = (int)$biPermission->fetchColumn() === 1;
        }
    }
}
if ($user && (int) ($user['crm_enabled'] ?? 1) === 1 && (int) ($user['pin_only_login'] ?? 0) !== 1 && !$showCrmMenu) {
    if (function_exists('gt_erp_user_can')) {
        $showCrmMenu = gt_erp_user_can($pdo, $user, 'crm.view');
    } else {
        $crmPermissionTable = $pdo->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='erp_user_permissions'")->fetchColumn();
        if ($crmPermissionTable) {
            $crmPermission = $pdo->prepare('SELECT COALESCE((SELECT is_allowed FROM erp_user_permissions WHERE user_id=? AND permission_code="crm.view"),(SELECT 1 FROM erp_role_permissions WHERE profile=? AND permission_code="crm.view"))');
            $crmPermission->execute([(int)$user['id'], (string)($user['access_profile'] ?? '')]);
            $showCrmMenu = (int)$crmPermission->fetchColumn() === 1;
        }
    }
}
$navbarCrmReminderCount = 0;
if ($user && $showCrmMenu) {
    $crmActivitiesTable = $pdo->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='crm_activities'")->fetchColumn();
    if ($crmActivitiesTable) {
        $crmReminderStmt = $pdo->prepare('SELECT COUNT(*) FROM crm_activities WHERE assigned_to=? AND status="PENDING" AND (due_datetime<=datetime("now","+1 day") OR reminder_datetime<=datetime("now"))');
        $crmReminderStmt->execute([(int)$user['id']]);
        $navbarCrmReminderCount = (int)$crmReminderStmt->fetchColumn();
    }
}
$isShopfloorOnlyNavigation = $user && has_shopfloor_only_navigation($user);
$isPinLogin = $user && (string) ($_SESSION['login_mode'] ?? '') === 'pin';

if ($user && !isset($navbarClockControl)) {
    // Keep navbar query variables isolated from the page that includes this partial.
    // Shopfloor also uses $todayEntries to render the complete daily history.
    $navbarTodayEntriesStmt = $pdo->prepare('SELECT entry_type, occurred_at AS occurred_at_local FROM shopfloor_time_entries WHERE user_id = ? AND date(occurred_at) = date("now") ORDER BY occurred_at DESC');
    $navbarTodayEntriesStmt->execute([(int) $user['id']]);
    $navbarTodayEntries = $navbarTodayEntriesStmt->fetchAll(PDO::FETCH_ASSOC);

    $latestTodayEntry = $navbarTodayEntries[0] ?? null;
    $nextEntryType = $latestTodayEntry && (($latestTodayEntry['entry_type'] ?? '') === 'entrada') ? 'saida' : 'entrada';
    $clockButtonLabel = $nextEntryType === 'entrada' ? 'Ponto de entrada' : 'Ponto de saída';
    $clockButtonClass = $nextEntryType === 'entrada' ? 'btn-primary' : 'btn-outline-light';
    $latestEntryTimeLabel = null;

    if ($latestTodayEntry && !empty($latestTodayEntry['occurred_at_local'])) {
        $latestTimestamp = strtotime((string) $latestTodayEntry['occurred_at_local']);
        if ($latestTimestamp !== false) {
            $latestEntryTimeLabel = sprintf(
                '%s às %s',
                (($latestTodayEntry['entry_type'] ?? '') === 'entrada') ? 'Entrada' : 'Saída',
                date('H:i', $latestTimestamp)
            );
        }
    }

    $navbarClockControl = [
        'form_action' => 'shopfloor.php',
        'entry_type' => $nextEntryType,
        'button_label' => $clockButtonLabel,
        'button_class' => $clockButtonClass,
        'latest_time_label' => $latestEntryTimeLabel,
    ];

    $activeBreakStmt = $pdo->prepare('SELECT b.id, b.break_reason_id, b.started_at, b.comment, r.code, r.label, r.break_type, r.requires_comment, CAST((julianday(CURRENT_TIMESTAMP) - julianday(b.started_at)) * 86400 AS INTEGER) AS elapsed_seconds FROM shopfloor_break_entries b INNER JOIN shopfloor_break_reasons r ON r.id = b.break_reason_id WHERE b.user_id = ? AND b.ended_at IS NULL ORDER BY b.started_at DESC LIMIT 1');
    $activeBreakStmt->execute([(int) $user['id']]);
    $activeBreak = $activeBreakStmt->fetch(PDO::FETCH_ASSOC) ?: null;

    $breakReasonOptionsStmt = $pdo->query('SELECT id, code, label, break_type, requires_comment FROM shopfloor_break_reasons WHERE is_active = 1 ORDER BY code COLLATE NOCASE ASC');
    $breakReasonOptions = $breakReasonOptionsStmt ? $breakReasonOptionsStmt->fetchAll(PDO::FETCH_ASSOC) : [];
    $navbarBreakControl = [
        'form_action' => 'shopfloor.php',
        'active_break' => $activeBreak,
        'reason_options' => $breakReasonOptions,
    ];
}

$currentFile = basename((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH));
if ($currentFile === '') {
    $currentFile = basename((string) ($_SERVER['PHP_SELF'] ?? ''));
}
$currentErpPage = trim((string) ($_GET['page'] ?? 'overview'));
if ($currentErpPage === 'customer_profile') { $currentErpPage = 'sales'; }
if ($currentErpPage === 'article_profile') { $currentErpPage = 'articles'; }
$shopfloorUserNameParts = preg_split('/\s+/u', trim((string) ($user['name'] ?? ''))) ?: [];
$shopfloorUserShortName = $shopfloorUserNameParts !== []
    ? ($shopfloorUserNameParts[0] . (count($shopfloorUserNameParts) > 1 ? ' ' . $shopfloorUserNameParts[count($shopfloorUserNameParts) - 1] : ''))
    : 'Utilizador';
$shopfloorUserNumber = trim((string) ($user['user_number'] ?? ''));
$shopfloorUserLabel = trim($shopfloorUserNumber . ' · ' . $shopfloorUserShortName, ' ·');
$hrFiles = [
    'hr.php', 'users.php', 'hr_departments.php', 'hr_schedules.php', 'hr_calendar.php',
    'hr_bank.php', 'hr_absences.php', 'hr_vacations.php', 'hr_alerts.php',
    'hr_evaluations.php', 'hr_evaluation_rules.php', 'hr_evaluation_history.php',
    'resultados.php', 'shopfloor_absence_reasons.php', 'shopfloor_break_reasons.php',
    'shopfloor_break_dashboard.php', 'hr_raffle.php', 'hr_organogram.php', 'hr_job_descriptions.php', 'hr_skills.php', 'payroll.php'
];
$adminFiles = ['assist_admin.php','sharepoint_settings.php', 'company_profile.php', 'erp_settings.php', 'requests.php', 'checklists.php', 'app_logs.php', 'backups.php', 'integrations.php', 'integration_edit.php', 'integration_flow_edit.php', 'integration_logs.php'];
$isCurrentFile = static function ($file) use ($currentFile) {
    return $currentFile === $file;
};
$isCurrentGroup = static function (array $files) use ($currentFile) {
    return in_array($currentFile, $files, true);
};
$gtHasAuthenticatedShell = !empty($user);
$resolvedBodyClass = trim('gt-body ' . (isset($bodyClass) ? (string) $bodyClass : 'bg-light') . ($gtHasAuthenticatedShell ? ' gt-authenticated' : ' gt-guest') . ($isPinLogin ? ' gt-pin-login' : ''));

header('Content-Type: text/html; charset=UTF-8');
?>
<!doctype html>
<html lang="pt-PT">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#212124">
    <title><?= isset($pageTitle) ? h($pageTitle) . ' · ' : '' ?>gesTISSER</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/styles.css?v=<?= h((string) (@filemtime(dirname(__DIR__) . '/assets/styles.css') ?: '1')) ?>" rel="stylesheet">
    <link href="assets/searchable-select.css?v=<?= h((string) (@filemtime(dirname(__DIR__) . '/assets/searchable-select.css') ?: '1')) ?>" rel="stylesheet">
    <link href="assets/mapper-theme.css?v=<?= h((string) (@filemtime(dirname(__DIR__) . '/assets/mapper-theme.css') ?: '1')) ?>" rel="stylesheet">
    <?php if (app_config('env') === 'test'): ?><meta name="robots" content="noindex,nofollow,noarchive"><?php endif; ?>
</head>
<body class="<?= h($resolvedBodyClass) ?>">
<?php if (app_config('env') === 'test'): ?>
<div class="alert alert-warning rounded-0 text-center fw-bold mb-0 py-2" role="status">AMBIENTE DE TESTE — emails, tarefas automáticas e integrações externas desativados</div>
<?php endif; ?>
<?php if ($user): ?>
<div class="gt-app-shell<?= $isPinLogin ? ' gt-pin-session' : '' ?>">
    <?php if (!$isPinLogin): ?>
    <aside class="gt-sidebar" id="gtSidebar" aria-label="Navegação principal">
        <div class="gt-brand">
            <a class="gt-brand-logo-shell" href="<?= h($isShopfloorOnlyNavigation ? route_url('shopfloor', 'shopfloor.php') : route_url('home', 'dashboard.php')) ?>" aria-label="Abrir página inicial">
                <?php if ($navbarLogo): ?>
                    <img src="<?= h($navbarLogo) ?>" alt="Logótipo empresa" class="gt-brand-logo">
                <?php else: ?>
                    <span class="gt-brand-monogram">T</span>
                    <strong>gesTISSER</strong>
                <?php endif; ?>
            </a>
            <span class="gt-brand-product">ERP e gestão industrial</span>
        </div>

        <nav class="gt-nav">
            <?php if ($isShopfloorOnlyNavigation): ?>
                <a class="gt-nav-link<?= $isCurrentFile('shopfloor.php') ? ' is-active' : '' ?>" href="<?= h(route_url('shopfloor', 'shopfloor.php')) ?>">
                    <i class="bi bi-speedometer2"></i><span>Shopfloor</span>
                </a>
                <?php if ($user && ((int)($user['is_admin']??0)===1 || (function_exists('gt_erp_user_can') && gt_erp_user_can($pdo,$user,'ink.prepare')))): ?>
                    <a class="gt-nav-link<?= $isCurrentFile('colorimetry.php') ? ' is-active' : '' ?>" href="colorimetry.php" data-ink-open><i class="bi bi-palette-fill"></i><span>Tintas / Cores</span></a>
                <?php endif; ?>
                <a class="gt-nav-link<?= $isCurrentFile('production_planning.php') ? ' is-active' : '' ?>" href="production_planning.php">
                    <i class="bi bi-display"></i><span>Plano de produção</span>
                </a>
            <?php else: ?>
                <a class="gt-nav-link<?= $isCurrentFile('dashboard.php') ? ' is-active' : '' ?>" href="<?= h(route_url('home', 'dashboard.php')) ?>">
                    <i class="bi bi-grid-1x2"></i><span>Visão geral</span>
                </a>
                <?php if ($showBiMenu): ?>
                    <a class="gt-nav-link<?= $isCurrentFile('business_intelligence.php') ? ' is-active' : '' ?>" href="business_intelligence.php">
                        <i class="bi bi-bar-chart-line"></i><span>Business Intelligence</span>
                    </a>
                <?php endif; ?>
                <?php if ($showCrmMenu): ?>
                    <details class="gt-nav-group"<?= $isCurrentFile('crm.php') ? ' open' : '' ?>>
                        <summary><span><i class="bi bi-bullseye"></i>CRM</span><i class="bi bi-chevron-down gt-nav-chevron"></i></summary>
                        <div class="gt-nav-submenu">
                            <?php foreach ([
                                'dashboard'=>['Dashboard','bi-grid-1x2'],'day'=>['Meu Dia','bi-sun'],'leads'=>['Leads','bi-person-plus'],'pipeline'=>['Pipeline','bi-kanban'],'customers'=>['Clientes','bi-buildings'],'contacts'=>['Contactos','bi-person-vcard'],'projects'=>['Projetos','bi-folder2-open'],'activities'=>['Atividades','bi-lightning'],'agenda'=>['Agenda','bi-calendar3'],'tasks'=>['Tarefas','bi-check2-square'],'reports'=>['Relatórios','bi-graph-up'],'settings'=>['Configurações','bi-gear']
                            ] as $crmView=>$crmItem): ?>
                                <a class="<?= $isCurrentFile('crm.php') && (string)($_GET['view']??'dashboard')===$crmView ? 'is-active' : '' ?>" href="crm.php?view=<?=h($crmView)?>"><i class="bi <?=h($crmItem[1])?>"></i><span><?=h($crmItem[0])?></span></a>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endif; ?>
                <a class="gt-nav-link<?= $isCurrentFile('shopfloor.php') ? ' is-active' : '' ?>" href="<?= h(route_url('shopfloor', 'shopfloor.php')) ?>">
                    <i class="bi bi-speedometer2"></i><span>Shopfloor</span>
                </a>
                <a class="gt-nav-link<?= $isCurrentFile('production_planning.php') ? ' is-active' : '' ?>" href="production_planning.php">
                    <i class="bi bi-display"></i><span>Plano de produção</span>
                </a>

                <details class="gt-nav-group"<?= ($isCurrentFile('erp.php') || $isCurrentFile('erp_operations.php') || $isCurrentFile('erp_routing.php')) ? ' open' : '' ?>>
                    <summary><span><i class="bi bi-boxes"></i>ERP industrial</span><i class="bi bi-chevron-down gt-nav-chevron"></i></summary>
                    <div class="gt-nav-submenu">
                        <?php
                        $erpMenuItems = [
                            'overview' => ['label' => 'Visão geral ERP', 'icon' => 'bi-grid'],
                            'sales' => ['label' => 'Clientes', 'icon' => 'bi-people'],
                            'purchases' => ['label' => 'Fornecedores', 'icon' => 'bi-cart3'],
                            'orders' => ['label' => 'Compras a fornecedores', 'icon' => 'bi-cart-check'],
                            'sales_orders' => ['label' => 'Encomendas de clientes', 'icon' => 'bi-bag-check'],
                            'production' => ['label' => 'Planeamento e produção', 'icon' => 'bi-calendar3'],
                            'articles' => ['label' => 'Artigos', 'icon' => 'bi-box-seam'],
                            'raw_materials' => ['label' => 'Matérias-primas', 'icon' => 'bi-stack'],
                            'warehouse' => ['label' => 'Armazém e stock', 'icon' => 'bi-building'],
                            'machines' => ['label' => 'Máquinas e equipamentos', 'icon' => 'bi-gear-wide-connected'],
                            'operations' => ['label' => 'Operações', 'icon' => 'bi-diagram-3'],
                        ];
                        ?>
                        <?php foreach ($erpMenuItems as $erpKey => $erpItem): ?>
                            <a class="<?= $isCurrentFile('erp.php') && $currentErpPage === $erpKey ? 'is-active' : '' ?>" href="<?= $erpKey === 'overview' ? h(route_url('erp', 'erp.php')) : ($erpKey === 'operations' ? 'erp_operations.php' : 'erp.php?page=' . h($erpKey)) ?>"><i class="bi <?= h($erpItem['icon']) ?>" aria-hidden="true"></i><span><?= h($erpItem['label']) ?></span></a>
                        <?php endforeach; ?>
                    </div>
                </details>

                <?php if ($showHrMenu): ?>
                    <details class="gt-nav-group"<?= $isCurrentGroup($hrFiles) ? ' open' : '' ?>>
                        <summary><span><i class="bi bi-people"></i>Recursos humanos</span><i class="bi bi-chevron-down gt-nav-chevron"></i></summary>
                        <div class="gt-nav-submenu">
                            <a class="<?= $isCurrentFile('hr.php') ? 'is-active' : '' ?>" href="hr.php"><i class="bi bi-grid" aria-hidden="true"></i><span>Visão geral RH</span></a>
                            <span class="gt-nav-label">Gestão base</span>
                            <a class="<?= $isCurrentFile('users.php') ? 'is-active' : '' ?>" href="users.php"><i class="bi bi-person" aria-hidden="true"></i><span>Utilizadores</span></a>
                            <a class="<?= $isCurrentFile('hr_schedules.php') ? 'is-active' : '' ?>" href="hr_schedules.php"><i class="bi bi-clock" aria-hidden="true"></i><span>Horários</span></a>
                            <a class="<?= $isCurrentFile('hr_departments.php') ? 'is-active' : '' ?>" href="hr_departments.php"><i class="bi bi-building" aria-hidden="true"></i><span>Departamentos</span></a>
                            <a class="<?= $isCurrentFile('hr_organogram.php') ? 'is-active' : '' ?>" href="hr_organogram.php"><i class="bi bi-diagram-3" aria-hidden="true"></i><span>Organograma</span></a>
                            <a class="<?= $isCurrentFile('hr_skills.php') ? 'is-active' : '' ?>" href="hr_skills.php"><i class="bi bi-stars" aria-hidden="true"></i><span>Matriz de competências</span></a>
                            <a class="<?= $isCurrentFile('hr_job_descriptions.php') ? 'is-active' : '' ?>" href="hr_job_descriptions.php"><i class="bi bi-journal-text" aria-hidden="true"></i><span>Cadernos de encargos</span></a>
                            <span class="gt-nav-label">Operação diária</span>
                            <a class="<?= $isCurrentFile('hr_calendar.php') ? 'is-active' : '' ?>" href="hr_calendar.php"><i class="bi bi-calendar3" aria-hidden="true"></i><span>Calendário</span></a>
                            <a class="<?= $isCurrentFile('hr_absences.php') ? 'is-active' : '' ?>" href="hr_absences.php"><i class="bi bi-person-dash" aria-hidden="true"></i><span>Ausências</span></a>
                            <a class="<?= $isCurrentFile('hr_vacations.php') ? 'is-active' : '' ?>" href="hr_vacations.php"><i class="bi bi-sun" aria-hidden="true"></i><span>Férias</span></a>
                            <a class="<?= $isCurrentFile('hr_bank.php') ? 'is-active' : '' ?>" href="hr_bank.php"><i class="bi bi-hourglass-split" aria-hidden="true"></i><span>Banco de horas</span></a>
                            <a class="<?= $isCurrentFile('hr_alerts.php') ? 'is-active' : '' ?>" href="hr_alerts.php"><i class="bi bi-bell" aria-hidden="true"></i><span>Alertas RH</span></a>
                            <a class="<?= $isCurrentFile('resultados.php') ? 'is-active' : '' ?>" href="resultados.php"><i class="bi bi-graph-up-arrow" aria-hidden="true"></i><span>Resultados</span></a>
                            <a class="<?= $isCurrentFile('shopfloor_break_dashboard.php') ? 'is-active' : '' ?>" href="shopfloor_break_dashboard.php"><i class="bi bi-pie-chart" aria-hidden="true"></i><span>Dashboard de pausas</span></a>
                            <a class="<?= $isCurrentFile('payroll.php') ? 'is-active' : '' ?>" href="payroll.php"><i class="bi bi-file-earmark-arrow-down" aria-hidden="true"></i><span>Export Payroll</span></a>
                            <a class="<?= $isCurrentFile('shopfloor_break_reasons.php') ? 'is-active' : '' ?>" href="shopfloor_break_reasons.php"><i class="bi bi-cup-hot" aria-hidden="true"></i><span>Pausas e paragens</span></a>
                            <a class="<?= $isCurrentFile('shopfloor_absence_reasons.php') ? 'is-active' : '' ?>" href="shopfloor_absence_reasons.php"><i class="bi bi-card-list" aria-hidden="true"></i><span>Motivos de ausência</span></a>
                            <a class="<?= $isCurrentFile('hr_evaluation_rules.php') ? 'is-active' : '' ?>" href="hr_evaluation_rules.php"><i class="bi bi-sliders" aria-hidden="true"></i><span>Regras de avaliação</span></a>
                        </div>
                    </details>
                <?php endif; ?>

                <?php if ((int) ($user['is_admin'] ?? 0) === 1): ?>
                    <details class="gt-nav-group"<?= $isCurrentGroup($adminFiles) ? ' open' : '' ?>>
                        <summary><span><i class="bi bi-sliders"></i>Administração</span><i class="bi bi-chevron-down gt-nav-chevron"></i></summary>
                        <div class="gt-nav-submenu">
                            <?php if ($assistNav && $assistNav->enabled() && $assistNav->can('assist.edit')): ?><a href="assist_admin.php" class="<?= $isCurrentFile('assist_admin.php')?'is-active':'' ?>"><i class="bi bi-chat-dots" aria-hidden="true"></i><span>SACO · Conhecimento</span></a><?php endif; ?>
                            <a class="<?= $isCurrentFile('company_profile.php') ? 'is-active' : '' ?>" href="company_profile.php"><i class="bi bi-buildings" aria-hidden="true"></i><span>Empresa e branding</span></a>
                            <a class="<?= $isCurrentFile('erp_settings.php') ? 'is-active' : '' ?>" href="erp_settings.php"><i class="bi bi-gear" aria-hidden="true"></i><span>Configuração ERP</span></a>
                            <a class="<?= in_array($currentFile, ['integrations.php','sharepoint_settings.php','integration_edit.php','integration_flow_edit.php','integration_logs.php'], true) ? 'is-active' : '' ?>" href="integrations.php"><i class="bi bi-plug" aria-hidden="true"></i><span>Integrações</span></a>
                            <a class="<?= $isCurrentFile('requests.php') ? 'is-active' : '' ?>" href="requests.php"><i class="bi bi-ui-checks" aria-hidden="true"></i><span>Gerar formulários</span></a>
                            <a class="<?= $isCurrentFile('checklists.php') ? 'is-active' : '' ?>" href="checklists.php"><i class="bi bi-list-check" aria-hidden="true"></i><span>Checklists</span></a>
                            <a class="<?= $isCurrentFile('app_logs.php') ? 'is-active' : '' ?>" href="app_logs.php"><i class="bi bi-terminal" aria-hidden="true"></i><span>Logs da aplicação</span></a>
                            <a class="<?= $isCurrentFile('backups.php') ? 'is-active' : '' ?>" href="backups.php"><i class="bi bi-cloud-arrow-down" aria-hidden="true"></i><span>Backups</span></a>
                        </div>
                    </details>
                <?php endif; ?>
            <?php endif; ?>
        </nav>

        <div class="gt-sidebar-footer">
            <div class="gt-system-state"><span class="gt-status-dot"></span><span>Sistema operacional</span></div>
            <div class="gt-user-card">
                <div class="gt-user-avatar"><?= h(strtoupper(substr((string) ($user['name'] ?? 'U'), 0, 1))) ?></div>
                <div>
                    <strong><?= h((string) ($user['name'] ?? 'Utilizador')) ?></strong>
                    <small><?= (int) ($user['is_admin'] ?? 0) === 1 ? 'Administrador' : h((string) ($user['access_profile'] ?? 'Utilizador')) ?></small>
                </div>
            </div>
            <a class="gt-logout-link" href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Sair</span></a>
        </div>
    </aside>
    <button type="button" class="gt-sidebar-backdrop" data-gt-sidebar-close aria-label="Fechar menu"></button>
    <?php endif; ?>

    <div class="gt-main">
        <header class="gt-topbar">
            <?php if ($isPinLogin): ?>
                <a class="gt-pin-topbar-logo" href="<?= h(route_url('shopfloor', 'shopfloor.php')) ?>" aria-label="Abrir Shopfloor">
                    <?php if ($navbarLogo): ?>
                        <img src="<?= h($navbarLogo) ?>" alt="Logótipo empresa">
                    <?php else: ?>
                        <span class="gt-brand-monogram">T</span>
                        <strong>gesTISSER</strong>
                    <?php endif; ?>
                </a>
            <?php else: ?>
                <button type="button" class="gt-icon-button gt-mobile-menu" data-gt-sidebar-toggle aria-controls="gtSidebar" aria-expanded="false" aria-label="Abrir menu">
                    <i class="bi bi-list"></i>
                </button>
                <div class="gt-page-heading">
                    <p>Centro operacional</p>
                    <h1><?= h(isset($pageTitle) ? (string) $pageTitle : 'gesTISSER') ?></h1>
                </div>
            <?php endif; ?>
            <?php if (!empty($showProductionLabelShortcuts)): ?>
                <div class="d-flex gap-2 me-auto shopfloor-header-shortcuts" role="group" aria-label="Atalhos do Shopfloor">
                    <?php if ($currentFile === 'shopfloor.php' && isset($selectedWorkCenter)): ?>
                        <button type="button" class="btn btn-sm <?= $selectedWorkCenter ? 'btn-outline-primary' : 'btn-warning' ?> fw-semibold" data-bs-toggle="modal" data-bs-target="#workCenterModal" aria-label="<?= h($selectedWorkCenter ? 'Alterar centro de trabalho: ' . (string) $selectedWorkCenter['code'] . ' · ' . (string) $selectedWorkCenter['name'] : 'Escolher centro de trabalho') ?>" title="<?= h($selectedWorkCenter ? (string) $selectedWorkCenter['code'] . ' · ' . (string) $selectedWorkCenter['name'] : 'Escolher centro de trabalho') ?>">
                            <i class="bi bi-geo-alt-fill" aria-hidden="true"></i>
                        </button>
                    <?php endif; ?>
                    <button type="button" class="btn btn-sm btn-warning fw-semibold" data-bs-toggle="modal" data-bs-target="#productionLabelModal" aria-label="Etiquetas" title="Etiquetas">
                        <i class="bi bi-tags-fill" aria-hidden="true"></i>
                    </button>
                    <?php if (function_exists('gt_erp_user_can') && $user && gt_erp_user_can($pdo,$user,'ink.prepare')): ?>
                        <a class="btn btn-sm btn-warning fw-semibold" href="colorimetry.php" data-ink-open title="Tintas / Cores" aria-label="Tintas / Cores"><i class="bi bi-palette-fill" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if ($currentFile === 'shopfloor.php'): ?>
                        <button type="button" class="btn btn-sm btn-dark fw-semibold" data-bs-toggle="modal" data-bs-target="#shopfloorCalculatorModal" aria-label="Calculadora" title="Calculadora">
                            <i class="bi bi-calculator" aria-hidden="true"></i>
                        </button>
                        <?php if (!empty($articleArtwork)): ?>
                            <button type="button" class="btn btn-sm btn-outline-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#articleArtworkModal" aria-label="Previsualizar maquete" title="Previsualizar maquete">
                                <i class="bi bi-file-earmark-pdf" aria-hidden="true"></i>
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="gt-top-actions">
                <?php if ($assistNav && $assistNav->enabled() && $assistNav->can('assist.use')): ?>
                <button type="button" class="btn btn-sm btn-outline-primary" id="assist-nav-open" aria-label="Abrir SACO" title="Abrir SACO" aria-controls="assist-panel"><svg viewBox="0 0 64 64" width="36" height="36" aria-hidden="true"><path d="M22 16 17 7l12 3 13-3-5 9M23 16h14M24 20C17 28 9 39 12 50c2 8 38 8 40 0 3-11-5-22-12-30Z" fill="#fff" stroke="#084c8a" stroke-width="3"/><circle cx="26" cy="36" r="3"/><circle cx="38" cy="36" r="3"/><path d="M25 44q7 7 14 0" fill="none" stroke="#084c8a" stroke-width="3"/></svg></button>
                <?php endif; ?>
                <?php if ($showCrmMenu): ?>
                    <a class="btn btn-sm btn-outline-secondary position-relative" href="crm.php?view=day" aria-label="<?= $navbarCrmReminderCount ?> lembretes CRM">
                        <i class="bi bi-bell"></i><span class="d-none d-md-inline"> CRM</span>
                        <?php if ($navbarCrmReminderCount): ?><span class="position-absolute top-0 start-100 translate-middle badge rounded-pill text-bg-danger"><?= $navbarCrmReminderCount ?></span><?php endif; ?>
                    </a>
                <?php endif; ?>
                <?php if (isset($navbarClockControl) && is_array($navbarClockControl)): ?>
                    <form method="post" action="<?= h((string) ($navbarClockControl['form_action'] ?? 'shopfloor.php')) ?>" class="gt-clock-form">
                        <input type="hidden" name="action" value="clock_entry">
                        <input type="hidden" name="entry_type" value="<?= h((string) ($navbarClockControl['entry_type'] ?? 'entrada')) ?>">
                        <?php if (($navbarClockControl['entry_type'] ?? 'entrada') === 'saida'): ?><input type="hidden" name="stop_machine" value="0" data-stop-machine-field><?php endif; ?>
                        <button type="submit" class="btn btn-sm fw-semibold <?= h((string) ($navbarClockControl['button_class'] ?? 'btn-primary')) ?>">
                            <i class="bi bi-clock-history"></i>
                            <span><?= h((string) ($navbarClockControl['button_label'] ?? 'Ponto de entrada')) ?></span>
                        </button>
                        <?php if (!empty($navbarClockControl['latest_time_label'])): ?>
                            <small><?= h((string) $navbarClockControl['latest_time_label']) ?></small>
                        <?php endif; ?>
                    </form>
                <?php endif; ?>
                <?php if (isset($navbarBreakControl) && is_array($navbarBreakControl)): ?>
                    <?php $activeBreak = $navbarBreakControl['active_break'] ?? null; ?>
                    <button
                        type="button"
                        class="btn btn-sm fw-semibold <?= $activeBreak ? 'btn-danger' : 'btn-success' ?>"
                        data-bs-toggle="modal"
                        data-bs-target="#navbarBreakModal"
                    >
                        <i class="bi <?= $activeBreak ? 'bi-stop-circle' : 'bi-cup-hot' ?>"></i>
                        <span><?= $activeBreak ? 'Terminar pausa/paragem' : 'Iniciar pausa/paragem' ?></span>
                    </button>
                <?php endif; ?>
                <?php if ($currentFile === 'shopfloor.php' && $user): ?>
                    <div class="shopfloor-user-identity" aria-label="Utilizador atual">
                        <i class="bi bi-person-circle" aria-hidden="true"></i>
                        <span><?= h($shopfloorUserLabel) ?></span>
                    </div>
                    <a class="btn btn-sm btn-outline-secondary shopfloor-switch-user" href="logout.php?next=pin" aria-label="Trocar de utilizador" title="Trocar de utilizador">
                        <i class="bi bi-person-gear" aria-hidden="true"></i>
                    </a>
                <?php endif; ?>
                <div class="gt-top-user<?= $currentFile === 'shopfloor.php' ? ' d-none' : '' ?>">
                    <span><?= h((string) ($user['name'] ?? 'Utilizador')) ?></span>
                    <small><?= (int) ($user['is_admin'] ?? 0) === 1 ? 'Admin' : h((string) ($user['access_profile'] ?? 'Utilizador')) ?></small>
                </div>
            </div>
        </header>

<?php if (isset($navbarBreakControl) && is_array($navbarBreakControl)): ?>
    <?php $activeBreak = $navbarBreakControl['active_break'] ?? null; ?>
    <div
        class="modal fade"
        id="navbarBreakModal"
        tabindex="-1"
        aria-labelledby="navbarBreakModalLabel"
        aria-hidden="true"
        <?= $activeBreak ? 'data-bs-backdrop="static" data-bs-keyboard="false"' : '' ?>
        <?= $activeBreak ? ('data-break-started-at="' . h((string) ($activeBreak['started_at'] ?? '')) . '"') : '' ?>
        <?= $activeBreak ? ('data-break-elapsed-seconds="' . (int) ($activeBreak['elapsed_seconds'] ?? 0) . '"') : '' ?>
    >
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="post" action="<?= h((string) ($navbarBreakControl['form_action'] ?? 'shopfloor.php')) ?>">
                    <div class="modal-header">
                        <h2 class="modal-title fs-5" id="navbarBreakModalLabel"><?= $activeBreak ? 'Terminar pausa/paragem' : 'Iniciar pausa/paragem' ?></h2>
                        <?php if (!$activeBreak): ?>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                        <?php endif; ?>
                    </div>
                    <div class="modal-body">
                        <?php if ($activeBreak): ?>
                            <input type="hidden" name="action" value="stop_break">
                            <p class="mb-2"><strong><?= h((string) ($activeBreak['break_type'] ?? 'Pausa')) ?></strong> em curso: <?= h((string) ($activeBreak['code'] ?? '')) ?> | <?= h((string) ($activeBreak['label'] ?? '')) ?></p>
                            <p class="small text-secondary">Iniciada às <?= h(date('H:i', strtotime((string) ($activeBreak['started_at'] ?? 'now')))) ?>.</p>
                            <div class="display-5 fw-bold text-center text-danger mb-3" id="navbarBreakElapsed">00:00:00</div>
                            <div class="mb-2 <?= (int) ($activeBreak['requires_comment'] ?? 0) === 1 ? '' : 'd-none' ?>">
                                <label class="form-label">Comentário</label>
                                <textarea class="form-control" name="break_comment" rows="3" placeholder="Comentário obrigatório para terminar" <?= (int) ($activeBreak['requires_comment'] ?? 0) === 1 ? 'required' : '' ?>></textarea>
                            </div>
                        <?php else: ?>
                            <input type="hidden" name="action" value="start_break">
                            <div class="mb-3">
                                <label class="form-label">Tipo de pausa/paragem</label>
                                <select class="form-select" name="break_reason_id" id="navbarBreakReasonSelect" required>
                                    <option value="">Selecionar</option>
                                    <?php foreach (($navbarBreakControl['reason_options'] ?? []) as $breakReasonOption): ?>
                                        <option
                                            value="<?= (int) $breakReasonOption['id'] ?>"
                                            data-requires-comment="<?= (int) ($breakReasonOption['requires_comment'] ?? 0) ?>"
                                        >
                                            <?= h((string) $breakReasonOption['code']) ?> | <?= h((string) $breakReasonOption['label']) ?> (<?= h((string) $breakReasonOption['break_type']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-2 d-none" id="navbarBreakCommentWrap">
                                <label class="form-label">Comentário</label>
                                <textarea class="form-control" name="break_comment" id="navbarBreakComment" rows="3" placeholder="Opcional no início (pode completar antes de terminar)"></textarea>
                            </div>
                            <div class="form-check mt-3">
                                <input class="form-check-input" type="checkbox" name="stop_machine" value="1" id="navbarStopMachine" checked>
                                <label class="form-check-label" for="navbarStopMachine">Parar também o tempo de produção da máquina</label>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <?php if (!$activeBreak): ?>
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <?php endif; ?>
                        <button type="submit" class="btn fw-semibold <?= $activeBreak ? 'btn-danger' : 'btn-success' ?>">
                            <?= $activeBreak ? 'Terminar' : 'Iniciar' ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const modalElement = document.getElementById('navbarBreakModal');
            const reasonSelect = document.getElementById('navbarBreakReasonSelect');
            const commentWrap = document.getElementById('navbarBreakCommentWrap');
            const commentField = document.getElementById('navbarBreakComment');
            const elapsedElement = document.getElementById('navbarBreakElapsed');
            const clockExitForm = document.querySelector('.gt-clock-form [data-stop-machine-field]')?.form || null;
            let timerIntervalId = null;

            if (clockExitForm) {
                clockExitForm.addEventListener('submit', () => {
                    const stopMachineField = clockExitForm.querySelector('[data-stop-machine-field]');
                    if (stopMachineField) {
                        stopMachineField.value = window.confirm('Pretende parar também o tempo de produção da máquina?') ? '1' : '0';
                    }
                });
            }

            if (reasonSelect && commentWrap && commentField) {
                const syncCommentVisibility = () => {
                    const selectedOption = reasonSelect.options[reasonSelect.selectedIndex] || null;
                    const requiresComment = selectedOption ? selectedOption.getAttribute('data-requires-comment') === '1' : false;
                    commentWrap.classList.toggle('d-none', !requiresComment);
                    commentField.required = false;
                    if (!requiresComment) {
                        commentField.value = '';
                    }
                };

                reasonSelect.addEventListener('change', syncCommentVisibility);
                syncCommentVisibility();
            }

            if (modalElement && elapsedElement && modalElement.dataset.breakElapsedSeconds) {
                const initialElapsedSeconds = Math.max(0, Number.parseInt(modalElement.dataset.breakElapsedSeconds || '0', 10) || 0);
                const clientTimerStartedAt = Date.now();
                const formatSeconds = (seconds) => {
                    const safeSeconds = Math.max(0, seconds);
                    const hours = Math.floor(safeSeconds / 3600);
                    const minutes = Math.floor((safeSeconds % 3600) / 60);
                    const remainingSeconds = safeSeconds % 60;
                    return String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0') + ':' + String(remainingSeconds).padStart(2, '0');
                };

                const renderElapsed = () => {
                    const clientElapsedSeconds = Math.floor((Date.now() - clientTimerStartedAt) / 1000);
                    const elapsedSeconds = initialElapsedSeconds + Math.max(0, clientElapsedSeconds);
                    elapsedElement.textContent = formatSeconds(elapsedSeconds);
                };

                renderElapsed();
                timerIntervalId = window.setInterval(renderElapsed, 1000);

                const showActiveBreakModal = () => {
                    if (!window.bootstrap || !window.bootstrap.Modal) {
                        return;
                    }
                    const modalInstance = window.bootstrap.Modal.getOrCreateInstance(modalElement);
                    modalInstance.show();
                };

                showActiveBreakModal();
            }

            window.addEventListener('beforeunload', () => {
                if (timerIntervalId !== null) {
                    window.clearInterval(timerIntervalId);
                }
            });
        });
    </script>
<?php endif; ?>
        <main class="gt-content" id="gtMainContent">
<?php else: ?>
    <main class="gt-guest-main" id="gtMainContent">
<?php endif; ?>
