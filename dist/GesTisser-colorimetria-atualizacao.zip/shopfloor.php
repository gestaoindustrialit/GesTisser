<?php
require_once __DIR__.'/app/Services/CentralPrinting.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/app/Services/ShopfloorAttachment.php';
require_once __DIR__ . '/article_document.php';
require_once __DIR__ . '/app/Services/OperationChecklistService.php';
require_once __DIR__ . '/app/Services/ShopfloorDailyIndicators.php';
require_once __DIR__ . '/app/Services/OperationConsumptionService.php';
require_once __DIR__ . '/app/Services/ProductionOrderStatusService.php';
$validatedHourBankCalculatorPath = __DIR__ . '/app/Services/ValidatedHourBankCalculator.php';
if (is_file($validatedHourBankCalculatorPath)) {
    require_once $validatedHourBankCalculatorPath;
}
require_once __DIR__ . '/hr_organization_lib.php';
require_once __DIR__ . '/erp_migrations.php';
require_login();
gt_run_org_migrations($pdo);
gt_erp_run_phase1_migrations($pdo);
require_once __DIR__.'/app/Services/ColorimetryService.php';
ColorimetryService::migrate($pdo);

$userId = (int) $_SESSION['user_id'];
$operationChecklistService = new OperationChecklistService($pdo);
$operationConsumptionService = new OperationConsumptionService($pdo);
$user = current_user($pdo);
$profile = (string) ($user['access_profile'] ?? 'Utilizador');
$isAdmin = (int) ($user['is_admin'] ?? 0) === 1;
$isRh = $profile === 'RH';
$isChief = $profile === 'Chefias';
$canManageAnnouncements = $isAdmin || $isRh;

if (!$isAdmin && !in_array($profile, ['Utilizador', 'Produção', 'Chefias', 'RH'], true)) {
    http_response_code(403);
    exit('Acesso reservado aos perfis Utilizador, Produção, Chefias e RH.');
}

$flashSuccess = null;
$flashError = null;
$showClockEntryRequiredModal = false;
$workCentersStmt = $pdo->query(
    'SELECT wc.id, wc.code, wc.name, wc.center_type, wc.machine_id, wc.is_active,
            p.id AS printer_id, p.name AS printer_name, p.network_uri AS printer_uri
     FROM erp_work_centers wc
     LEFT JOIN erp_printers p ON p.id = wc.default_printer_id AND p.is_active = 1
     ORDER BY wc.is_active DESC, wc.code COLLATE NOCASE, wc.name COLLATE NOCASE'
);
$workCenters = $workCentersStmt ? $workCentersStmt->fetchAll(PDO::FETCH_ASSOC) : [];
$workCentersById = [];
foreach ($workCenters as $workCenterRow) {
    $workCentersById[(int) $workCenterRow['id']] = $workCenterRow;
}

/*
 * The workstation belongs to the physical browser/device, rather than to the
 * employee who happens to be signed in. JavaScript restores the device choice
 * from localStorage after every login and this action validates it server-side.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && trim((string) ($_POST['action'] ?? '')) === 'select_work_center') {
    validate_csrf_or_abort(true);
    $requestedWorkCenterId = (int) ($_POST['work_center_id'] ?? 0);
    if (!isset($workCentersById[$requestedWorkCenterId])) {
        $_SESSION['shopfloor_work_center_id'] = null;
        redirect('shopfloor.php?work_center_error=1');
    }

    $_SESSION['shopfloor_work_center_id'] = $requestedWorkCenterId;
    log_app_event($pdo, $userId, 'shopfloor.work_center.select', 'Centro de trabalho selecionado no dispositivo.', [
        'work_center_id' => $requestedWorkCenterId,
        'work_center_code' => (string) $workCentersById[$requestedWorkCenterId]['code'],
    ]);
    redirect('shopfloor.php?work_center_selected=1');
}

$selectedWorkCenterId = (int) ($_SESSION['shopfloor_work_center_id'] ?? 0);
if (!isset($workCentersById[$selectedWorkCenterId])) {
    $selectedWorkCenterId = 0;
    unset($_SESSION['shopfloor_work_center_id']);
}
$selectedWorkCenter = $selectedWorkCenterId > 0 ? $workCentersById[$selectedWorkCenterId] : null;
$selectedWorkCenterMachineId = (int) ($selectedWorkCenter['machine_id'] ?? 0);

if (($_GET['action'] ?? '') === 'lookup_stock_unit') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $unit=$operationConsumptionService->findUnit((string)($_GET['unit_type']??''),(string)($_GET['label_number']??''));
        if(!$unit){http_response_code(404);echo json_encode(['ok'=>false,'message'=>'Etiqueta não encontrada.']);}
        else echo json_encode(['ok'=>true,'unit'=>$unit],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    } catch(Throwable $exception){http_response_code(422);echo json_encode(['ok'=>false,'message'=>$exception->getMessage()],JSON_UNESCAPED_UNICODE);}
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'adjust_stock_label') {
    validate_csrf_or_abort(true);
    try {
        if (!gt_erp_user_can($pdo, $user ?: [], 'erp.shopfloor.execute')) throw new RuntimeException('Sem permissão para acertar quantidades no Shopfloor.');
        $unit = $operationConsumptionService->adjustUnit((string)($_POST['unit_type']??''), (string)($_POST['label_number']??''), (float)($_POST['weight_kg']??-1), (float)($_POST['metres']??-1), (float)($_POST['expected_weight']??-1), (float)($_POST['expected_metres']??-1), (string)($_POST['reason']??''), $userId, (string)($_POST['idempotency_key']??''));
        redirect(($unit['unit_type']==='ROLL'?'raw_material_roll_label.php?printed_label_id=':'raw_material_ink_label.php?label_id=').(int)$unit['id'].'&raw_material_id='.(int)$unit['raw_material_id'].'&print=1');
    } catch (Throwable $exception) { $flashError=$exception->getMessage(); }
    $_POST['action']='';
}

if (!function_exists('shopfloor_format_quantity')) {
    function shopfloor_format_quantity(float $quantity): string
    {
        return rtrim(rtrim(number_format($quantity, 3, ',', '.'), '0'), ',');
    }
}

if (!function_exists('shopfloor_productivity_percentage')) {
    /**
     * Compares the actual production rate with the rate planned for the OF.
     * A value of 100 means that the quantity produced in the elapsed interval
     * is exactly the quantity expected for that same interval.
     */
    function shopfloor_productivity_percentage(float $goodQuantity, float $plannedQuantity, float $actualMinutes, float $plannedMinutes)
    {
        if ($plannedQuantity <= 0 || $actualMinutes <= 0 || $plannedMinutes <= 0) {
            return null;
        }

        return min(200, ($goodQuantity * $plannedMinutes) / ($plannedQuantity * $actualMinutes) * 100);
    }
}

if (!function_exists('shopfloor_operation_can_run_at_work_center')) {
    /**
     * An operation belongs at a workstation either through its assigned work
     * center or through one of its compatible (alternative) machines.
     */
    function shopfloor_operation_can_run_at_work_center(array $operation, int $workCenterId, int $workCenterMachineId): bool
    {
        if ($workCenterId <= 0) {
            return false;
        }
        $allowedWorkCenterIds = json_decode((string) ($operation['allowed_work_center_ids_json'] ?? '[]'), true);
        if (is_array($allowedWorkCenterIds) && in_array($workCenterId, array_map('intval', $allowedWorkCenterIds), true)) {
            return true;
        }
        // Backward compatibility for OFs released before multiple start stations.
        if ((int) ($operation['work_center_id'] ?? 0) === $workCenterId) {
            return true;
        }
        if ($workCenterMachineId <= 0 || (int) ($operation['machine_required'] ?? 1) !== 1) {
            return false;
        }
        $allowedMachineIds = json_decode((string) ($operation['allowed_machine_ids_json'] ?? '[]'), true);
        return is_array($allowedMachineIds)
            && in_array($workCenterMachineId, array_map('intval', $allowedMachineIds), true);
    }
}
$sessionLoginAt = trim((string) ($_SESSION['login_at'] ?? ''));
$todayLocalDate = date('Y-m-d');
$latestClockEntryTodayStmt = $pdo->prepare('SELECT entry_type FROM shopfloor_time_entries WHERE user_id = ? AND date(occurred_at) = ? ORDER BY occurred_at DESC, id DESC LIMIT 1');
$latestClockEntryTodayStmt->execute([$userId, $todayLocalDate]);
$latestClockEntryToday = (string) ($latestClockEntryTodayStmt->fetchColumn() ?: '');
$hasOpenClockEntryToday = $latestClockEntryToday === 'entrada';
if (isset($_GET['announcement_ack_required'])) {
    $flashError = 'Tem de validar o conhecimento do comunicado pendente para continuar.';
}
if (isset($_GET['work_center_error'])) {
    $flashError = 'O centro de trabalho guardado neste dispositivo já não está disponível. Selecione outro posto.';
}
if (isset($_GET['work_center_selected'])) {
    $flashSuccess = 'Centro de trabalho definido para este dispositivo.';
}

if (!function_exists('shopfloor_parse_absence_code')) {
    function shopfloor_parse_absence_code(string $reason): string
    {
        if (preg_match('/·\s*([A-Z0-9\-]+)\s*-/', $reason, $matches)) {
            return normalize_sage_code((string) ($matches[1] ?? ''));
        }

        return '';
    }
}

if (!function_exists('shopfloor_should_exclude_absence_credit')) {
    function shopfloor_should_exclude_absence_credit(string $absenceCode): bool
    {
        $normalized = preg_replace('/\D+/', '', $absenceCode) ?? '';
        return $normalized === '100';
    }
}

if (!function_exists('shopfloor_resolve_absence_minutes')) {
    function shopfloor_resolve_absence_minutes(array $absence, int $targetMinutes): int
    {
        $durationType = trim((string) ($absence['duration_type'] ?? 'Completa'));
        if ($durationType === 'Parcial') {
            return (int) round($targetMinutes / 2);
        }

        if ($durationType === 'Horas') {
            $hoursValue = trim((string) ($absence['duration_hours'] ?? ''));
            if (preg_match('/^(\d{1,2}):(\d{2})$/', $hoursValue, $matches)) {
                $minutes = (((int) $matches[1]) * 60) + (int) $matches[2];
                return max(0, min($targetMinutes, $minutes));
            }
        }

        return $targetMinutes;
    }
}

if (!function_exists('shopfloor_pause_active_operation')) {
    /** Stop the employee's production clock without completing the operation. */
    function shopfloor_pause_active_operation(PDO $pdo, int $userId, string $reason): bool
    {
        $entryStmt = $pdo->prepare('SELECT id FROM erp_operation_time_entries WHERE user_id = ? AND ended_at IS NULL AND status <> "paused" ORDER BY started_at DESC LIMIT 1');
        $entryStmt->execute([$userId]);
        $entryId = (int) ($entryStmt->fetchColumn() ?: 0);
        if ($entryId <= 0) {
            return false;
        }

        $pdo->prepare('UPDATE erp_operation_time_entries SET status = "paused", paused_at = CURRENT_TIMESTAMP WHERE id = ? AND ended_at IS NULL AND status <> "paused"')->execute([$entryId]);
        $pdo->prepare('INSERT INTO erp_operation_stoppages(time_entry_id, reason, created_by) VALUES (?, ?, ?)')->execute([$entryId, $reason, $userId]);
        return true;
    }
}

if (!function_exists('shopfloor_resume_operation')) {
    /** Resume an entry and close the matching automatically-created stoppage. */
    function shopfloor_resume_operation(PDO $pdo, int $entryId, int $userId): bool
    {
        $stmt = $pdo->prepare('UPDATE erp_operation_time_entries SET status = "running", pause_seconds = pause_seconds + CASE WHEN paused_at IS NOT NULL THEN CAST((julianday(CURRENT_TIMESTAMP) - julianday(paused_at)) * 86400 AS INTEGER) ELSE 0 END, paused_at = NULL WHERE id = ? AND user_id = ? AND ended_at IS NULL AND status = "paused"');
        $stmt->execute([$entryId, $userId]);
        if ($stmt->rowCount() === 0) {
            return false;
        }

        $pdo->prepare('UPDATE erp_operation_stoppages SET ended_at = CURRENT_TIMESTAMP WHERE id = (SELECT id FROM erp_operation_stoppages WHERE time_entry_id = ? AND ended_at IS NULL ORDER BY started_at DESC LIMIT 1)')->execute([$entryId]);
        return true;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string) ($_POST['action'] ?? ''));
    $pendingAnnouncementForAck = fetch_pending_shopfloor_announcement_ack($pdo, $userId, $sessionLoginAt);

    if ($action === 'acknowledge_announcement') {
        $announcementId = (int) ($_POST['announcement_id'] ?? 0);
        if ($announcementId <= 0 || !$pendingAnnouncementForAck || (int) ($pendingAnnouncementForAck['id'] ?? 0) !== $announcementId) {
            $flashError = 'Comunicado inválido para confirmação.';
        } else {
            $ackStmt = $pdo->prepare('INSERT OR IGNORE INTO shopfloor_announcement_acknowledgements(announcement_id, user_id) VALUES (?, ?)');
            $ackStmt->execute([$announcementId, $userId]);
            log_app_event(
                $pdo,
                $userId,
                'shopfloor.announcement.acknowledge',
                'Comunicado confirmado pelo utilizador.',
                [
                    'announcement_id' => $announcementId,
                    'title' => (string) ($pendingAnnouncementForAck['title'] ?? ''),
                    'acknowledged_at' => date('Y-m-d H:i:s'),
                ]
            );
            $flashSuccess = 'Comunicado confirmado com sucesso.';
            $pendingAnnouncementForAck = null;
        }
    }

    if ($action !== 'acknowledge_announcement' && $pendingAnnouncementForAck) {
        $flashError = 'Tem de confirmar o comunicado pendente antes de continuar.';
    } else {


    if ($action === 'ack_of_document') {
        $documentId = (int) ($_POST['document_id'] ?? 0);
        $stmt = $pdo->prepare('INSERT OR IGNORE INTO erp_production_order_document_acknowledgements(document_id, user_id) VALUES (?, ?)');
        $stmt->execute([$documentId, $userId]);
        $flashSuccess = 'Documento da OF confirmado.';
    }

    if ($action === 'start_of_operation') {
        $poOperationId = (int) ($_POST['po_operation_id'] ?? 0);
        if (!gt_erp_user_can($pdo, $user ?: [], 'erp.shopfloor.execute')) { $flashError = 'Sem permissão para executar operações no Shopfloor.'; }
        $operationStmt=$pdo->prepare('SELECT opo.*,te.id open_entry FROM erp_production_order_operations opo LEFT JOIN erp_operation_time_entries te ON te.production_order_operation_id=opo.id AND te.ended_at IS NULL WHERE opo.id=?');$operationStmt->execute([$poOperationId]);$operation=$operationStmt->fetch(PDO::FETCH_ASSOC);
        $canRunAtSelectedWorkCenter = $operation && shopfloor_operation_can_run_at_work_center($operation, $selectedWorkCenterId, $selectedWorkCenterMachineId);
        $allowed=json_decode((string)($operation['allowed_machine_ids_json']??'[]'),true)?:[];
        $allowedMachineIds = array_values(array_map('intval', $allowed));
        $machineId=(int)($_POST['machine_id']??0);
        if (!$machineId) {
            $primaryMachineId = (int) ($operation['primary_machine_id'] ?? 0);
            $machineId = $selectedWorkCenterMachineId > 0 && in_array($selectedWorkCenterMachineId, $allowedMachineIds, true)
                ? $selectedWorkCenterMachineId
                : (in_array($primaryMachineId, $allowedMachineIds, true) ? $primaryMachineId : (int) ($allowedMachineIds[0] ?? 0));
        }
        $machineRequired = (int) ($operation['machine_required'] ?? 1) === 1;
        $labourTimeOnly = !$machineRequired || (int) ($operation['labour_time_only'] ?? 0) === 1;
        if ($labourTimeOnly) { $machineId = 0; }
        $blockedStmt=$pdo->prepare('SELECT COUNT(*) FROM erp_routing_step_dependencies d JOIN erp_production_order_operations predecessor ON predecessor.routing_step_id=d.predecessor_step_id WHERE d.routing_step_id=? AND predecessor.production_order_id=? AND predecessor.status<>"Concluída"');$blockedStmt->execute([(int)($operation['routing_step_id']??0),(int)($operation['production_order_id']??0)]);
        $pendingDocsStmt = $pdo->prepare('SELECT COUNT(*) FROM erp_production_order_documents d JOIN erp_production_order_operations opo ON opo.production_order_id = d.production_order_id WHERE opo.id = ? AND d.is_required = 1 AND NOT EXISTS (SELECT 1 FROM erp_production_order_document_acknowledgements a WHERE a.document_id = d.id AND a.user_id = ?)');
        $pendingDocsStmt->execute([$poOperationId, $userId]);
        $openOpStmt = $pdo->prepare('SELECT id FROM erp_operation_time_entries WHERE user_id = ? AND ended_at IS NULL LIMIT 1');
        $openOpStmt->execute([$userId]);
        $previousQuantityStmt = $pdo->prepare('SELECT previous.id, previous.sequence_no, COALESCE(previous.requires_good_quantity,predecessor_operation.requires_good_quantity) requires_good_quantity, COALESCE(SUM(COALESCE(te.quantity_good, 0) + COALESCE(te.quantity_rejected, 0)), 0) AS registered_quantity FROM erp_production_order_operations previous JOIN erp_operations predecessor_operation ON predecessor_operation.id = previous.operation_id LEFT JOIN erp_operation_time_entries te ON te.production_order_operation_id = previous.id WHERE previous.production_order_id = ? AND previous.sequence_no < ? GROUP BY previous.id ORDER BY previous.sequence_no DESC, previous.id DESC LIMIT 1');
        $previousQuantityStmt->execute([(int) ($operation['production_order_id'] ?? 0), (int) ($operation['sequence_no'] ?? 0)]);
        $previousOperation = $previousQuantityStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if ($flashError) {
        } elseif (!$operation) {
            $flashError = 'Etapa da OF inválida.';
        } elseif (!$hasOpenClockEntryToday) {
            $flashError = 'Não pode iniciar produção sem registar primeiro o ponto de entrada na empresa.';
            $showClockEntryRequiredModal = true;
        } elseif ($selectedWorkCenterId <= 0) {
            $flashError = 'Selecione primeiro o centro de trabalho deste dispositivo.';
        } elseif (!$canRunAtSelectedWorkCenter) {
            $flashError = 'Esta operação só pode ser acompanhada neste centro de trabalho; não pode ser arrancada aqui.';
        } elseif ($machineRequired && $machineId <= 0) {
            $flashError = 'Esta operação precisa de uma máquina para ser iniciada.';
        } elseif ($machineId && !in_array($machineId,array_map('intval',$allowed),true)) {
            $flashError = 'A máquina selecionada não está autorizada para esta operação.';
        } elseif ((int)$blockedStmt->fetchColumn()>0 && empty($operation['parallel_allowed'])) {
            $flashError = 'Conclua primeiro as operações precedentes obrigatórias.';
        } elseif ((int) $pendingDocsStmt->fetchColumn() > 0) {
            $flashError = 'Tem de visualizar e confirmar todos os documentos obrigatórios da OF antes de iniciar.';
        } elseif ((int) ($openOpStmt->fetchColumn() ?: 0) > 0) {
            $flashError = 'Já existe uma operação em curso.';
        } else {
            $pdo->prepare('INSERT INTO erp_operation_time_entries(production_order_operation_id, user_id, selected_machine_id) VALUES (?, ?, ?)')->execute([$poOperationId, $userId,$machineId?:null]);
            $entry=(int)$pdo->lastInsertId();$pdo->prepare('INSERT OR IGNORE INTO erp_operation_execution_operators(time_entry_id,user_id) VALUES (?,?)')->execute([$entry,$userId]);
            $pdo->prepare('UPDATE erp_production_order_operations SET status = "Em curso" WHERE id = ?')->execute([$poOperationId]);
            $flashSuccess = 'Operação iniciada.';
        }
    }

    if ($action === 'validate_operation_checklist') {
        $poOperationId = (int) ($_POST['po_operation_id'] ?? 0);
        $entryStmt = $pdo->prepare('SELECT opo.*, te.id AS open_entry FROM erp_production_order_operations opo JOIN erp_operation_time_entries te ON te.production_order_operation_id=opo.id AND te.user_id=? AND te.ended_at IS NULL WHERE opo.id=? LIMIT 1');
        $entryStmt->execute([$userId, $poOperationId]);
        $operation = $entryStmt->fetch(PDO::FETCH_ASSOC);
        if (!$operation || !$operationChecklistService->isRequired($operation, $userId, 'start')) {
            $flashError = 'A checklist desta operação já foi validada ou a produção não está ativa.';
        } else {
            try {
                $operationChecklistService->save($operation, $userId, 'start', (array) ($_POST['checklist'] ?? []), (int) $operation['open_entry']);
                $flashSuccess = 'Checklist validada. Pode continuar a produção.';
            } catch (InvalidArgumentException $exception) {
                $flashError = $exception->getMessage();
            }
        }
    }

    if ($action === 'stop_of_operation') {
        $entryId = (int) ($_POST['entry_id'] ?? 0);
        $good = (float) ($_POST['quantity_good'] ?? 0);
        $reject = (float) ($_POST['quantity_rejected'] ?? 0);
        $stmt = $pdo->prepare('UPDATE erp_operation_time_entries SET ended_at = CURRENT_TIMESTAMP, pause_seconds = pause_seconds + CASE WHEN status = "paused" AND paused_at IS NOT NULL THEN CAST((julianday(CURRENT_TIMESTAMP) - julianday(paused_at)) * 86400 AS INTEGER) ELSE 0 END, paused_at = NULL, status = "completed", quantity_good = ?, quantity_rejected = ?, notes = ? WHERE id = ? AND user_id = ? AND ended_at IS NULL');
        $qualityResult=trim((string)($_POST['quality_result']??''));$entryInfo=$pdo->prepare('SELECT opo.*,o.requires_quality,COALESCE(opo.requires_good_quantity,o.requires_good_quantity) requires_good_quantity FROM erp_operation_time_entries te JOIN erp_production_order_operations opo ON opo.id=te.production_order_operation_id JOIN erp_operations o ON o.id=opo.operation_id WHERE te.id=? AND te.user_id=? AND te.ended_at IS NULL');$entryInfo->execute([$entryId,$userId]);$entryInfo=$entryInfo->fetch(PDO::FETCH_ASSOC);$reason=trim((string)($_POST['waste_reason']??''));if($entryInfo&&(int)$entryInfo['requires_good_quantity']!==1){$good=0.0;$reject=0.0;$reason='';}
        $endChecklistRequired=$entryInfo?$operationChecklistService->isRequired($entryInfo,$userId,'end'):false;
        $missingOperationConsumption = false;
        if ($entryInfo) {
            $completionConsumptionStmt = $pdo->prepare('SELECT po.planned_quantity, COALESCE((SELECT SUM(quantity_good) FROM erp_operation_time_entries previous_entry WHERE previous_entry.production_order_operation_id=opo.id AND previous_entry.id<>?),0) completed_quantity, (SELECT COUNT(DISTINCT required.material_id) FROM (SELECT material_id FROM erp_production_order_material_reservations WHERE production_order_operation_id=opo.id UNION SELECT material_id FROM erp_routing_step_materials WHERE routing_step_id=opo.routing_step_id) required) required_materials, (SELECT COUNT(DISTINCT pc.raw_material_id) FROM erp_production_consumptions pc WHERE pc.production_order_operation_id=opo.id AND pc.quantity>0 AND pc.raw_material_id IN (SELECT material_id FROM erp_production_order_material_reservations WHERE production_order_operation_id=opo.id UNION SELECT material_id FROM erp_routing_step_materials WHERE routing_step_id=opo.routing_step_id)) consumed_materials FROM erp_production_order_operations opo JOIN erp_production_orders po ON po.id=opo.production_order_id WHERE opo.id=?');
            $completionConsumptionStmt->execute([$entryId, (int) $entryInfo['id']]);
            $completionConsumption = $completionConsumptionStmt->fetch(PDO::FETCH_ASSOC) ?: [];
            $reachesPlannedQuantity = (float) ($completionConsumption['planned_quantity'] ?? 0) > 0 && ((float) ($completionConsumption['completed_quantity'] ?? 0) + $good) >= (float) $completionConsumption['planned_quantity'];
            $missingOperationConsumption = $reachesPlannedQuantity && (int) ($completionConsumption['required_materials'] ?? 0) > (int) ($completionConsumption['consumed_materials'] ?? 0);
        }
        if($endChecklistRequired){try{$operationChecklistService->validateAndEncode((int)$entryInfo['checklist_template_id'],(array)($_POST['checklist']??[]));}catch(InvalidArgumentException$exception){$flashError=$exception->getMessage();}}
        if($flashError){}elseif($entryInfo&&(int)$entryInfo['requires_good_quantity']===1&&$reject>0&&$reason===''){$flashError='Indique o Motivo NOK.';}elseif($entryInfo&&($good>0||$reject>0)&&((int)$entryInfo['requires_quality']||trim((string)$entryInfo['quality_points'])!=='')&&!in_array($qualityResult,['pass','fail','na'],true)){$flashError='Execute e registe o controlo de qualidade obrigatório.';}else{$stmt->execute([$good, $reject, trim((string)($_POST['notes'] ?? '')) ?: null, $entryId, $userId]);if($stmt->rowCount()>0){$pdo->prepare('UPDATE erp_operation_stoppages SET ended_at = CURRENT_TIMESTAMP WHERE time_entry_id = ? AND ended_at IS NULL')->execute([$entryId]);if($endChecklistRequired)$operationChecklistService->save($entryInfo,$userId,'end',(array)($_POST['checklist']??[]),$entryId);if($reject>0)$pdo->prepare('INSERT INTO erp_operation_waste(time_entry_id,quantity,reason,created_by) VALUES (?,?,?,?)')->execute([$entryId,$reject,$reason,$userId]);if($qualityResult!=='')$pdo->prepare('INSERT INTO erp_operation_quality_checks(production_order_operation_id,checkpoint,result,checked_by) VALUES (?,?,?,?)')->execute([(int)$entryInfo['id'],trim((string)$entryInfo['quality_points'])?:'Controlo obrigatório',$qualityResult,$userId]);$pdo->prepare('UPDATE erp_production_order_operations SET status="Concluída" WHERE id=(SELECT production_order_operation_id FROM erp_operation_time_entries WHERE id=?)')->execute([$entryId]);}$flashSuccess=$stmt->rowCount()>0?'Operação concluída e tempos registados na OF.':'Operação inválida.';}
    }

    if ($action === 'start_unit_consumption') {
        try {
            if(!gt_erp_user_can($pdo,$user?:[],'erp.shopfloor.execute'))throw new RuntimeException('Sem permissão para registar consumos.');
            $operationConsumptionService->startUnit((int)($_POST['po_operation_id']??0),(string)($_POST['unit_type']??''),(string)($_POST['label_number']??''),$userId,$selectedWorkCenterId,(string)($_POST['idempotency_key']??''));
            $flashSuccess='Unidade associada à operação. Registe o restante quando sair da máquina.';
        } catch (Throwable $exception) { $flashError=$exception->getMessage(); }
    }
    if ($action === 'finish_unit_consumption') {
        try {
            if(!gt_erp_user_can($pdo,$user?:[],'erp.shopfloor.execute'))throw new RuntimeException('Sem permissão para registar consumos.');
            $remaining=(float)str_replace(',','.',(string)($_POST['remaining_quantity']??''));
            if(isset($_POST['finished_unit']))$remaining=0.0;
            $operationConsumptionService->finishUnit((int)($_POST['consumption_id']??0),$remaining,$userId,(string)($_POST['idempotency_key']??''));
            $flashSuccess='Consumo fechado e movimento de stock registado.';
        } catch (Throwable $exception) { $flashError=$exception->getMessage(); }
    }
    if ($action === 'register_material_consumption') {
        $operationId = (int) ($_POST['po_operation_id'] ?? 0);
        $materialIds = (array) ($_POST['raw_material_id'] ?? []);
        $quantities = (array) ($_POST['quantity'] ?? []);
        $operationStmt = $pdo->prepare('SELECT opo.production_order_id,po.product_id FROM erp_production_order_operations opo JOIN erp_production_orders po ON po.id=opo.production_order_id WHERE opo.id=? LIMIT 1');
        $operationStmt->execute([$operationId]);
        $consumptionOperation = $operationStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        $consumptionLines = [];
        $consumptionError = '';
        foreach ($materialIds as $index => $rawMaterialId) {
            $materialId = (int) $rawMaterialId;
            $quantity = (float) str_replace(',', '.', (string) ($quantities[$index] ?? 0));
            if ($materialId <= 0 && $quantity <= 0) continue;
            if ($materialId <= 0 || $quantity <= 0) { $consumptionError = 'Cada linha deve indicar um material e um consumo superior a zero.'; break; }
            $consumptionLines[] = [$materialId,$quantity,$index];
        }
        $requiredMaterialStmt = $pdo->prepare('SELECT material_id FROM erp_production_order_material_reservations WHERE production_order_operation_id=? UNION SELECT sm.material_id FROM erp_routing_step_materials sm JOIN erp_production_order_operations opo ON opo.routing_step_id=sm.routing_step_id WHERE opo.id=?');
        $requiredMaterialStmt->execute([$operationId, $operationId]);
        $requiredMaterialIds = array_map('intval', $requiredMaterialStmt->fetchAll(PDO::FETCH_COLUMN));
        if (!gt_erp_user_can($pdo, $user ?: [], 'erp.shopfloor.execute')) {
            $flashError = 'Sem permissão para registar consumos.';
        } elseif (!$consumptionOperation) {
            $flashError = 'Operação inválida para registo de consumos.';
        } elseif ($consumptionError !== '') {
            $flashError = $consumptionError;
        } else {
            try {
                foreach ($consumptionLines as $consumptionLine) {
                    $materialId = (int) $consumptionLine[0];
                    $quantity = (float) $consumptionLine[1];
                    $index = (int) $consumptionLine[2];
                    $baseKey=(string)($_POST['idempotency_key']??'');
                    $operationConsumptionService->direct($operationId,$materialId,$quantity,$userId,$selectedWorkCenterId,$baseKey.'-'.$index);
                }
                $flashSuccess = 'Consumos diretos e movimentos de stock registados.';
            } catch (Throwable $exception) {
                $flashError = $exception->getMessage();
            }
        }
    }

    if (in_array($action,['pause_operation','resume_operation'],true)) {
        $entryId = (int) ($_POST['entry_id'] ?? 0);
        if ($action === 'pause_operation') {
            $paused = shopfloor_pause_active_operation($pdo, $userId, 'Paragem manual aprovada pelo colaborador');
            $flashSuccess = $paused ? 'Operação pausada.' : 'Não existe uma operação em produção para pausar.';
        } elseif (!$hasOpenClockEntryToday) {
            $flashError = 'Não pode retomar produção sem registar primeiro o ponto de entrada na empresa.';
            $showClockEntryRequiredModal = true;
        } else {
            $resumed = shopfloor_resume_operation($pdo, $entryId, $userId);
            $flashSuccess = $resumed ? 'Operação retomada.' : 'Não foi possível retomar a operação.';
        }
    }

    if ($action === 'clock_entry') {
        $entryType = trim((string) ($_POST['entry_type'] ?? ''));
        $note = trim((string) ($_POST['note'] ?? ''));

        if (!in_array($entryType, ['entrada', 'saida'], true)) {
            $flashError = 'Tipo de registo de ponto inválido.';
        } else {
            $occurredAt = date('Y-m-d H:i:s');
            $stmt = $pdo->prepare('INSERT INTO shopfloor_time_entries(user_id, entry_type, note, occurred_at) VALUES (?, ?, ?, ?)');
            $stmt->execute([$userId, $entryType, $note !== '' ? $note : null, $occurredAt]);
            if ($entryType === 'saida' && (int) ($_POST['stop_machine'] ?? 0) === 1) {
                shopfloor_pause_active_operation($pdo, $userId, 'Ponto de saída aprovado pelo colaborador');
            }
            log_app_event($pdo, $userId, 'shopfloor.clock.' . $entryType, 'Registo de ponto no Shopfloor.', ['entry_type' => $entryType]);
            $flashSuccess = $entryType === 'entrada' ? 'Ponto de entrada registado com sucesso.' : 'Ponto de saída registado com sucesso.';
        }
    }

    if ($action === 'start_break') {
        $breakReasonId = (int) ($_POST['break_reason_id'] ?? 0);
        $reasonStmt = $pdo->prepare('SELECT id, code, label, break_type, requires_comment FROM shopfloor_break_reasons WHERE id = ? AND is_active = 1 LIMIT 1');
        $reasonStmt->execute([$breakReasonId]);
        $reason = $reasonStmt->fetch(PDO::FETCH_ASSOC) ?: null;

        $openBreakStmt = $pdo->prepare('SELECT id FROM shopfloor_break_entries WHERE user_id = ? AND ended_at IS NULL LIMIT 1');
        $openBreakStmt->execute([$userId]);
        $openBreakId = (int) ($openBreakStmt->fetchColumn() ?: 0);

        if (!$reason) {
            $flashError = 'Selecione um tipo de pausa/paragem válido.';
        } elseif (!$hasOpenClockEntryToday) {
            $flashError = 'Não pode iniciar uma pausa/paragem sem registar primeiro o ponto de entrada.';
        } elseif ($openBreakId > 0) {
            $flashError = 'Já existe uma pausa/paragem em curso.';
        } else {
            $comment = trim((string) ($_POST['break_comment'] ?? ''));
            $insertBreakStmt = $pdo->prepare('INSERT INTO shopfloor_break_entries(user_id, break_reason_id, break_type, comment) VALUES (?, ?, ?, ?)');
            $insertBreakStmt->execute([
                $userId,
                (int) $reason['id'],
                (string) ($reason['break_type'] ?? 'Pausa'),
                $comment !== '' ? $comment : null,
            ]);
            if ((int) ($_POST['stop_machine'] ?? 0) === 1) {
                shopfloor_pause_active_operation($pdo, $userId, 'Pausa/paragem aprovada pelo colaborador');
            }
            $flashSuccess = ((string) ($reason['break_type'] ?? 'Pausa')) . ' iniciada: ' . (string) ($reason['code'] ?? '') . ' · ' . (string) ($reason['label'] ?? '');
        }
    }

    if ($action === 'stop_break') {
        $activeBreakToStopStmt = $pdo->prepare('SELECT b.id, r.requires_comment FROM shopfloor_break_entries b INNER JOIN shopfloor_break_reasons r ON r.id = b.break_reason_id WHERE b.user_id = ? AND b.ended_at IS NULL ORDER BY b.started_at DESC LIMIT 1');
        $activeBreakToStopStmt->execute([$userId]);
        $activeBreakToStop = $activeBreakToStopStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        $stopComment = trim((string) ($_POST['break_comment'] ?? ''));

        if (!$activeBreakToStop) {
            $flashError = 'Não existe pausa/paragem ativa para terminar.';
        } elseif ((int) ($activeBreakToStop['requires_comment'] ?? 0) === 1 && $stopComment === '') {
            $flashError = 'Este tipo exige comentário obrigatório para terminar.';
        } else {
            $stopBreakStmt = $pdo->prepare('UPDATE shopfloor_break_entries SET ended_at = CURRENT_TIMESTAMP, comment = COALESCE(NULLIF(TRIM(?), ""), comment) WHERE id = ?');
            $stopBreakStmt->execute([$stopComment, (int) $activeBreakToStop['id']]);
            $pausedEntryStmt = $pdo->prepare('SELECT id FROM erp_operation_time_entries WHERE user_id=? AND ended_at IS NULL AND status="paused" ORDER BY started_at DESC LIMIT 1');
            $pausedEntryStmt->execute([$userId]);
            $pausedEntryId = (int) ($pausedEntryStmt->fetchColumn() ?: 0);
            $resumedAfterBreak = $hasOpenClockEntryToday && $pausedEntryId > 0 && shopfloor_resume_operation($pdo, $pausedEntryId, $userId);
            $flashSuccess = $resumedAfterBreak ? 'Pausa/paragem terminada e operação retomada automaticamente.' : 'Pausa/paragem terminada com sucesso.';
            if ($pausedEntryId > 0 && !$hasOpenClockEntryToday) {
                $flashError = 'Não pode retomar produção sem registar primeiro o ponto de entrada na empresa.';
                $showClockEntryRequiredModal = true;
            }
        }
    }

    if ($action === 'submit_absence') {
        $requestType = trim((string) ($_POST['request_type'] ?? 'Dias inteiros'));
        if ($hasOpenClockEntryToday) {
            $flashError = 'Não é possível criar pedidos de ausência enquanto o ponto do dia estiver aberto (sem saída).';
        } else {
        $startDate = trim((string) ($_POST['start_date'] ?? ''));
        $endDate = trim((string) ($_POST['end_date'] ?? ''));
        $singleDate = trim((string) ($_POST['single_date'] ?? ''));
        $startTime = trim((string) ($_POST['start_time'] ?? ''));
        $endTime = trim((string) ($_POST['end_time'] ?? ''));
        $reasonId = (int) ($_POST['reason_id'] ?? 0);
        $details = trim((string) ($_POST['details'] ?? ''));
        $durationType = trim((string) ($_POST['duration_type'] ?? 'Completa'));
        $durationHours = trim((string) ($_POST['duration_hours'] ?? ''));

        $reasonStmt = $pdo->prepare('SELECT reason_code, sage_code, label FROM shopfloor_absence_reasons WHERE id = ? AND is_active = 1 AND (? = 1 OR ? = 1 OR show_in_shopfloor = 1) LIMIT 1');
        $reasonStmt->execute([$reasonId, $isAdmin ? 1 : 0, $isRh ? 1 : 0]);
        $reasonData = $reasonStmt->fetch(PDO::FETCH_ASSOC);

        if (!in_array($requestType, ['Dias inteiros', 'Intervalo de tempo'], true)) {
            $flashError = 'Tipo de ausência inválido.';
        } elseif (!in_array($durationType, ['Completa', 'Parcial', 'Horas'], true)) {
            $flashError = 'Tipo de duração inválido.';
        } elseif (!$reasonData) {
            $flashError = 'Selecione um motivo para comunicar ausência.';
        } elseif ($requestType === 'Dias inteiros' && ($startDate === '' || $endDate === '')) {
            $flashError = 'Preencha datas e selecione um motivo para comunicar ausência.';
        } elseif ($requestType === 'Dias inteiros' && $endDate < $startDate) {
            $flashError = 'A data final da ausência não pode ser anterior à inicial.';
        } elseif ($requestType === 'Intervalo de tempo' && ($singleDate === '' || $startTime === '' || $endTime === '')) {
            $flashError = 'Preencha data e horas para o intervalo de tempo.';
        } elseif ($requestType === 'Intervalo de tempo' && $endTime <= $startTime) {
            $flashError = 'A hora final deve ser posterior à hora inicial.';
        } else {
            if ($requestType === 'Intervalo de tempo') {
                $startDate = $singleDate;
                $endDate = $singleDate;
            }
            $reason = trim((string) ($reasonData['reason_code'] ?? '')) . ' · ' . normalize_sage_code((string) ($reasonData['sage_code'] ?? '')) . ' - ' . trim((string) ($reasonData['label'] ?? ''));
            $stmt = $pdo->prepare('INSERT INTO shopfloor_absence_requests(user_id, request_type, duration_type, duration_hours, start_date, end_date, start_time, end_time, reason, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $userId,
$requestType,
                $durationType,
                $durationType === 'Horas' ? $durationHours : null,
                $startDate,
                $endDate,
                $requestType === 'Intervalo de tempo' ? $startTime : null,
                $requestType === 'Intervalo de tempo' ? $endTime : null,
                $reason,
                $details !== '' ? $details : null,
            ]);
            $absenceId = (int) $pdo->lastInsertId();
            if ($absenceId > 0) {
                $pdo->prepare('UPDATE shopfloor_absence_requests SET status = ? WHERE id = ?')->execute(['Pendente Nível 1', $absenceId]);
            }
            log_app_event($pdo, $userId, 'shopfloor.absence.create', 'Comunicação de ausência submetida.', ['request_type' => $requestType, 'duration_type' => $durationType, 'duration_hours' => $durationHours, 'start_date' => $startDate, 'end_date' => $endDate, 'reason_id' => $reasonId]);
            $flashSuccess = 'Comunicação de ausência submetida com sucesso.';
        }
        }
    }

    if ($action === 'review_absence' && ($isAdmin || $isChief || $isRh)) {
        $absenceId = (int) ($_POST['absence_id'] ?? 0);
        $decision = trim((string) ($_POST['decision'] ?? ''));

        $absenceStmt = $pdo->prepare('SELECT id, status FROM shopfloor_absence_requests WHERE id = ? LIMIT 1');
        $absenceStmt->execute([$absenceId]);
        $absence = $absenceStmt->fetch(PDO::FETCH_ASSOC);

        if (!$absence || $absenceId <= 0 || !in_array($decision, ['approve', 'reject'], true)) {
            $flashError = 'Pedido inválido para validação.';
        } else {
            $currentStatus = (string) ($absence['status'] ?? '');
            $newStatus = null;

            if ($isAdmin && $decision === 'approve') {
                $newStatus = 'Aprovado';
            } elseif ($isAdmin && $decision === 'reject') {
                $newStatus = 'Rejeitado';
            } elseif ($isChief) {
                if ($currentStatus !== 'Pendente Nível 1') {
                    $flashError = 'Este pedido já não está pendente do Nível 1.';
                } elseif ($decision === 'approve') {
                    $newStatus = 'Pendente Nível 2';
                } else {
                    $newStatus = 'Rejeitado';
                }
            } elseif ($isRh) {
                if (!in_array($currentStatus, ['Pendente Nível 1', 'Pendente Nível 2', 'Pendente'], true)) {
                    $flashError = 'Este pedido já não está pendente de aprovação.';
                } elseif ($decision === 'approve') {
                    $newStatus = 'Aprovado';
                } else {
                    $newStatus = 'Rejeitado';
                }
            }

            if ($newStatus !== null) {
                $updateStmt = $pdo->prepare('UPDATE shopfloor_absence_requests SET status = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?');
                $updateStmt->execute([$newStatus, $userId, $absenceId]);
                log_app_event($pdo, $userId, 'shopfloor.absence.review', 'Validação de ausência efetuada.', ['absence_id' => $absenceId, 'status' => $newStatus]);
                $flashSuccess = 'Estado do pedido atualizado para ' . $newStatus . '.';
            }
        }
    }


    if ($action === 'edit_absence' && ($isAdmin || $isRh)) {
        $absenceId = (int) ($_POST['absence_id'] ?? 0);
        $requestType = trim((string) ($_POST['request_type'] ?? 'Dias inteiros'));
        $durationType = trim((string) ($_POST['duration_type'] ?? 'Completa'));
        $durationHours = trim((string) ($_POST['duration_hours'] ?? ''));
        $startDate = trim((string) ($_POST['start_date'] ?? ''));
        $endDate = trim((string) ($_POST['end_date'] ?? ''));
        $startTime = trim((string) ($_POST['start_time'] ?? ''));
        $endTime = trim((string) ($_POST['end_time'] ?? ''));
        $details = trim((string) ($_POST['details'] ?? ''));

        if ($absenceId <= 0 || !in_array($requestType, ['Dias inteiros', 'Intervalo de tempo'], true) || !in_array($durationType, ['Completa', 'Parcial', 'Horas'], true) || $startDate === '' || $endDate === '' || $endDate < $startDate) {
            $flashError = 'Dados inválidos para editar ausência.';
        } elseif ($durationType === 'Horas' && !preg_match('/^\d{1,2}:\d{2}$/', $durationHours)) {
            $flashError = 'Indique a duração no formato hh:mm.';
        } elseif ($requestType === 'Intervalo de tempo' && ($startTime === '' || $endTime === '' || $endTime <= $startTime)) {
            $flashError = 'Preencha um intervalo horário válido.';
        } else {
            $updateStmt = $pdo->prepare('UPDATE shopfloor_absence_requests SET request_type = ?, duration_type = ?, duration_hours = ?, start_date = ?, end_date = ?, start_time = ?, end_time = ?, details = ? WHERE id = ?');
            $updateStmt->execute([$requestType, $durationType, $durationType === 'Horas' ? $durationHours : null, $startDate, $endDate, $requestType === 'Intervalo de tempo' ? $startTime : null, $requestType === 'Intervalo de tempo' ? $endTime : null, $details !== '' ? $details : null, $absenceId]);
            log_app_event($pdo, $userId, 'shopfloor.absence.edit', 'Pedido de ausência editado por RH/Admin.', ['absence_id' => $absenceId, 'request_type' => $requestType, 'duration_type' => $durationType, 'duration_hours' => $durationHours, 'start_date' => $startDate, 'end_date' => $endDate]);
            $flashSuccess = 'Pedido de ausência atualizado com sucesso.';
        }
    }

    if ($action === 'submit_justification') {
        $absenceRequestId = (int) ($_POST['absence_request_id'] ?? 0);
        $eventDate = date('Y-m-d');
        $description = trim((string) ($_POST['description'] ?? ''));
        $attachmentFile = $_FILES['attachment'] ?? null;
        $attachmentPath = null;
        $hasAttachmentUpload = is_array($attachmentFile) && (($attachmentFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE);

        if ($hasAttachmentUpload) {
            $uploadError = (int) ($attachmentFile['error'] ?? UPLOAD_ERR_NO_FILE);
            if ($uploadError !== UPLOAD_ERR_OK) {
                $flashError = 'Não foi possível carregar o ficheiro da justificação.';
            } elseif (!isset($attachmentFile['tmp_name']) || !is_string($attachmentFile['tmp_name']) || !is_file($attachmentFile['tmp_name'])) {
                $flashError = 'O ficheiro submetido é inválido.';
            } else {
                $attachmentExtension = ShopfloorAttachment::detectExtension((string) $attachmentFile['tmp_name']);

                if ($attachmentExtension === null) {
                    $flashError = 'Formato de ficheiro inválido. Use PDF, JPG, PNG ou WEBP.';
                } else {
                    $uploadDir = __DIR__ . '/assets/uploads/justifications';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0775, true);
                    }

                    $filename = sprintf(
                        'justification_%d_%s.%s',
                        $userId,
                        bin2hex(random_bytes(6)),
                        $attachmentExtension
                    );
                    $targetPath = $uploadDir . '/' . $filename;

                    if (!move_uploaded_file((string) $attachmentFile['tmp_name'], $targetPath)) {
                        $flashError = 'Falha ao guardar o ficheiro da justificação.';
                    } else {
                        $attachmentPath = 'assets/uploads/justifications/' . $filename;
                    }
                }
            }
        }

        if ($flashError === null && !$hasAttachmentUpload) {
            $flashError = 'Anexe um ficheiro para a justificação.';
        }

        if ($flashError === null) {
            $targetAbsenceId = null;
            if ($absenceRequestId > 0) {
                $checkAbsenceStmt = $pdo->prepare('SELECT id FROM shopfloor_absence_requests WHERE id = ? AND user_id = ?');
                $checkAbsenceStmt->execute([$absenceRequestId, $userId]);
                $targetAbsenceId = (int) $checkAbsenceStmt->fetchColumn();
                if ($targetAbsenceId <= 0) {
                    $targetAbsenceId = null;
                }
            }

            $stmt = $pdo->prepare('INSERT INTO shopfloor_justifications(user_id, absence_request_id, event_date, description) VALUES (?, ?, ?, ?)');
            $justificationDescription = $description !== '' ? $description : 'Ficheiro anexado';
            $stmt->execute([$userId, $targetAbsenceId, $eventDate, $justificationDescription]);
            if ($attachmentPath !== null) {
                $justificationId = (int) $pdo->lastInsertId();
                if ($justificationId > 0) {
                    $attachmentStmt = $pdo->prepare('UPDATE shopfloor_justifications SET attachment_path = ? WHERE id = ? AND user_id = ?');
                    $attachmentStmt->execute([$attachmentPath, $justificationId, $userId]);
                }
            }
            log_app_event($pdo, $userId, 'shopfloor.justification.create', 'Justificação submetida no Shopfloor.', ['event_date' => $eventDate]);
            $flashSuccess = 'Justificação submetida com sucesso.';
        }
    }

    if ($action === 'submit_vacation') {
        $startDate = trim((string) ($_POST['start_date'] ?? ''));
        $endDate = trim((string) ($_POST['end_date'] ?? ''));
        $notes = trim((string) ($_POST['notes'] ?? ''));

        if ($hasOpenClockEntryToday) {
            $flashError = 'Não é possível criar pedidos de férias enquanto o ponto do dia estiver aberto (sem saída).';
        } elseif ($startDate === '' || $endDate === '') {
            $flashError = 'Indique o período de férias.';
        } elseif ($endDate < $startDate) {
            $flashError = 'A data final das férias não pode ser anterior à inicial.';
        } else {
            $start = new DateTimeImmutable($startDate);
            $end = new DateTimeImmutable($endDate);
            $totalDays = (float) $start->diff($end)->days + 1;

            $stmt = $pdo->prepare('INSERT INTO shopfloor_vacation_requests(user_id, start_date, end_date, total_days, notes) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$userId, $startDate, $endDate, $totalDays, $notes !== '' ? $notes : null]);
            log_app_event($pdo, $userId, 'shopfloor.vacation.create', 'Pedido de férias submetido no Shopfloor.', ['start_date' => $startDate, 'end_date' => $endDate]);
            $flashSuccess = 'Pedido de férias submetido com sucesso.';
        }
    }


    if ($action === 'publish_announcement' && $canManageAnnouncements) {
        $title = trim((string) ($_POST['title'] ?? ''));
        $body = trim((string) ($_POST['body'] ?? ''));
        $targetUserIds = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['target_user_ids'] ?? [])), static function (int $id): bool { return $id > 0; })));

        if ($title === '' || $body === '') {
            $flashError = 'Preencha título e conteúdo para publicar o comunicado.';
        } else {
            $validTargetUserIds = [];
            if ($targetUserIds !== []) {
                $targetPlaceholders = implode(',', array_fill(0, count($targetUserIds), '?'));
                $targetUsersStmt = $pdo->prepare('SELECT id FROM users WHERE id IN (' . $targetPlaceholders . ')');
                $targetUsersStmt->execute($targetUserIds);
                $validTargetUserIds = array_map('intval', $targetUsersStmt->fetchAll(PDO::FETCH_COLUMN));
            }

            $audience = $validTargetUserIds === [] ? 'shopfloor' : 'targeted';
            $stmt = $pdo->prepare('INSERT INTO shopfloor_announcements(title, body, audience, created_by) VALUES (?, ?, ?, ?)');
            $stmt->execute([$title, $body, $audience, $userId]);
            $announcementId = (int) $pdo->lastInsertId();

            if ($announcementId > 0 && $validTargetUserIds !== []) {
                $targetInsertStmt = $pdo->prepare('INSERT OR IGNORE INTO shopfloor_announcement_targets(announcement_id, user_id) VALUES (?, ?)');
                foreach ($validTargetUserIds as $targetUserId) {
                    $targetInsertStmt->execute([$announcementId, $targetUserId]);
                }
            }

            $recipientRows = [];
            if ($validTargetUserIds !== []) {
                $recipientPlaceholders = implode(',', array_fill(0, count($validTargetUserIds), '?'));
                $recipientStmt = $pdo->prepare('SELECT id, name, email, username FROM users WHERE id IN (' . $recipientPlaceholders . ') ORDER BY name COLLATE NOCASE ASC');
                $recipientStmt->execute($validTargetUserIds);
                $recipientRows = $recipientStmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $recipientStmt = $pdo->query('SELECT id, name, email, username FROM users WHERE is_active = 1 ORDER BY name COLLATE NOCASE ASC');
                $recipientRows = $recipientStmt->fetchAll(PDO::FETCH_ASSOC);
            }

            log_app_event(
                $pdo,
                $userId,
                'shopfloor.announcement.create',
                'Comunicado publicado no Shopfloor.',
                [
                    'announcement_id' => $announcementId,
                    'title' => $title,
                    'body' => $body,
                    'audience' => $audience,
                    'target_user_ids' => $validTargetUserIds,
                    'submitted_to_users' => $recipientRows,
                ]
            );
            $flashSuccess = 'Comunicado publicado com sucesso.';
        }
    }

    if ($action === 'toggle_announcement' && $canManageAnnouncements) {
        $announcementId = (int) ($_POST['announcement_id'] ?? 0);
        $toggleStmt = $pdo->prepare('UPDATE shopfloor_announcements SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?');
        $toggleStmt->execute([$announcementId]);

        if ($toggleStmt->rowCount() > 0) {
            log_app_event($pdo, $userId, 'shopfloor.announcement.toggle', 'Comunicado ativado/desativado no Shopfloor.', ['announcement_id' => $announcementId]);
            $flashSuccess = 'Estado do comunicado atualizado com sucesso.';
        } else {
            $flashError = 'Comunicado inválido para alteração de estado.';
        }
    }

    if ($action === 'delete_announcement' && $canManageAnnouncements) {
        $announcementId = (int) ($_POST['announcement_id'] ?? 0);
        $deleteStmt = $pdo->prepare('DELETE FROM shopfloor_announcements WHERE id = ?');
        $deleteStmt->execute([$announcementId]);

        if ($deleteStmt->rowCount() > 0) {
            log_app_event($pdo, $userId, 'shopfloor.announcement.delete', 'Comunicado eliminado no Shopfloor.', ['announcement_id' => $announcementId]);
            $flashSuccess = 'Comunicado eliminado com sucesso.';
        } else {
            $flashError = 'Comunicado inválido para eliminação.';
        }
    }
    }
}

$hourBankStmt = $pdo->prepare('SELECT balance_hours, updated_at FROM shopfloor_hour_banks WHERE user_id = ? LIMIT 1');
$hourBankStmt->execute([$userId]);
$hourBank = $hourBankStmt->fetch(PDO::FETCH_ASSOC);
if (!$hourBank) {
    $pdo->prepare('INSERT INTO shopfloor_hour_banks(user_id, balance_hours, notes) VALUES (?, 0, NULL)')->execute([$userId]);
    $hourBank = ['balance_hours' => 0, 'updated_at' => date('Y-m-d H:i:s')];
}

$todayEntriesStmt = $pdo->prepare('SELECT entry_type, note, occurred_at FROM shopfloor_time_entries WHERE user_id = ? AND date(occurred_at) = ? ORDER BY occurred_at DESC, id DESC');
$todayEntriesStmt->execute([$userId, $todayLocalDate]);
$todayEntries = $todayEntriesStmt->fetchAll(PDO::FETCH_ASSOC);

$activeBreakEntryStmt = $pdo->prepare('SELECT b.id, b.break_reason_id, b.break_type, b.started_at, r.code, r.label, r.requires_comment FROM shopfloor_break_entries b INNER JOIN shopfloor_break_reasons r ON r.id = b.break_reason_id WHERE b.user_id = ? AND b.ended_at IS NULL ORDER BY b.started_at DESC LIMIT 1');
$activeBreakEntryStmt->execute([$userId]);
$activeBreakEntry = $activeBreakEntryStmt->fetch(PDO::FETCH_ASSOC) ?: null;

$dailyBreakSummaryStmt = $pdo->prepare(
    'SELECT b.break_type, COUNT(*) AS total_count, SUM(CASE WHEN b.ended_at IS NULL THEN CAST((julianday(CURRENT_TIMESTAMP) - julianday(b.started_at)) * 86400 AS INTEGER) ELSE CAST((julianday(b.ended_at) - julianday(b.started_at)) * 86400 AS INTEGER) END) AS total_seconds
     FROM shopfloor_break_entries b
     WHERE b.user_id = ? AND date(b.started_at) = date("now", "localtime")
     GROUP BY b.break_type'
);
$dailyBreakSummaryStmt->execute([$userId]);
$dailyBreakSummaryRows = $dailyBreakSummaryStmt->fetchAll(PDO::FETCH_ASSOC);
$dailyBreakSummaryMap = ['Pausa' => ['count' => 0, 'seconds' => 0], 'Paragem' => ['count' => 0, 'seconds' => 0]];
foreach ($dailyBreakSummaryRows as $dailyBreakSummaryRow) {
    $type = (string) ($dailyBreakSummaryRow['break_type'] ?? 'Pausa');
    if (!isset($dailyBreakSummaryMap[$type])) {
        continue;
    }
    $dailyBreakSummaryMap[$type] = [
        'count' => (int) ($dailyBreakSummaryRow['total_count'] ?? 0),
        'seconds' => max(0, (int) ($dailyBreakSummaryRow['total_seconds'] ?? 0)),
    ];
}
$dailyIndicators = (new ShopfloorDailyIndicators($pdo))->forUser($userId);
$dailyBreakByReasonStmt = $pdo->prepare(
    'SELECT r.code, r.label, b.break_type, COUNT(*) AS total_count, SUM(CASE WHEN b.ended_at IS NULL THEN CAST((julianday(CURRENT_TIMESTAMP) - julianday(b.started_at)) * 86400 AS INTEGER) ELSE CAST((julianday(b.ended_at) - julianday(b.started_at)) * 86400 AS INTEGER) END) AS total_seconds
     FROM shopfloor_break_entries b
     INNER JOIN shopfloor_break_reasons r ON r.id = b.break_reason_id
     WHERE b.user_id = ? AND date(b.started_at) = date("now", "localtime")
     GROUP BY r.id, r.code, r.label, b.break_type
     ORDER BY r.code COLLATE NOCASE ASC'
);
$dailyBreakByReasonStmt->execute([$userId]);
$dailyBreakByReason = $dailyBreakByReasonStmt->fetchAll(PDO::FETCH_ASSOC);
$latestTodayEntryType = (string) ($todayEntries[0]['entry_type'] ?? '');
$hasOpenClockEntryToday = $latestTodayEntryType === 'entrada';

$absenceReasonsStmt = $pdo->prepare('SELECT id, reason_code, sage_code, label, color FROM shopfloor_absence_reasons WHERE is_active = 1 AND (? = 1 OR ? = 1 OR show_in_shopfloor = 1) ORDER BY reason_code COLLATE NOCASE ASC, label COLLATE NOCASE ASC');
$absenceReasonsStmt->execute([$isAdmin ? 1 : 0, $isRh ? 1 : 0]);
$absenceReasons = $absenceReasonsStmt->fetchAll(PDO::FETCH_ASSOC);

$absenceRequestsStmt = $pdo->prepare('SELECT a.id, a.request_type, a.duration_type, a.duration_hours, a.start_date, a.end_date, a.start_time, a.end_time, a.reason, a.details, a.status, a.created_at, r.color AS reason_color, j.attachment_path AS latest_attachment_path FROM shopfloor_absence_requests a LEFT JOIN shopfloor_absence_reasons r ON a.reason LIKE (r.reason_code || " · %") LEFT JOIN shopfloor_justifications j ON j.id = (SELECT j2.id FROM shopfloor_justifications j2 WHERE j2.absence_request_id = a.id AND j2.attachment_path IS NOT NULL AND TRIM(j2.attachment_path) <> "" ORDER BY j2.created_at DESC LIMIT 1) WHERE a.user_id = ? ORDER BY a.created_at DESC LIMIT 10');
$absenceRequestsStmt->execute([$userId]);
$absenceRequests = $absenceRequestsStmt->fetchAll(PDO::FETCH_ASSOC);

$rhFilter = trim((string) ($_GET['rh_filter'] ?? 'todos'));
if (!in_array($rhFilter, ['todos', 'pendentes', 'aprovados'], true)) {
    $rhFilter = 'todos';
}
$rhAbsenceRows = [];
if ($isAdmin || $isRh) {
    $rhWhere = 'WHERE a.status LIKE "Pendente%" OR a.status = "Aprovado"';
    if ($rhFilter === 'pendentes') {
        $rhWhere = 'WHERE a.status LIKE "Pendente%"';
    } elseif ($rhFilter === 'aprovados') {
        $rhWhere = 'WHERE a.status = "Aprovado"';
    }
    $rhAbsenceStmt = $pdo->query('SELECT a.id, a.request_type, a.duration_type, a.duration_hours, a.start_date, a.end_date, a.start_time, a.end_time, a.reason, a.status, a.created_at, a.details, u.name AS user_name FROM shopfloor_absence_requests a INNER JOIN users u ON u.id = a.user_id ' . $rhWhere . ' ORDER BY a.created_at DESC LIMIT 100');
    $rhAbsenceRows = $rhAbsenceStmt->fetchAll(PDO::FETCH_ASSOC);
}

$absenceJustificationsStmt = $pdo->prepare('SELECT id, absence_request_id, event_date, description, attachment_path, status, created_at FROM shopfloor_justifications WHERE user_id = ? AND absence_request_id IS NOT NULL ORDER BY created_at DESC LIMIT 100');
$absenceJustificationsStmt->execute([$userId]);
$absenceJustificationsRows = $absenceJustificationsStmt->fetchAll(PDO::FETCH_ASSOC);
$absenceJustificationsByRequestId = [];
foreach ($absenceJustificationsRows as $absenceJustificationRow) {
    $requestId = (int) ($absenceJustificationRow['absence_request_id'] ?? 0);
    if ($requestId <= 0) {
        continue;
    }
    if (!array_key_exists($requestId, $absenceJustificationsByRequestId)) {
        $absenceJustificationsByRequestId[$requestId] = [];
    }
    $absenceJustificationsByRequestId[$requestId][] = $absenceJustificationRow;
}

$vacationRequestsStmt = $pdo->prepare('SELECT id, start_date, end_date, total_days, status, created_at FROM shopfloor_vacation_requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 10');
$vacationRequestsStmt->execute([$userId]);
$vacationRequests = $vacationRequestsStmt->fetchAll(PDO::FETCH_ASSOC);

$vacationYear = (int) ($_GET['vacation_year'] ?? date('Y'));
if ($vacationYear < 2000 || $vacationYear > 2100) {
    $vacationYear = (int) date('Y');
}

$scheduleContextStmt = $pdo->prepare('SELECT s.name AS schedule_name, s.weekdays_mask, s.start_time, s.end_time, s.second_start_time, s.second_end_time, s.break_minutes FROM users u LEFT JOIN hr_schedules s ON s.id = u.schedule_id WHERE u.id = ? LIMIT 1');
$scheduleContextStmt->execute([$userId]);
$scheduleContext = $scheduleContextStmt->fetch(PDO::FETCH_ASSOC) ?: [];
$scheduleName = trim((string) ($scheduleContext['schedule_name'] ?? ''));
$scheduleGap = '';
if ($scheduleName !== '' && preg_match('/\bGAP\s*([1-3])\b/i', $scheduleName, $gapMatches) === 1) {
    $scheduleGap = 'GAP' . $gapMatches[1];
}
$scheduleWeekdays = array_filter(
    array_map('trim', explode(',', (string) ($scheduleContext['weekdays_mask'] ?? '1,2,3,4,5'))),
    static function (string $day): bool { return preg_match('/^[1-7]$/', $day) === 1; }
);
if ($scheduleWeekdays === []) {
    $scheduleWeekdays = ['1', '2', '3', '4', '5'];
}
$scheduleWeekdaysMap = array_fill_keys($scheduleWeekdays, true);

$yearStart = sprintf('%04d-01-01', $vacationYear);
$yearEnd = sprintf('%04d-12-31', $vacationYear);

$calendarEventsStmt = $pdo->prepare('SELECT event_type, title, start_date, end_date FROM hr_calendar_events WHERE start_date <= ? AND end_date >= ?');
$calendarEventsStmt->execute([$yearEnd, $yearStart]);
$calendarEvents = $calendarEventsStmt->fetchAll(PDO::FETCH_ASSOC);
$blockedDates = [];
foreach ($calendarEvents as $calendarEvent) {
    $eventType = trim((string) ($calendarEvent['event_type'] ?? ''));
    $eventTitle = mb_strtolower(trim((string) ($calendarEvent['title'] ?? '')));
    $isGlobalBlocked = in_array($eventType, ['Feriado', 'Ponte'], true);
    $isVacationBlocked = $eventType === 'Férias' && ($scheduleGap === '' || strpos($eventTitle, mb_strtolower($scheduleGap)) !== false || strpos($eventTitle, 'gerais') !== false);
    if (!$isGlobalBlocked && !$isVacationBlocked) {
        continue;
    }

    try {
        $eventStart = new DateTimeImmutable(max((string) $calendarEvent['start_date'], $yearStart));
        $eventEnd = new DateTimeImmutable(min((string) $calendarEvent['end_date'], $yearEnd));
    } catch (Exception $exception) {
        continue;
    }

    for ($currentDate = $eventStart; $currentDate <= $eventEnd; $currentDate = $currentDate->modify('+1 day')) {
        $blockedDates[$currentDate->format('Y-m-d')] = true;
    }
}

$expectedWorkDays = 0;
for ($currentDate = new DateTimeImmutable($yearStart); $currentDate <= new DateTimeImmutable($yearEnd); $currentDate = $currentDate->modify('+1 day')) {
    $weekday = (string) $currentDate->format('N');
    $dateKey = $currentDate->format('Y-m-d');
    if (isset($scheduleWeekdaysMap[$weekday]) && !isset($blockedDates[$dateKey])) {
        $expectedWorkDays++;
    }
}

$workedDaysStmt = $pdo->prepare('SELECT COUNT(DISTINCT date(occurred_at)) FROM shopfloor_time_entries WHERE user_id = ? AND entry_type = "entrada" AND date(occurred_at) BETWEEN ? AND ?');
$workedDaysStmt->execute([$userId, $yearStart, $yearEnd]);
$workedDays = (int) $workedDaysStmt->fetchColumn();

$assignedVacationDaysStmt = $pdo->prepare('SELECT COALESCE(assigned_days, 0) FROM hr_vacation_balances WHERE user_id = ? AND year = ? LIMIT 1');
$assignedVacationDaysStmt->execute([$userId, $vacationYear]);
$assignedVacationDays = (float) $assignedVacationDaysStmt->fetchColumn();

$requestedVacationDaysStmt = $pdo->prepare('SELECT COALESCE(SUM(total_days), 0) FROM shopfloor_vacation_requests WHERE user_id = ? AND status LIKE "Pendente%" AND start_date <= ? AND end_date >= ?');
$requestedVacationDaysStmt->execute([$userId, $yearEnd, $yearStart]);
$requestedVacationDays = (float) $requestedVacationDaysStmt->fetchColumn();

$validatedVacationDaysStmt = $pdo->prepare('SELECT COALESCE(SUM(total_days), 0) FROM shopfloor_vacation_requests WHERE user_id = ? AND status = "Aprovado" AND start_date <= ? AND end_date >= ?');
$validatedVacationDaysStmt->execute([$userId, $yearEnd, $yearStart]);
$validatedVacationDays = (float) $validatedVacationDaysStmt->fetchColumn();

$takenVacationDaysStmt = $pdo->prepare('SELECT COALESCE(SUM(total_days), 0) FROM hr_vacation_events WHERE user_id = ? AND status = "Aprovado" AND start_date <= ? AND end_date >= ?');
$takenVacationDaysStmt->execute([$userId, $yearEnd, $yearStart]);
$takenVacationDays = (float) $takenVacationDaysStmt->fetchColumn();

$announcementTargetUsers = [];
if ($canManageAnnouncements) {
    $announcementTargetUsersStmt = $pdo->query('SELECT id, name, username FROM users ORDER BY name COLLATE NOCASE ASC');
    $announcementTargetUsers = $announcementTargetUsersStmt->fetchAll(PDO::FETCH_ASSOC);
}

$announcementsStmt = $pdo->prepare('SELECT a.id, a.title, a.body, a.created_at, a.is_active, a.audience, COALESCE(u.name, "Sistema") AS created_by_name FROM shopfloor_announcements a LEFT JOIN users u ON u.id = a.created_by WHERE a.is_active = 1 AND (a.audience IN ("all", "shopfloor") OR EXISTS (SELECT 1 FROM shopfloor_announcement_targets t WHERE t.announcement_id = a.id AND t.user_id = ?)) ORDER BY a.created_at DESC LIMIT 8');
$announcementsStmt->execute([$userId]);
$announcements = $announcementsStmt->fetchAll(PDO::FETCH_ASSOC);
$pendingAnnouncementAck = fetch_pending_shopfloor_announcement_ack($pdo, $userId, $sessionLoginAt);

$managedAnnouncements = [];
if ($canManageAnnouncements) {
    $managedAnnouncementsStmt = $pdo->query('SELECT a.id, a.title, a.body, a.created_at, a.is_active, a.audience, COALESCE(u.name, "Sistema") AS created_by_name, (SELECT COUNT(*) FROM shopfloor_announcement_targets t WHERE t.announcement_id = a.id) AS target_count FROM shopfloor_announcements a LEFT JOIN users u ON u.id = a.created_by ORDER BY a.created_at DESC LIMIT 25');
    $managedAnnouncements = $managedAnnouncementsStmt->fetchAll(PDO::FETCH_ASSOC);
}

$availableVacationDays = max(0.0, $assignedVacationDays - $takenVacationDays);

$targetMinutes = company_daily_objective_minutes($pdo);
if (!empty($scheduleContext['start_time']) && !empty($scheduleContext['end_time'])) {
    $scheduleTargetMinutes = 0;
    foreach ([['start_time', 'end_time'], ['second_start_time', 'second_end_time']] as $periodColumns) {
        $periodStart = trim((string) ($scheduleContext[$periodColumns[0]] ?? ''));
        $periodEnd = trim((string) ($scheduleContext[$periodColumns[1]] ?? ''));
        if (preg_match('/^\d{2}:\d{2}$/', $periodStart) !== 1 || preg_match('/^\d{2}:\d{2}$/', $periodEnd) !== 1) {
            continue;
        }

        $periodStartParts = array_map('intval', explode(':', $periodStart));
        $periodEndParts = array_map('intval', explode(':', $periodEnd));
        $startHour = $periodStartParts[0];
        $startMinute = $periodStartParts[1];
        $endHour = $periodEndParts[0];
        $endMinute = $periodEndParts[1];
        $periodMinutes = (($endHour * 60) + $endMinute) - (($startHour * 60) + $startMinute);
        if ($periodMinutes > 0) {
            $scheduleTargetMinutes += $periodMinutes;
        }
    }
    $targetMinutes = max(0, $scheduleTargetMinutes - (int) ($scheduleContext['break_minutes'] ?? 0));
}

$bhAdjustmentMinutes = 0;
$rangeStart = $yearStart;
$rangeEnd = min($yearEnd, date('Y-m-d'));
if ($rangeEnd >= $rangeStart) {
    $absenceImpactStmt = $pdo->prepare('SELECT start_date, end_date, reason, duration_type, duration_hours FROM shopfloor_absence_requests WHERE user_id = ? AND status = "Aprovado" AND start_date <= ? AND end_date >= ?');
    $absenceImpactStmt->execute([$userId, $rangeEnd, $rangeStart]);
    $absenceImpactRows = $absenceImpactStmt->fetchAll(PDO::FETCH_ASSOC);

    $approvedMinutesByDate = [];
    $excludedCode100MinutesByDate = [];
    foreach ($absenceImpactRows as $absenceImpact) {
        $absenceMinutes = shopfloor_resolve_absence_minutes($absenceImpact, $targetMinutes);
        if ($absenceMinutes <= 0) {
            continue;
        }

        $absenceCode = shopfloor_parse_absence_code((string) ($absenceImpact['reason'] ?? ''));
        $isCode100 = shopfloor_should_exclude_absence_credit($absenceCode);

        try {
            $start = new DateTimeImmutable(max((string) ($absenceImpact['start_date'] ?? ''), $rangeStart));
            $end = new DateTimeImmutable(min((string) ($absenceImpact['end_date'] ?? ''), $rangeEnd));
        } catch (Exception $exception) {
            continue;
        }

        for ($dateCursor = $start; $dateCursor <= $end; $dateCursor = $dateCursor->modify('+1 day')) {
            $dateKey = $dateCursor->format('Y-m-d');
            $approvedMinutesByDate[$dateKey] = ($approvedMinutesByDate[$dateKey] ?? 0) + $absenceMinutes;
            if ($isCode100) {
                $excludedCode100MinutesByDate[$dateKey] = ($excludedCode100MinutesByDate[$dateKey] ?? 0) + $absenceMinutes;
            }
        }
    }

    $workedMapStmt = $pdo->prepare('SELECT DISTINCT date(occurred_at) AS work_date FROM shopfloor_time_entries WHERE user_id = ? AND entry_type = "entrada" AND date(occurred_at) BETWEEN ? AND ?');
    $workedMapStmt->execute([$userId, $rangeStart, $rangeEnd]);
    $workedDateMap = [];
    foreach ($workedMapStmt->fetchAll(PDO::FETCH_ASSOC) as $workedRow) {
        $workedDate = (string) ($workedRow['work_date'] ?? '');
        if ($workedDate !== '') {
            $workedDateMap[$workedDate] = true;
        }
    }

    foreach ($approvedMinutesByDate as $dateKey => $approvedMinutes) {
        try {
            $dateObj = new DateTimeImmutable($dateKey);
        } catch (Exception $exception) {
            continue;
        }

        $weekday = (string) $dateObj->format('N');
        if (!isset($scheduleWeekdaysMap[$weekday]) || isset($blockedDates[$dateKey]) || isset($workedDateMap[$dateKey])) {
            continue;
        }

        $excludedMinutes = (int) ($excludedCode100MinutesByDate[$dateKey] ?? 0);
        $creditMinutes = max(0, (int) $approvedMinutes - $excludedMinutes);
        $bhAdjustmentMinutes += $creditMinutes;
    }
}

$validatedHourBankMinutes = class_exists('ValidatedHourBankCalculator')
    ? ValidatedHourBankCalculator::calculateMinutes($pdo, $userId)
    : null;
$storedHourBankMinutes = (int) round(((float) ($hourBank['balance_hours'] ?? 0)) * 60);
$displayedHourBankMinutes = ($validatedHourBankMinutes ?? $storedHourBankMinutes) + $bhAdjustmentMinutes;
$displayedHourBankAbsMinutes = abs($displayedHourBankMinutes);
$formattedHourBank = sprintf('%s%02dh%02dm', $displayedHourBankMinutes < 0 ? '-' : '', intdiv($displayedHourBankAbsMinutes, 60), $displayedHourBankAbsMinutes % 60);


ProductionOrderStatusService::syncAll($pdo,$userId);
$ofSql = 'SELECT o.id, o.order_number, o.product_id, fp.id AS finished_product_id, o.planned_quantity, o.status, COALESCE(NULLIF(json_extract(pos.snapshot_json,"$._order.lot"),""),NULLIF(json_extract(ts.snapshot_json,"$._order.lot"),""),o.order_number) AS lot, c.name AS customer_name, TRIM(COALESCE(c.postal_code,"") || " " || COALESCE(c.city,"")) AS customer_locality, COALESCE(fp.code,p.code) AS product_code, COALESCE(fp.description,p.description) AS product_description FROM erp_production_orders o JOIN erp_products p ON p.id = o.product_id LEFT JOIN erp_finished_products fp ON fp.id=o.finished_product_id OR (o.finished_product_id IS NULL AND fp.code=p.code) LEFT JOIN erp_customers c ON c.id=o.customer_id LEFT JOIN erp_production_order_snapshots pos ON pos.production_order_id=o.id LEFT JOIN erp_technical_sheets ts ON ts.production_order_id=o.id WHERE o.status IN ("Por iniciar", "Em Produção", "Em Pausa", "Planeada", "Em curso")';
$ofParams = [];
if ($selectedWorkCenterId > 0) {
    $ofSql .= ' AND EXISTS (SELECT 1 FROM erp_production_order_operations center_op WHERE center_op.production_order_id = o.id AND (center_op.work_center_id = ? OR EXISTS (SELECT 1 FROM json_each(CASE WHEN json_valid(center_op.allowed_work_center_ids_json) THEN center_op.allowed_work_center_ids_json ELSE "[]" END) allowed_center WHERE CAST(allowed_center.value AS INTEGER) = ?) OR (? > 0 AND center_op.machine_required = 1 AND EXISTS (SELECT 1 FROM json_each(CASE WHEN json_valid(center_op.allowed_machine_ids_json) THEN center_op.allowed_machine_ids_json ELSE "[]" END) allowed_machine WHERE CAST(allowed_machine.value AS INTEGER) = ?))))';
    $ofParams[] = $selectedWorkCenterId;
    $ofParams[] = $selectedWorkCenterId;
    $ofParams[] = $selectedWorkCenterMachineId;
    $ofParams[] = $selectedWorkCenterMachineId;
}
$ofSql .= ' ORDER BY o.due_date IS NULL, o.due_date, o.id DESC LIMIT 25';
$ofStmt = $pdo->prepare($ofSql);
$ofStmt->execute($ofParams);
$productionOrders = $ofStmt ? $ofStmt->fetchAll(PDO::FETCH_ASSOC) : [];

$selectedOfId = (int) ($_GET['of_id'] ?? ($productionOrders[0]['id'] ?? 0));
$selectedOf = null;
foreach ($productionOrders as $ofRow) { if ((int)$ofRow['id'] === $selectedOfId) { $selectedOf = $ofRow; break; } }
$ofDocuments = $ofOperations = $ofConsumptionMaterials = [];
$operationRequiredMaterials = $operationConsumptions = [];
$articleArtwork = null;
if ($selectedOfId > 0) {
    $docsStmt = $pdo->prepare('SELECT d.*, EXISTS(SELECT 1 FROM erp_production_order_document_acknowledgements a WHERE a.document_id=d.id AND a.user_id=?) AS acknowledged FROM erp_production_order_documents d WHERE d.production_order_id=? ORDER BY d.id');
    $docsStmt->execute([$userId, $selectedOfId]);
    $ofDocuments = $docsStmt->fetchAll(PDO::FETCH_ASSOC);
    if ($selectedOf && (int) ($selectedOf['finished_product_id'] ?? 0) > 0) {
        $artworkStmt = $pdo->prepare('SELECT id, document_type, title, file_url FROM erp_product_documents WHERE entity_type="finished_product" AND entity_id=? AND status="Ativo" ORDER BY id');
        $artworkStmt->execute([(int) $selectedOf['finished_product_id']]);
        $articleArtwork = ArticleDocument::mainArtwork($artworkStmt->fetchAll(PDO::FETCH_ASSOC));
        $consumptionMaterialsStmt = $pdo->prepare('SELECT rm.id,rm.code,rm.description,rm.roll_controlled,rm.ink_type_id,u.code unit_code,am.quantity_per_unit FROM erp_article_materials am JOIN erp_raw_materials rm ON rm.id=am.raw_material_id AND rm.status="Ativo" LEFT JOIN erp_units u ON u.id=rm.primary_unit_id WHERE am.finished_product_id=? ORDER BY rm.code COLLATE NOCASE');
        $consumptionMaterialsStmt->execute([(int) $selectedOf['finished_product_id']]);
        $ofConsumptionMaterials = $consumptionMaterialsStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    $opsSql = 'SELECT opo.*, COALESCE(opo.operation_code,op.code) code,COALESCE(opo.operation_name,op.name) name, op.standard_minutes, op.product_label_enabled, COALESCE(opo.requires_good_quantity,op.requires_good_quantity) requires_good_quantity, op.requires_waste, op.requires_waste_reason, COALESCE((SELECT SUM(COALESCE(te.quantity_good, 0)) FROM erp_operation_time_entries te WHERE te.production_order_operation_id=opo.id), 0) AS quantity_good, COALESCE((SELECT SUM(COALESCE(te.quantity_rejected, 0)) FROM erp_operation_time_entries te WHERE te.production_order_operation_id=opo.id), 0) AS quantity_rejected, (SELECT id FROM erp_operation_time_entries te WHERE te.production_order_operation_id=opo.id AND te.user_id=? AND te.ended_at IS NULL LIMIT 1) AS open_entry_id, (SELECT status FROM erp_operation_time_entries te WHERE te.production_order_operation_id=opo.id AND te.user_id=? AND te.ended_at IS NULL LIMIT 1) AS open_entry_status, (SELECT CAST(MAX(0, (julianday(CASE WHEN te.status="paused" THEN te.paused_at ELSE CURRENT_TIMESTAMP END)-julianday(te.started_at))*86400-te.pause_seconds) AS INTEGER) FROM erp_operation_time_entries te WHERE te.production_order_operation_id=opo.id AND te.user_id=? AND te.ended_at IS NULL LIMIT 1) AS open_elapsed_seconds, (SELECT COALESCE(SUM((julianday(CASE WHEN te.ended_at IS NOT NULL THEN te.ended_at WHEN te.status="paused" THEN te.paused_at ELSE CURRENT_TIMESTAMP END)-julianday(te.started_at))*1440)-SUM(te.pause_seconds)/60,0) FROM erp_operation_time_entries te WHERE te.production_order_operation_id=opo.id) actual_minutes, EXISTS(SELECT 1 FROM erp_operation_time_entries te WHERE te.production_order_operation_id=opo.id AND te.ended_at IS NULL AND te.status<>"paused") has_running_entry FROM erp_production_order_operations opo JOIN erp_operations op ON op.id=opo.operation_id WHERE opo.production_order_id=?';
    $opsParams = [$userId, $userId, $userId, $selectedOfId];
    $opsSql .= ' ORDER BY opo.sequence_no, opo.id';
    $opsStmt = $pdo->prepare($opsSql);
    $opsStmt->execute($opsParams);
    $ofOperations = $opsStmt->fetchAll(PDO::FETCH_ASSOC);
    $consumptionMaterialsStmt = $pdo->query('SELECT rm.id,rm.code,rm.description,rm.roll_controlled,rm.ink_type_id,u.code unit_code FROM erp_raw_materials rm LEFT JOIN erp_units u ON u.id=rm.primary_unit_id WHERE rm.status="Ativo" ORDER BY rm.code COLLATE NOCASE');
    $ofConsumptionMaterials = $consumptionMaterialsStmt ? $consumptionMaterialsStmt->fetchAll(PDO::FETCH_ASSOC) : [];
    $requiredMaterialsStmt = $pdo->prepare('SELECT required.production_order_operation_id,required.material_id,MAX(required.required_qty) required_qty,rm.code,rm.description,u.code unit_code FROM (SELECT r.production_order_operation_id,r.material_id,r.required_qty FROM erp_production_order_material_reservations r UNION ALL SELECT opo.id,sm.material_id,po.planned_quantity*sm.quantity_per_unit FROM erp_production_order_operations opo JOIN erp_production_orders po ON po.id=opo.production_order_id JOIN erp_routing_step_materials sm ON sm.routing_step_id=opo.routing_step_id) required JOIN erp_production_order_operations opo ON opo.id=required.production_order_operation_id JOIN erp_raw_materials rm ON rm.id=required.material_id LEFT JOIN erp_units u ON u.id=rm.primary_unit_id WHERE opo.production_order_id=? GROUP BY required.production_order_operation_id,required.material_id ORDER BY rm.code COLLATE NOCASE');
    $requiredMaterialsStmt->execute([$selectedOfId]);
    foreach ($requiredMaterialsStmt->fetchAll(PDO::FETCH_ASSOC) as $requiredMaterial) $operationRequiredMaterials[(int)$requiredMaterial['production_order_operation_id']][] = $requiredMaterial;
    $operationConsumptionsStmt = $pdo->prepare('SELECT pc.*,rm.code,rm.description,COALESCE(pc.unit_code,u.code) unit_code,CASE pc.stock_unit_type WHEN "ROLL" THEN rl.barcode WHEN "INK" THEN il.barcode END label_number FROM erp_production_consumptions pc JOIN erp_raw_materials rm ON rm.id=pc.raw_material_id LEFT JOIN erp_units u ON u.id=rm.primary_unit_id LEFT JOIN erp_raw_material_roll_labels rl ON pc.stock_unit_type="ROLL" AND rl.id=pc.stock_unit_id LEFT JOIN erp_raw_material_ink_labels il ON pc.stock_unit_type="INK" AND il.id=pc.stock_unit_id WHERE pc.production_order_id=? AND pc.production_order_operation_id IS NOT NULL ORDER BY pc.id');
    $operationConsumptionsStmt->execute([$selectedOfId]);
    foreach ($operationConsumptionsStmt->fetchAll(PDO::FETCH_ASSOC) as $consumption) $operationConsumptions[(int)$consumption['production_order_operation_id']][] = $consumption;
}

$pageTitle = 'Shopfloor';
$bodyClass = 'shopfloor-body';
$showProductionLabelShortcuts = true;
require __DIR__ . '/partials/header.php';
?>

<section class="shopfloor-shell">
    <div class="shopfloor-topbar">
        <div class="shopfloor-topbar-kpis" aria-label="Indicadores diários do colaborador">
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>T. Presença</h2>
                <strong data-daily-indicator="presence"><?= h(ShopfloorDailyIndicators::formatDuration($dailyIndicators['presence_seconds'])) ?></strong>
            </article>
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>T. Trabalhado</h2>
                <strong data-daily-indicator="worked"><?= h(ShopfloorDailyIndicators::formatDuration($dailyIndicators['worked_seconds'])) ?></strong>
            </article>
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>T. Morto</h2>
                <strong data-daily-indicator="dead"><?= h(ShopfloorDailyIndicators::formatDuration($dailyIndicators['dead_seconds'])) ?></strong>
            </article>
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>Produção</h2>
                <strong data-daily-indicator="production"><?= h(ShopfloorDailyIndicators::formatDuration($dailyIndicators['production_seconds'])) ?></strong>
            </article>
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>Pausas</h2>
                <strong data-daily-indicator="pauses"><?= h(ShopfloorDailyIndicators::formatDuration($dailyIndicators['pause_seconds'])) ?></strong>
                <span class="small text-secondary">(<span data-daily-indicator="pause_count"><?= (int) $dailyIndicators['pause_count'] ?></span>)</span>
            </article>
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>Paragens</h2>
                <strong data-daily-indicator="stoppages"><?= h(ShopfloorDailyIndicators::formatDuration($dailyIndicators['stoppage_seconds'])) ?></strong>
                <span class="small text-secondary">(<span data-daily-indicator="stoppage_count"><?= (int) $dailyIndicators['stoppage_count'] ?></span>)</span>
            </article>
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>BH</h2>
                <strong class="<?= $displayedHourBankMinutes < 0 ? 'text-danger' : '' ?>"><?= h($formattedHourBank) ?></strong>
            </article>
            <article class="shopfloor-kpi-card shopfloor-kpi-card-compact">
                <h2>Férias</h2>
                <strong><?= h(number_format($availableVacationDays, 1, ',', '.')) ?></strong>
            </article>
        </div>
    </div>

    <?php if ($flashSuccess || $flashError): ?>
        <div class="toast-container position-fixed shopfloor-toast-container" aria-live="polite" aria-atomic="true">
            <div class="toast align-items-center border-0 text-bg-<?= $flashError ? 'danger' : 'success' ?>" role="alert" data-shopfloor-notification data-bs-autohide="true" data-bs-delay="7000">
                <div class="d-flex">
                    <div class="toast-body fw-semibold"><?= h((string) ($flashError ?: $flashSuccess)) ?></div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Fechar"></button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="modal fade" id="productionLabelModal" tabindex="-1" aria-labelledby="productionLabelModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><div><h2 class="modal-title fs-5" id="productionLabelModalTitle">Imprimir etiqueta</h2><p class="small text-secondary mb-0">Selecione uma unidade para imprimir ou acertar as quantidades.</p></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button></div>
        <div class="modal-body">
          <div class="d-flex gap-2 mb-3" role="group" aria-label="Tipo de etiqueta"><button type="button" class="btn btn-primary flex-fill" data-label-type="ROLL" aria-pressed="true">📦 Rolo / Bobine</button><button type="button" class="btn btn-outline-primary flex-fill" data-label-type="INK" aria-pressed="false">🎨 Lata de tinta</button></div>
          <form method="post" id="stockLabelForm" class="border rounded p-3">
            <?=csrf_input()?><input type="hidden" name="action" value="adjust_stock_label"><input type="hidden" name="unit_type" value="ROLL"><input type="hidden" name="expected_weight"><input type="hidden" name="expected_metres"><input type="hidden" name="idempotency_key" value="<?=h(bin2hex(random_bytes(16)))?>">
            <label class="form-label fw-semibold" for="stockLabelNumber" data-label-prompt>Nº da etiqueta do rolo</label><div class="input-group input-group-lg"><input id="stockLabelNumber" class="form-control" name="label_number" autocomplete="off" enterkeyhint="search" required><button type="button" class="btn btn-outline-primary" data-label-search>Pesquisar</button></div>
            <div class="mt-3" data-label-result aria-live="polite"></div>
            <div data-label-actions hidden><a class="btn btn-primary mt-3" data-label-print target="_blank" rel="noopener">Imprimir etiqueta</a><div class="form-check mt-3"><input type="checkbox" class="form-check-input" id="labelAdjust"><label class="form-check-label" for="labelAdjust">Acertar quantidades</label></div>
              <fieldset data-label-adjust hidden disabled class="mt-3"><div class="row g-2"><div class="col"><label class="form-label" for="labelWeight">Peso atual (kg)</label><input class="form-control" id="labelWeight" name="weight_kg" type="number" min="0" step="0.001" required></div><div class="col" data-label-metres><label class="form-label" for="labelMetres">Metros atuais</label><input class="form-control" id="labelMetres" name="metres" type="number" min="0" step="0.001"></div></div><label class="form-label mt-2" for="labelReason">Motivo do acerto</label><input class="form-control" id="labelReason" name="reason" required maxlength="500"><button class="btn btn-primary w-100 mt-3">Guardar acerto e imprimir</button></fieldset>
            </div>
          </form>
        </div><div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Fechar</button></div>
      </div></div>
    </div>

    <?php if ($selectedOf): ?>
    <div class="modal fade" id="productGoodsLabelModal" tabindex="-1" aria-labelledby="productGoodsLabelTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered"><div class="modal-content"><form method="post" action="product_label.php" target="_blank">
        <?= csrf_input() ?><input type="hidden" name="production_order_id" value="<?= (int)$selectedOf['id'] ?>"><input type="hidden" name="central_request_key" value="<?=h(bin2hex(random_bytes(16)))?>"><input type="hidden" name="operation_id" id="productLabelOperationId">
        <div class="modal-header"><div><span class="small text-success fw-bold text-uppercase">Produção</span><h2 class="modal-title fs-5" id="productGoodsLabelTitle">Etiqueta de produto</h2></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button></div>
        <div class="modal-body"><dl class="row small mb-3"><dt class="col-3">Cliente</dt><dd class="col-9 fw-semibold"><?= h((string)$selectedOf['customer_name']) ?><br><span class="text-secondary"><?= h((string)$selectedOf['customer_locality']) ?></span></dd><dt class="col-3">Produto</dt><dd class="col-9 fw-semibold text-break"><?= h((string)$selectedOf['product_code']) ?></dd><dt class="col-3">Descrição</dt><dd class="col-9"><?= h((string)$selectedOf['product_description']) ?></dd><dt class="col-3">Lote</dt><dd class="col-9 fw-semibold"><?= h((string)$selectedOf['lot']) ?></dd></dl>
          <div class="row g-3"><div class="col-7"><label class="form-label fw-semibold" for="productLabelQuantity">Quantidade</label><input class="form-control form-control-lg" id="productLabelQuantity" name="quantity" type="number" inputmode="decimal" min="0.001" step="0.001" required></div><div class="col-5"><label class="form-label fw-semibold" for="productLabelDate">Data</label><input class="form-control form-control-lg" id="productLabelDate" name="label_date" type="date" value="<?= date('Y-m-d') ?>" required></div><div class="col-12"><label class="form-label fw-semibold" for="productLabelCopies">N.º de etiquetas</label><div class="input-group input-group-lg"><button class="btn btn-outline-secondary" type="button" data-copy-step="-1" aria-label="Retirar uma etiqueta">−</button><input class="form-control text-center" id="productLabelCopies" name="copies" type="number" inputmode="numeric" min="1" max="99" value="1" required><button class="btn btn-outline-secondary" type="button" data-copy-step="1" aria-label="Adicionar uma etiqueta">+</button></div></div></div>
        </div><div class="modal-footer"><button class="btn btn-outline-primary btn-lg" name="mode" value="preview"><i class="bi bi-eye me-1"></i>Pré-visualizar</button><button class="btn btn-primary btn-lg" name="mode" value="print"><i class="bi bi-printer me-1"></i>Imprimir</button></div>
      </form></div></div>
    </div>
    <?php endif; ?>

    <div class="modal fade" id="workCenterModal" tabindex="-1" aria-labelledby="workCenterModalLabel" aria-hidden="true" data-requires-selection="<?= $selectedWorkCenter ? '0' : '1' ?>">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div><h2 class="modal-title fs-5" id="workCenterModalLabel">Centro de trabalho deste dispositivo</h2><p class="small text-secondary mb-0">A escolha fica memorizada neste equipamento para os próximos logins.</p></div>
                    <?php if ($selectedWorkCenter): ?><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button><?php endif; ?>
                </div>
                <div class="modal-body">
                    <?php if ($workCenters): ?>
                        <div class="d-grid gap-2">
                            <?php foreach ($workCenters as $center): ?>
                                <form method="post" class="js-work-center-form">
                                    <?= csrf_input() ?>
                                    <input type="hidden" name="action" value="select_work_center">
                                    <input type="hidden" name="work_center_id" value="<?= (int) $center['id'] ?>">
                                    <button class="btn <?= (int) $center['id'] === $selectedWorkCenterId ? 'btn-primary' : 'btn-outline-primary' ?> text-start w-100" type="submit">
                                        <strong><?= h((string) $center['code']) ?></strong> · <?= h((string) $center['name']) ?>
                                        <?php if ((int) ($center['is_active'] ?? 0) !== 1): ?><span class="badge text-bg-warning ms-1">Inativo</span><?php endif; ?>
                                        <?php if (!empty($center['printer_name'])): ?><span class="d-block small mt-1"><i class="bi bi-printer me-1"></i><?= h((string) $center['printer_name']) ?></span><?php endif; ?>
                                    </button>
                                </form>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning mb-0">Ainda não existem centros de trabalho ativos. Solicite a configuração no ERP.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php if ($pendingAnnouncementAck): ?>
        <div class="modal fade" id="shopfloorAnnouncementAcknowledgeModal" tabindex="-1" aria-labelledby="shopfloorAnnouncementAcknowledgeModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title fs-5" id="shopfloorAnnouncementAcknowledgeModalLabel"><?= h((string) $pendingAnnouncementAck['title']) ?></h2>
                    </div>
                    <div class="modal-body">
                        <p class="small text-secondary mb-2">Comunicado emitido por <?= h((string) $pendingAnnouncementAck['created_by_name']) ?> em <?= h((string) $pendingAnnouncementAck['created_at']) ?>.</p>
                        <div class="border rounded p-3 bg-light"><?= nl2br(h((string) $pendingAnnouncementAck['body'])) ?></div>
                    </div>
                    <div class="modal-footer">
                        <form method="post" class="w-100 d-grid">
                            <input type="hidden" name="action" value="acknowledge_announcement">
                            <input type="hidden" name="announcement_id" value="<?= (int) $pendingAnnouncementAck['id'] ?>">
                            <button type="submit" class="btn btn-primary btn-lg fw-semibold">Tomei conhecimento</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="<?= $pendingAnnouncementAck ? 'd-none' : '' ?>">

    <div class="shopfloor-panel mb-4">
        <div class="shopfloor-panel-header flex-wrap gap-2">
            <h2 class="h4 mb-0">Produção - escolher OF</h2>
            <div class="small text-secondary" data-shopfloor-order-summary>
                <strong>Qtd Planeada:</strong> <?= $selectedOf ? h(shopfloor_format_quantity((float) $selectedOf['planned_quantity'])) : '—' ?>
                <span class="mx-1">|</span>
                <strong>Estado da OF:</strong> <?= $selectedOf ? h((string) $selectedOf['status']) : '—' ?>
            </div>
        </div>
        <form method="get" class="row g-2 align-items-end mb-3" data-of-picker-form><div class="col-md-8"><label class="form-label" for="shopfloorOfSearch">Ordem de fabrico</label><input type="search" id="shopfloorOfSearch" class="form-control shopfloor-of-search" list="shopfloorOfOptions" autocomplete="off" enterkeyhint="search" inputmode="search" data-of-search value="<?= $selectedOf ? h($selectedOf['order_number'].' · '.$selectedOf['product_code'].' · '.$selectedOf['product_description']) : '' ?>" placeholder="Pesquisar por código, nome ou referência..."><input type="hidden" name="of_id" data-of-id value="<?= (int)$selectedOfId ?>"><datalist id="shopfloorOfOptions"><?php foreach ($productionOrders as $of): ?><option data-id="<?= (int)$of['id'] ?>" value="<?= h($of['order_number'].' · '.$of['product_code'].' · '.$of['product_description']) ?>"></option><?php endforeach; ?></datalist></div><div class="col-md-4"><button class="btn btn-primary w-100">Abrir OF</button></div></form>
        <?php if ($selectedOf): ?>
            <h3 class="h6">Documentos obrigatórios</h3>
            <div class="list-group mb-3"><?php if (!$ofDocuments): ?><div class="list-group-item text-secondary">Sem documentos anexados.</div><?php endif; foreach ($ofDocuments as $doc): ?><div class="list-group-item d-flex justify-content-between gap-2"><div><strong><?= h($doc['title']) ?></strong><?php if (!empty($doc['document_url'])): ?> · <a target="_blank" href="<?= h($doc['document_url']) ?>">visualizar</a><?php endif; ?><div class="small text-secondary"><?= nl2br(h((string)$doc['body'])) ?></div></div><form method="post"><input type="hidden" name="action" value="ack_of_document"><input type="hidden" name="document_id" value="<?= (int)$doc['id'] ?>"><button class="btn btn-sm <?= (int)$doc['acknowledged']===1?'btn-success':'btn-outline-success' ?>"><?= (int)$doc['acknowledged']===1?'Confirmado':'Tomei conhecimento' ?></button></form></div><?php endforeach; ?></div>
            <h3 class="h6">Operações</h3>
            <div class="shopfloor-operation-grid">
            <?php foreach ($ofOperations as $op):
                $isOpen = (int) ($op['open_entry_id'] ?? 0) > 0;
                $isPaused = $isOpen && (string) ($op['open_entry_status'] ?? '') === 'paused';
                $checklistPhase = $isOpen ? 'end' : 'start';
                $showChecklist = $operationChecklistService->isRequired($op, $userId, $checklistPhase);
                $operationChecklistItems = $showChecklist ? $operationChecklistService->items((int) $op['checklist_template_id']) : [];
                $canRunHere = shopfloor_operation_can_run_at_work_center($op, $selectedWorkCenterId, $selectedWorkCenterMachineId);
            ?>
                <?php
                    $operationStatusClass = $isPaused ? 'is-paused' : ($isOpen ? 'is-running' : ((string)$op['status'] === 'Concluída' ? 'is-completed' : 'is-pending'));
                    $operationFormId = 'shopfloor-operation-form-'.(int)$op['id'];
                ?>
                <article class="shopfloor-operation-card <?= $isOpen ? 'is-active' : '' ?> <?= !$canRunHere ? 'is-monitor-only' : '' ?>">
                    <div class="shopfloor-operation-content">
                        <header class="shopfloor-operation-card-header">
                            <div class="shopfloor-operation-heading">
                                <span class="shopfloor-operation-sequence" aria-label="Sequência <?= (int)$op['sequence_no'] ?>"><?= (int)$op['sequence_no'] ?></span>
                                <h4><?= h($op['code'].' - '.$op['name']) ?></h4>
                            </div>
                            <span class="shopfloor-operation-status <?= h($operationStatusClass) ?>"><?= h($op['status']) ?><?= $isPaused ? ' · Pausada' : '' ?></span>
                        </header>
                        <?php if ((int)($op['requires_good_quantity']??1) === 1): $productivityPercentage=shopfloor_productivity_percentage((float)($op['quantity_good']??0),(float)($selectedOf['planned_quantity']??0),(float)($op['actual_minutes']??0),(float)($op['planned_minutes']??0)); ?>
                            <div class="shopfloor-productivity-compact <?= h($operationStatusClass) ?>" data-productivity data-planned-quantity="<?=h((string)($selectedOf['planned_quantity']??0))?>" data-planned-minutes="<?=h((string)($op['planned_minutes']??0))?>" data-actual-minutes="<?=h((string)($op['actual_minutes']??0))?>" data-running="<?=!empty($op['has_running_entry'])?'1':'0'?>" data-realized-quantity="<?=h((string)($op['quantity_good']??0))?>" data-rejected-quantity="<?=h((string)($op['quantity_rejected']??0))?>">
                                <div class="shopfloor-productivity-heading"><span>Produtividade</span><strong data-productivity-value><?=$productivityPercentage===null?'—':h(number_format($productivityPercentage,0,',','.')).'%'?></strong></div>
                                <div class="progress" role="progressbar" aria-label="Ritmo de produção real face ao ritmo previsto" aria-valuemin="0" aria-valuemax="200" aria-valuenow="<?=h((string)min(200,max(0,round($productivityPercentage??0))))?>"><div class="progress-bar" data-productivity-bar style="width:<?=h((string)min(100,max(0,$productivityPercentage??0)))?>%"></div></div>
                                <small data-productivity-detail><?=$productivityPercentage===null?'Sem dados suficientes para calcular.':h(shopfloor_format_quantity((float)($op['quantity_good']??0))).' OK / '.h(shopfloor_format_quantity((float)($op['quantity_rejected']??0))).' NOK'?></small>
                            </div>
                        <?php endif; ?>
                        <?php if (trim((string)($op['instructions']??'')) !== ''): ?><div class="small text-secondary shopfloor-operation-instructions"><?=nl2br(h((string)$op['instructions']))?></div><?php endif; ?>
                        <div class="shopfloor-operation-metrics">
                            <div><span><i class="bi bi-clock" aria-hidden="true"></i> Previsto</span><strong><?=h(number_format((float)($op['planned_minutes']??0),1,',','.'))?> min</strong></div>
                            <div><span><i class="bi bi-stopwatch" aria-hidden="true"></i> Real</span><strong><?=h(number_format((float)($op['actual_minutes']??0),1,',','.'))?> min</strong></div>
                            <div><span><i class="bi bi-box-seam" aria-hidden="true"></i> Produção</span><strong><?=(int)($op['requires_good_quantity']??1)===1?h(shopfloor_format_quantity((float)($op['quantity_good']??0))).' / '.h(shopfloor_format_quantity((float)($selectedOf['planned_quantity']??0))):((string)$op['status']==='Concluída'?'100%':'—')?></strong></div>
                        </div>
                        <?php if ($isOpen): ?><div class="shopfloor-operation-live-time"><i class="bi bi-record-circle" aria-hidden="true"></i><span><?= $isPaused ? 'Em pausa' : 'Tempo atual' ?></span><strong class="<?= $isPaused ? 'text-warning' : 'text-primary' ?>" data-production-timer data-elapsed-seconds="<?= (int)($op['open_elapsed_seconds']??0) ?>" data-running="<?= $isPaused ? '0' : '1' ?>">00:00:00</strong></div><?php endif; ?>
                        <form method="post" id="<?=h($operationFormId)?>" class="row g-2 shopfloor-operation-actions">
                            <input type="hidden" name="action" value="<?= $isOpen ? 'stop_of_operation' : 'start_of_operation' ?>">
                            <?php if ($isOpen): ?><input type="hidden" name="entry_id" value="<?=(int)$op['open_entry_id']?>"><?php else: ?><input type="hidden" name="po_operation_id" value="<?=(int)$op['id']?>"><?php endif; ?>
                            <?php if ($showChecklist && $isOpen): ?><div class="col-12 border rounded bg-light p-2"><div class="fw-semibold mb-2"><?=($op['checklist_timing']??'')==='first'?'Checklist · primeira execução nesta OF':'Checklist · fim'?></div>
                                <?php foreach ($operationChecklistItems as $checkItem): $fieldId='checklist-'.$op['id'].'-'.$checkItem['id'];$fieldType=(string)($checkItem['field_type']?:'checkbox');$required=(int)$checkItem['is_required']===1; ?>
                                    <div class="mb-2"><label class="form-label small mb-1" for="<?=h($fieldId)?>"><?=h($checkItem['content'])?><?=$required?' *':''?></label>
                                    <?php if($fieldType==='checkbox'): ?><div><input class="form-check-input" id="<?=h($fieldId)?>" type="checkbox" name="checklist[<?=(int)$checkItem['id']?>]" value="1" <?=$required?'required':''?>></div>
                                    <?php elseif($fieldType==='textarea'): ?><textarea class="form-control form-control-sm" id="<?=h($fieldId)?>" name="checklist[<?=(int)$checkItem['id']?>]" <?=$required?'required':''?>></textarea>
                                    <?php elseif($fieldType==='select'): ?><select class="form-select form-select-sm" id="<?=h($fieldId)?>" name="checklist[<?=(int)$checkItem['id']?>]" <?=$required?'required':''?>><option value="">Escolher…</option><?php foreach(json_decode((string)$checkItem['options_json'],true)?:[] as$option):?><option value="<?=h($option)?>"><?=h($option)?></option><?php endforeach;?></select>
                                    <?php else: ?><input class="form-control form-control-sm" id="<?=h($fieldId)?>" type="<?=in_array($fieldType,['number','date'],true)?$fieldType:'text'?>" name="checklist[<?=(int)$checkItem['id']?>]" <?=$fieldType==='number'?'step="any"':''?> <?=$required?'required':''?>><?php endif; ?></div>
                                <?php endforeach; ?></div><?php endif; ?>
                            <?php if ($isOpen): ?>
                                <?php if ((int)($op['requires_good_quantity']??1)===1): ?><div class="col-6 col-xl"><input class="form-control form-control-sm" type="number" min="0" step="0.001" name="quantity_good" placeholder="Qtd. OK (opcional)" inputmode="decimal" data-productivity-quantity></div><?php else: ?><input type="hidden" name="quantity_good" value="0"><?php endif; ?><?php if ((int)($op['requires_good_quantity']??1)===1&&(int)($op['requires_waste']??1)===1): ?><div class="col-6 col-xl"><input class="form-control form-control-sm" type="number" min="0" step="0.001" name="quantity_rejected" placeholder="NOK" inputmode="decimal" data-productivity-rejected></div><?php else: ?><input type="hidden" name="quantity_rejected" value="0"><?php endif; ?><?php if ((int)($op['requires_good_quantity']??1)===1&&(int)($op['requires_waste_reason']??1)===1): ?><div class="col-6 col-xl"><input class="form-control form-control-sm" name="waste_reason" placeholder="Motivo NOK"></div><?php endif; ?><div class="col-6 col-xl"><select class="form-select form-select-sm" name="quality_result"><option value="">Qualidade…</option><option value="pass">Conforme</option><option value="fail">Não conforme</option><option value="na">N/A</option></select></div>
                            <?php endif; ?>
                        </form>
                    </div>
                    <aside class="shopfloor-operation-action-rail" aria-label="Ações de <?=h($op['code'].' - '.$op['name'])?>">
                        <?php if (!$canRunHere): ?>
                            <button type="button" class="shopfloor-operation-action" disabled title="Operação disponível apenas para acompanhamento neste posto" aria-label="Apenas acompanhamento"><i class="bi bi-eye" aria-hidden="true"></i></button>
                        <?php else: ?>
                            <button class="shopfloor-operation-action <?= $isOpen ? 'is-stop' : 'is-start' ?>" type="submit" form="<?=h($operationFormId)?>" title="<?= $isOpen ? 'Terminar operação' : 'Iniciar operação' ?>" aria-label="<?= $isOpen ? 'Terminar operação' : 'Iniciar operação' ?>"><i class="bi <?= $isOpen ? 'bi-stop-fill' : 'bi-play-fill' ?>" aria-hidden="true"></i></button>
                        <?php endif; ?>
                        <?php if ($isOpen && $canRunHere): ?><form method="post"><input type="hidden" name="action" value="<?= $isPaused ? 'resume_operation' : 'pause_operation' ?>"><input type="hidden" name="entry_id" value="<?=(int)$op['open_entry_id']?>"><button class="shopfloor-operation-action <?= $isPaused ? 'is-resume' : '' ?>" title="<?= $isPaused ? 'Retomar produção' : 'Pausar produção' ?>" aria-label="<?= $isPaused ? 'Retomar produção' : 'Pausar produção' ?>"><i class="bi <?= $isPaused ? 'bi-play-circle' : 'bi-pause-fill' ?>" aria-hidden="true"></i></button></form><?php endif; ?>
                        <button type="button" class="shopfloor-operation-action" data-bs-toggle="modal" data-bs-target="#materialConsumptionModal-<?=(int)$op['id']?>" <?= $ofConsumptionMaterials ? 'title="Registar consumo" aria-label="Registar consumo"' : 'disabled title="Não existem materiais ativos" aria-label="Registar consumo indisponível"' ?>><i class="bi bi-box-seam" aria-hidden="true"></i></button>
                        <?php if(gt_erp_user_can($pdo,$user,'ink.prepare')):?><a class="shopfloor-operation-action" href="colorimetry.php?tab=stock&amp;production_order_id=<?=$selectedOfId?>" title="Consumir tinta preparada nesta OF" aria-label="Consumir tinta preparada nesta OF"><i class="bi bi-palette-fill" aria-hidden="true"></i></a><?php endif;?>
                        <?php if(!empty($op['product_label_enabled'])):?><button type="button" class="shopfloor-operation-action" data-bs-toggle="modal" data-bs-target="#productGoodsLabelModal" data-product-label-operation="<?=(int)$op['id']?>" data-product-label-quantity="<?=h((string)((float)$op['quantity_good']>0?$op['quantity_good']:$selectedOf['planned_quantity']))?>" title="Imprimir etiqueta" aria-label="Imprimir etiqueta"><i class="bi bi-tag" aria-hidden="true"></i></button><?php endif;?>
                    </aside>
                </article>
                <?php
                    $requiredConsumptionRows = $operationRequiredMaterials[(int)$op['id']] ?? [];
                    $savedConsumptionRows = $operationConsumptions[(int)$op['id']] ?? [];
                    $suggestRoll=false;$suggestInk=false;
                    foreach($requiredConsumptionRows as $requiredRow){foreach($ofConsumptionMaterials as $candidate){if((int)$candidate['id']===(int)$requiredRow['material_id']){$suggestRoll=$suggestRoll||!empty($candidate['roll_controlled']);$suggestInk=$suggestInk||!empty($candidate['ink_type_id']);}}}
                ?>
                <div class="modal fade" id="materialConsumptionModal-<?= (int)$op['id'] ?>" tabindex="-1" aria-labelledby="materialConsumptionTitle-<?= (int)$op['id'] ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
                        <div class="modal-header"><div><h2 class="modal-title fs-5" id="materialConsumptionTitle-<?= (int)$op['id'] ?>">Registar consumo</h2><p class="small text-secondary mb-0"><?=h($op['code'].' - '.$op['name'])?></p></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button></div>
                        <div class="modal-body">
                            <?php if($requiredConsumptionRows):?><div class="alert alert-light border"><strong>Consumo previsto</strong><?php foreach($requiredConsumptionRows as $planned):?><div class="small"><?=h($planned['code'].' · '.$planned['description'])?></div><?php endforeach;?></div><?php endif;?>
                            <div class="d-grid d-sm-flex gap-2 mb-3" role="tablist">
                                <button type="button" class="btn <?= $suggestRoll?'btn-primary':'btn-outline-primary' ?> flex-fill" data-consumption-mode="ROLL">📦 Rolo / Bobine<?= $suggestRoll?' · sugerido':''?></button>
                                <button type="button" class="btn <?= $suggestInk?'btn-primary':'btn-outline-primary' ?> flex-fill" data-consumption-mode="INK">🎨 Lata de tinta<?= $suggestInk?' · sugerido':''?></button>
                                <button type="button" class="btn <?= !$suggestRoll&&!$suggestInk?'btn-primary':'btn-outline-primary' ?> flex-fill" data-consumption-mode="DIRECT">⚖ Consumo direto</button>
                            </div>
                            <form method="post" data-unit-consumption-form class="border rounded p-3 mb-3 d-none"><input type="hidden" name="action" value="start_unit_consumption"><input type="hidden" name="po_operation_id" value="<?=(int)$op['id']?>"><input type="hidden" name="unit_type"><input type="hidden" name="idempotency_key" value="<?=h(bin2hex(random_bytes(16)))?>"><label class="form-label fw-semibold" data-unit-label>Nº da etiqueta</label><div class="input-group input-group-lg"><input class="form-control" name="label_number" autocomplete="off" enterkeyhint="search" required><button class="btn btn-outline-primary" type="button" data-lookup-unit>Pesquisar</button></div><div class="mt-3" data-unit-result aria-live="polite"></div><button class="btn btn-success btn-lg w-100 mt-3 d-none" data-confirm-unit>Usar esta unidade</button></form>
                            <form method="post" data-material-consumption-form class="border rounded p-3 mb-3 d-none"><input type="hidden" name="action" value="register_material_consumption"><input type="hidden" name="po_operation_id" value="<?=(int)$op['id']?>"><input type="hidden" name="idempotency_key" value="<?=h(bin2hex(random_bytes(16)))?>"><div data-consumption-rows><div class="row g-2" data-consumption-row><div class="col-md-8"><label class="form-label">Material</label><select class="form-select" name="raw_material_id[]" data-consumption-material required><option value="">Escolher…</option><?php foreach($ofConsumptionMaterials as $material):?><option value="<?=(int)$material['id']?>" data-unit="<?=h((string)($material['unit_code']?:'un.'))?>"><?=h($material['code'].' · '.$material['description'])?></option><?php endforeach;?></select></div><div class="col"><label class="form-label">Quantidade (<span data-consumption-unit>un.</span>)</label><input class="form-control" type="number" name="quantity[]" min="0.001" step="0.001" inputmode="decimal" required></div></div></div><button type="button" class="btn btn-outline-primary mt-3" data-add-consumption-row>+ Adicionar consumo extra</button><template data-consumption-row-template><div class="row g-2 mt-1" data-consumption-row><div class="col-md-8"><select class="form-select" name="raw_material_id[]" data-consumption-material required><option value="">Escolher material…</option><?php foreach($ofConsumptionMaterials as $material):?><option value="<?=(int)$material['id']?>" data-unit="<?=h((string)($material['unit_code']?:'un.'))?>"><?=h($material['code'].' · '.$material['description'])?></option><?php endforeach;?></select></div><div class="col"><input class="form-control" type="number" name="quantity[]" min="0.001" step="0.001" required></div><div class="col-auto"><button type="button" class="btn btn-outline-danger" data-remove-consumption-row aria-label="Remover"><i class="bi bi-trash"></i></button></div></div></template><button class="btn btn-primary btn-lg w-100 mt-3">Registar consumo direto</button></form>
                            <?php if($savedConsumptionRows):?><h3 class="h6 mt-4">Consumos reais da operação</h3><div class="list-group"><?php foreach($savedConsumptionRows as $used):?><div class="list-group-item"><div class="d-flex justify-content-between gap-2"><div><strong><?=h($used['label_number']?:$used['code'])?></strong><div class="small text-secondary"><?=h($used['description'])?></div></div><strong><?=h(shopfloor_format_quantity((float)$used['quantity']))?> <?=h($used['unit_code']?:'kg')?></strong></div><?php if($used['stock_unit_id']&&!$used['completed_at']):?><form method="post" class="row g-2 align-items-end mt-2"><input type="hidden" name="action" value="finish_unit_consumption"><input type="hidden" name="consumption_id" value="<?=(int)$used['id']?>"><input type="hidden" name="idempotency_key" value="<?=h(bin2hex(random_bytes(16)))?>"><div class="col"><label class="form-label">Restante (inicial: <?=h(shopfloor_format_quantity((float)$used['quantity_before']))?> kg)</label><input class="form-control" type="number" min="0" max="<?=h((string)$used['quantity_before'])?>" step="0.001" name="remaining_quantity" required></div><div class="col-auto"><button class="btn btn-primary">Fechar utilização</button></div><div class="col-auto"><button class="btn btn-outline-danger" name="finished_unit" value="1" formnovalidate>Unidade terminada</button></div></form><?php elseif($used['stock_unit_id']):?><a class="btn btn-sm btn-outline-secondary mt-2" target="_blank" rel="noopener" href="<?=h($used['stock_unit_type']==='ROLL'?'raw_material_roll_label.php':'raw_material_ink_label.php')?>?raw_material_id=<?=(int)$used['raw_material_id']?>&amp;<?= $used['stock_unit_type']==='ROLL'?'printed_label_id':'label_id' ?>=<?=(int)$used['stock_unit_id']?>&amp;print=1">Imprimir etiqueta atualizada</a><?php endif;?></div><?php endforeach;?></div><?php endif;?>
                        </div>
                        <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Fechar</button></div>
                    </div></div>
                </div>
            <?php endforeach; ?></div>
            <?php foreach ($ofOperations as $op):
                $isOpen = (int) ($op['open_entry_id'] ?? 0) > 0;
                $showStartChecklist = $isOpen && $operationChecklistService->isRequired($op, $userId, 'start');
                if (!$showStartChecklist) continue;
                $startChecklistItems = $operationChecklistService->items((int) $op['checklist_template_id']);
            ?>
                <div class="modal fade shopfloor-checklist-modal" id="operationChecklistModal-<?= (int)$op['id'] ?>" tabindex="-1" aria-labelledby="operationChecklistTitle-<?= (int)$op['id'] ?>" aria-hidden="true" data-auto-show-checklist data-bs-backdrop="static" data-bs-keyboard="false">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"><div class="modal-content"><form method="post">
                        <input type="hidden" name="action" value="validate_operation_checklist"><input type="hidden" name="po_operation_id" value="<?= (int)$op['id'] ?>">
                        <div class="modal-header"><div><span class="small text-success fw-bold text-uppercase">Produção iniciada</span><h2 class="modal-title fs-5" id="operationChecklistTitle-<?= (int)$op['id'] ?>">Checklist · <?= h($op['code'].' - '.$op['name']) ?></h2></div></div>
                        <div class="modal-body"><p class="text-secondary">A contagem de tempo já começou. Valide os pontos seguintes para continuar.</p>
                            <?php foreach ($startChecklistItems as $checkItem): $fieldId='start-checklist-'.$op['id'].'-'.$checkItem['id'];$fieldType=(string)($checkItem['field_type']?:'checkbox');$required=(int)$checkItem['is_required']===1; ?>
                                <div class="shopfloor-checklist-field"><label class="form-label" for="<?=h($fieldId)?>"><?=h($checkItem['content'])?><?=$required?' *':''?></label>
                                <?php if($fieldType==='checkbox'): ?><input class="form-check-input" id="<?=h($fieldId)?>" type="checkbox" name="checklist[<?=(int)$checkItem['id']?>]" value="1" <?=$required?'required':''?>>
                                <?php elseif($fieldType==='textarea'): ?><textarea class="form-control" id="<?=h($fieldId)?>" name="checklist[<?=(int)$checkItem['id']?>]" rows="3" <?=$required?'required':''?>></textarea>
                                <?php elseif($fieldType==='select'): ?><select class="form-select" id="<?=h($fieldId)?>" name="checklist[<?=(int)$checkItem['id']?>]" <?=$required?'required':''?>><option value="">Escolher…</option><?php foreach(json_decode((string)$checkItem['options_json'],true)?:[] as$option):?><option value="<?=h($option)?>"><?=h($option)?></option><?php endforeach;?></select>
                                <?php else: ?><input class="form-control" id="<?=h($fieldId)?>" type="<?=in_array($fieldType,['number','date'],true)?$fieldType:'text'?>" name="checklist[<?=(int)$checkItem['id']?>]" <?=$fieldType==='number'?'step="any" inputmode="decimal"':''?> <?=$required?'required':''?>><?php endif; ?></div>
                            <?php endforeach; ?>
                        </div><div class="modal-footer"><button type="submit" class="btn btn-success w-100">Validar checklist e continuar</button></div>
                    </form></div></div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <section class="shopfloor-panel mb-4" aria-labelledby="humanResourcesHeading">
        <button
            class="shopfloor-panel-header shopfloor-collapsible-trigger w-100 border-0 bg-transparent p-0 text-start"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#humanResourcesPanel"
            aria-expanded="false"
            aria-controls="humanResourcesPanel"
        >
            <span>
                <span class="d-block h4 mb-1" id="humanResourcesHeading">Recursos humanos</span>
                <span class="small text-secondary fw-normal">Comunicação, gestão de ausências e pedidos de férias</span>
            </span>
            <i class="bi bi-chevron-down shopfloor-collapse-icon" aria-hidden="true"></i>
        </button>
        <div class="collapse mt-4" id="humanResourcesPanel">
    <div class="shopfloor-panel mb-4">
        <div class="shopfloor-panel-header">
            <h2 class="h4 mb-0">Pedidos de ausência</h2>
            <?php if ($hasOpenClockEntryToday): ?>
                <button class="btn btn-secondary btn-sm fw-semibold" type="button" disabled aria-disabled="true">Novo pedido</button>
            <?php else: ?>
                <button class="btn btn-primary btn-sm fw-semibold" type="button" data-bs-toggle="collapse" data-bs-target="#absenceFormPanel" aria-expanded="false" aria-controls="absenceFormPanel">Novo pedido</button>
            <?php endif; ?>
        </div>
        <?php if ($hasOpenClockEntryToday): ?>
            <p class="small text-secondary mb-3">Os pedidos de ausência só podem ser criados quando não existe ponto em aberto no dia atual.</p>
        <?php endif; ?>

        <div class="collapse mb-3" id="absenceFormPanel">
            <form method="post" class="shopfloor-form-grid shopfloor-form-grid-request" id="absenceRequestForm">
                <input type="hidden" name="action" value="submit_absence">
                <div>
                    <label class="form-label">Tipo</label>
                    <select name="request_type" class="form-select" id="absenceRequestType" required>
                        <option value="Dias inteiros">Dia(s) inteiro(s)</option>
                        <option value="Intervalo de tempo">Intervalo de tempo</option>
                    </select>
                </div>
                <div>
                    <label class="form-label d-flex justify-content-between align-items-center gap-2">
                        <span>Motivo (RH)</span>
                        <?php if ($isAdmin || $isRh): ?>
                            <a href="shopfloor_absence_reasons.php" class="small link-primary">Gerir motivos</a>
                        <?php endif; ?>
                    </label>
                    <select name="reason_id" class="form-select shopfloor-reason-select d-none" id="absenceReasonSelect">
                        <option value="" data-color="#475569">Selecionar motivo</option>
                        <?php foreach ($absenceReasons as $reasonOption): ?>
                            <option value="<?= (int) $reasonOption['id'] ?>" data-color="<?= h((string) ($reasonOption['color'] ?? '#1e293b')) ?>"><?= h((string) $reasonOption['reason_code']) ?> · <?= h(normalize_sage_code((string) $reasonOption['sage_code'])) ?> — <?= h((string) $reasonOption['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="shopfloor-reason-picker" id="absenceReasonPicker">
                        <button type="button" class="form-select text-start shopfloor-reason-picker-toggle" data-role="toggle">Selecionar motivo</button>
                        <div class="shopfloor-reason-picker-menu d-none" data-role="menu">
                            <input type="text" class="form-control form-control-sm shopfloor-reason-picker-search" data-role="search" placeholder="Pesquisar por código ou motivo">
                            <div class="shopfloor-reason-picker-list" data-role="list">
                                <?php foreach ($absenceReasons as $reasonOption): ?>
                                    <?php
                                        $reasonColor = (string) ($reasonOption['color'] ?? '#1e293b');
                                        $reasonLabel = (string) $reasonOption['reason_code'] . ' · ' . normalize_sage_code((string) $reasonOption['sage_code']) . ' — ' . (string) $reasonOption['label'];
                                    ?>
                                    <button type="button" class="shopfloor-reason-option" data-role="option" data-value="<?= (int) $reasonOption['id'] ?>" data-color="<?= h($reasonColor) ?>" data-search="<?= h(strtolower($reasonLabel)) ?>">
                                        <span class="shopfloor-dot" style="background: <?= h($reasonColor) ?>"></span>
                                        <span><?= h($reasonLabel) ?></span>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <label class="form-label">Duração</label>
                    <select name="duration_type" class="form-select" required><option value="Completa">Completa</option><option value="Parcial">Parcial</option><option value="Horas">Horas</option></select>
                </div>
                <div class="absence-full-days-field request-second-row">
                    <label class="form-label">Data início</label>
                    <input type="date" name="start_date" class="form-control" required>
                </div>
                <div class="absence-full-days-field request-second-row">
                    <label class="form-label">Data fim</label>
                    <input type="date" name="end_date" class="form-control" required>
                </div>
                <div class="absence-time-range-field d-none request-second-row">
                    <label class="form-label">Data</label>
                    <input type="date" name="single_date" class="form-control">
                </div>
                <div class="absence-time-range-field d-none request-second-row">
                    <label class="form-label">Hora início</label>
                    <input type="time" name="start_time" class="form-control">
                </div>
                <div class="absence-time-range-field d-none request-second-row">
                    <label class="form-label">Hora fim</label>
                    <input type="time" name="end_time" class="form-control">
                </div>
                <div>
                    <label class="form-label">Duração (hh:mm)</label>
                    <input type="text" name="duration_hours" class="form-control" placeholder="02:00">
                </div>
                <div class="full">
                    <label class="form-label">Justificação</label>
                    <textarea name="details" class="form-control" rows="3" placeholder="Opcional"></textarea>
                </div>
                <div class="full">
                    <button type="submit" class="btn btn-primary w-100 fw-semibold">Submeter pedido</button>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-sm shopfloor-table mb-0">
                <thead><tr><th>Motivo</th><th>Data</th><th>Estado</th><th class="text-end">Justificação</th></tr></thead>
                <tbody>
                <?php if ($absenceRequests): foreach ($absenceRequests as $absence): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <span class="shopfloor-dot" style="background: <?= h((string) ($absence['reason_color'] ?? '#2563eb')) ?>"></span>
                                <span><?= h((string) $absence['reason']) ?></span><br><span class="small text-secondary">Duração: <?= h((string) ($absence['duration_type'] ?? 'Completa')) ?><?= !empty($absence['duration_hours']) ? ' · ' . h((string) $absence['duration_hours']) : '' ?></span>
                            </div>
                            <div class="small text-secondary">Código: <?= (int) $absence['id'] ?></div>
                        </td>
                        <td>
                            <?php if (($absence['request_type'] ?? 'Dias inteiros') === 'Intervalo de tempo'): ?>
                                <?= h((string) $absence['start_date']) ?> · <?= h((string) ($absence['start_time'] ?? '')) ?> → <?= h((string) ($absence['end_time'] ?? '')) ?>
                            <?php else: ?>
                                <?= h((string) $absence['start_date']) ?><?= $absence['end_date'] !== $absence['start_date'] ? ' → ' . h((string) $absence['end_date']) : '' ?>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge shopfloor-status-pill"><?= h((string) $absence['status']) ?></span></td>
                        <td class="text-end">
                            <div class="d-inline-flex align-items-center gap-2">
                                <?php if (!empty($absence['latest_attachment_path'])): ?>
                                    <?php $latestAttachmentIsPdf = strtolower((string) pathinfo((string) $absence['latest_attachment_path'], PATHINFO_EXTENSION)) === 'pdf'; ?>
                                    <a
                                        href="<?= h((string) $absence['latest_attachment_path']) ?>"
                                        class="btn btn-outline-secondary btn-sm"
                                        <?= $latestAttachmentIsPdf ? 'target="_blank" rel="noopener"' : 'data-lightbox-image="' . h((string) $absence['latest_attachment_path']) . '"' ?>
                                    >Ver ficheiro</a>
                                <?php endif; ?>
                                <button class="btn btn-primary btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#justification-form-<?= (int) $absence['id'] ?>">Anexar</button>
                            </div>
                        </td>
                    </tr>
                    <tr class="collapse" id="justification-form-<?= (int) $absence['id'] ?>">
                        <td colspan="4" class="bg-transparent">
                            <form method="post" class="row g-2 align-items-end" enctype="multipart/form-data">
                                <input type="hidden" name="action" value="submit_justification">
                                <input type="hidden" name="absence_request_id" value="<?= (int) $absence['id'] ?>">
                                <div class="col-md-10">
                                    <label class="form-label mb-1">Ficheiro (PDF ou fotografia)</label>
                                    <input type="file" name="attachment" class="form-control form-control-sm" accept="application/pdf,image/jpeg,image/png,image/webp" required>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-outline-primary btn-sm w-100">Submeter</button>
                                </div>
                            </form>

                            <?php $absenceJustifications = $absenceJustificationsByRequestId[(int) $absence['id']] ?? []; ?>
                            <?php if ($absenceJustifications): ?>
                                <div class="mt-3 border-top pt-2">
                                    <div class="small text-secondary mb-2">Justificações ligadas a esta ausência</div>
                                    <div class="d-flex flex-column gap-2">
                                        <?php foreach ($absenceJustifications as $absenceJustification): ?>
                                            <div class="d-flex flex-wrap align-items-center gap-2 small">
                                                <span class="text-secondary"><?= h((string) $absenceJustification['event_date']) ?></span>
                                                <span>— <?= h((string) $absenceJustification['description']) ?></span>
                                                <?php if (!empty($absenceJustification['attachment_path'])): ?>
                                                    <?php $attachmentIsPdf = strtolower((string) pathinfo((string) $absenceJustification['attachment_path'], PATHINFO_EXTENSION)) === 'pdf'; ?>
                                                    <a
                                                        href="<?= h((string) $absenceJustification['attachment_path']) ?>"
                                                        class="btn btn-outline-secondary btn-sm py-0 px-2"
                                                        <?= $attachmentIsPdf ? 'target="_blank" rel="noopener"' : 'data-lightbox-image="' . h((string) $absenceJustification['attachment_path']) . '"' ?>
                                                    >Ver ficheiro</a>
                                                <?php else: ?>
                                                    <span class="text-secondary">Sem anexo</span>
                                                <?php endif; ?>
                                                <span class="badge shopfloor-status-pill"><?= h((string) $absenceJustification['status']) ?></span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="4" class="text-secondary">Sem comunicações de ausência.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>


    <?php if ($isAdmin || $isRh): ?>
        <div class="shopfloor-panel mb-4">
            <div class="shopfloor-panel-header flex-wrap gap-2">
                <h2 class="h5 mb-0">Acompanhamento RH (pendentes e aprovados)</h2>
                <div class="btn-group btn-group-sm" role="group" aria-label="Filtro RH">
                    <a class="btn <?= $rhFilter === 'todos' ? 'btn-primary' : 'btn-outline-primary' ?>" href="shopfloor.php?rh_filter=todos">Todos</a>
                    <a class="btn <?= $rhFilter === 'pendentes' ? 'btn-primary' : 'btn-outline-primary' ?>" href="shopfloor.php?rh_filter=pendentes">Pendentes</a>
                    <a class="btn <?= $rhFilter === 'aprovados' ? 'btn-primary' : 'btn-outline-primary' ?>" href="shopfloor.php?rh_filter=aprovados">Aprovados</a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-sm shopfloor-table mb-0">
                    <thead><tr><th>Colaborador</th><th>Motivo</th><th>Data</th><th>Estado</th><th class="text-end">Validação RH</th></tr></thead>
                    <tbody>
                    <?php if ($rhAbsenceRows): foreach ($rhAbsenceRows as $rhAbsence): ?>
                        <tr>
                            <td><?= h((string) $rhAbsence['user_name']) ?></td>
                            <td><?= h((string) $rhAbsence['reason']) ?></td>
                            <td>
                                <?php if (($rhAbsence['request_type'] ?? 'Dias inteiros') === 'Intervalo de tempo'): ?>
                                    <?= h((string) $rhAbsence['start_date']) ?> · <?= h((string) ($rhAbsence['start_time'] ?? '')) ?> → <?= h((string) ($rhAbsence['end_time'] ?? '')) ?>
                                <?php else: ?>
                                    <?= h((string) $rhAbsence['start_date']) ?><?= $rhAbsence['end_date'] !== $rhAbsence['start_date'] ? ' → ' . h((string) $rhAbsence['end_date']) : '' ?>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge shopfloor-status-pill"><?= h((string) $rhAbsence['status']) ?></span></td>
                            <td class="text-end">
                                <?php if (($rhAbsence['status'] ?? '') === 'Pendente Nível 2' || ($rhAbsence['status'] ?? '') === 'Pendente'): ?>
                                    <div class="d-inline-flex gap-2">
                                        <form method="post">
                                            <input type="hidden" name="action" value="review_absence">
                                            <input type="hidden" name="absence_id" value="<?= (int) $rhAbsence['id'] ?>">
                                            <input type="hidden" name="decision" value="approve">
                                            <button class="btn btn-sm btn-outline-success">Aprovar</button>
                                        </form>
                                        <form method="post">
                                            <input type="hidden" name="action" value="review_absence">
                                            <input type="hidden" name="absence_id" value="<?= (int) $rhAbsence['id'] ?>">
                                            <input type="hidden" name="decision" value="reject">
                                            <button class="btn btn-sm btn-outline-danger">Rejeitar</button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <span class="text-secondary small">Sem ação</span>
                                <?php endif; ?>
                                <button class="btn btn-sm btn-outline-secondary ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#edit-absence-<?= (int) $rhAbsence['id'] ?>">Editar</button>
                            </td>
                        </tr>
                        <tr class="collapse" id="edit-absence-<?= (int) $rhAbsence['id'] ?>">
                            <td colspan="5">
                                <form method="post" class="row g-2 align-items-end">
                                    <input type="hidden" name="action" value="edit_absence">
                                    <input type="hidden" name="absence_id" value="<?= (int) $rhAbsence['id'] ?>">
                                    <div class="col-md-2"><label class="form-label">Tipo</label><select class="form-select" name="request_type"><option value="Dias inteiros" <?= ($rhAbsence['request_type'] ?? '') === 'Dias inteiros' ? 'selected' : '' ?>>Dias inteiros</option><option value="Intervalo de tempo" <?= ($rhAbsence['request_type'] ?? '') === 'Intervalo de tempo' ? 'selected' : '' ?>>Intervalo</option></select></div>
                                    <div class="col-md-2"><label class="form-label">Duração</label><select class="form-select" name="duration_type"><option value="Completa" <?= ($rhAbsence['duration_type'] ?? '') === 'Completa' ? 'selected' : '' ?>>Completa</option><option value="Parcial" <?= ($rhAbsence['duration_type'] ?? '') === 'Parcial' ? 'selected' : '' ?>>Parcial</option><option value="Horas" <?= ($rhAbsence['duration_type'] ?? '') === 'Horas' ? 'selected' : '' ?>>Horas</option></select></div>
                                    <div class="col-md-2"><label class="form-label">Início</label><input class="form-control" type="date" name="start_date" value="<?= h((string) $rhAbsence['start_date']) ?>" required></div>
                                    <div class="col-md-2"><label class="form-label">Fim</label><input class="form-control" type="date" name="end_date" value="<?= h((string) $rhAbsence['end_date']) ?>" required></div>
                                    <div class="col-md-1"><label class="form-label">H. ini</label><input class="form-control" type="time" name="start_time" value="<?= h((string) ($rhAbsence['start_time'] ?? '')) ?>"></div>
                                    <div class="col-md-1"><label class="form-label">H. fim</label><input class="form-control" type="time" name="end_time" value="<?= h((string) ($rhAbsence['end_time'] ?? '')) ?>"></div>
                                    <div class="col-md-2"><label class="form-label">Duração</label><input class="form-control" name="duration_hours" placeholder="hh:mm" value="<?= h((string) ($rhAbsence['duration_hours'] ?? '')) ?>"></div><div class="col-md-2"><label class="form-label">Detalhes</label><input class="form-control" name="details" value="<?= h((string) ($rhAbsence['details'] ?? '')) ?>"></div>
                                    <div class="col-md-12 d-grid"><button class="btn btn-dark btn-sm">Guardar edição</button></div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="5" class="text-secondary">Sem pedidos para o filtro selecionado.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <div class="shopfloor-panel mb-4">
        <div class="shopfloor-panel-header">
            <h2 class="h4 mb-0">Pedidos de férias</h2>
            <div class="d-flex align-items-center gap-2 flex-wrap justify-content-end">
                <form method="get" class="d-flex align-items-center gap-2">
                    <?php if ($rhFilter !== 'todos'): ?><input type="hidden" name="rh_filter" value="<?= h($rhFilter) ?>"><?php endif; ?>
                    <input type="number" name="vacation_year" class="form-control form-control-sm" style="width:100px" min="2000" max="2100" value="<?= (int) $vacationYear ?>">
                    <button class="btn btn-outline-secondary btn-sm">Ano</button>
                </form>
                <?php if ($hasOpenClockEntryToday): ?>
                    <button class="btn btn-secondary btn-sm fw-semibold" type="button" disabled aria-disabled="true">Novo pedido</button>
                <?php else: ?>
                    <button class="btn btn-primary btn-sm fw-semibold" type="button" data-bs-toggle="collapse" data-bs-target="#vacationFormPanel" aria-expanded="false" aria-controls="vacationFormPanel">Novo pedido</button>
                <?php endif; ?>
            </div>
        </div>
        <?php if ($hasOpenClockEntryToday): ?>
            <p class="small text-secondary mb-3">Os pedidos de férias só podem ser criados quando não existe ponto em aberto no dia atual.</p>
        <?php endif; ?>
        <div class="row g-2 mb-3">
            <div class="col-lg-3 col-md-6">
                <div class="border rounded p-2 bg-white h-100">
                    <div class="small text-secondary">Ano analisado</div>
                    <div class="fw-semibold">
                        <?= (int) $vacationYear ?>
                        <?php if ($scheduleGap !== ''): ?><span class="text-secondary"> · <?= h($scheduleGap) ?></span><?php endif; ?>
                    </div>
                    <div class="small text-secondary">Supostos: <?= (int) $expectedWorkDays ?> · Trabalhados: <?= (int) $workedDays ?></div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6"><div class="border rounded p-2 bg-white h-100"><div class="small text-secondary">Atribuídos</div><div class="fw-semibold"><?= h(number_format($assignedVacationDays, 1, ',', '.')) ?> dias</div></div></div>
            <div class="col-lg-2 col-md-6"><div class="border rounded p-2 bg-white h-100"><div class="small text-secondary">Pedidos</div><div class="fw-semibold"><?= h(number_format($requestedVacationDays, 1, ',', '.')) ?> dias</div></div></div>
            <div class="col-lg-2 col-md-6"><div class="border rounded p-2 bg-white h-100"><div class="small text-secondary">Validados</div><div class="fw-semibold"><?= h(number_format($validatedVacationDays, 1, ',', '.')) ?> dias</div></div></div>
            <div class="col-lg-3 col-md-12"><div class="border rounded p-2 bg-white h-100"><div class="small text-secondary">Gozados (registo RH)</div><div class="fw-semibold"><?= h(number_format($takenVacationDays, 1, ',', '.')) ?> dias</div></div></div>
        </div>

        <div class="collapse mb-3" id="vacationFormPanel">
            <form method="post" class="shopfloor-form-grid">
                <input type="hidden" name="action" value="submit_vacation">
                <div>
                    <label class="form-label">Início</label>
                    <input type="date" name="start_date" class="form-control" required>
                </div>
                <div>
                    <label class="form-label">Fim</label>
                    <input type="date" name="end_date" class="form-control" required>
                </div>
                <div class="full">
                    <label class="form-label">Notas</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="Observações opcionais"></textarea>
                </div>
                <div class="full">
                    <button type="submit" class="btn btn-primary w-100 fw-semibold">Submeter pedido</button>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-sm shopfloor-table mb-0">
                <thead><tr><th>Início</th><th>Fim</th><th>Dias</th><th>Estado</th></tr></thead>
                <tbody>
                <?php if ($vacationRequests): foreach ($vacationRequests as $vacation): ?>
                    <tr>
                        <td><?= h((string) $vacation['start_date']) ?></td>
                        <td><?= h((string) $vacation['end_date']) ?></td>
                        <td><?= h(number_format((float) ($vacation['total_days'] ?? 0), 1, ',', '.')) ?></td>
                        <td><span class="badge shopfloor-status-pill"><?= h((string) $vacation['status']) ?></span></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="4" class="text-secondary">Sem pedidos de férias.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-12">
            <div class="shopfloor-panel">
                <h2 class="h5 mb-3">Comunicados da chefia / RH</h2>
                <ul class="list-group list-group-flush mb-3">
                    <?php if ($announcements): foreach ($announcements as $announcement): ?>
                        <li class="list-group-item shopfloor-list-item">
                            <div class="fw-semibold"><?= h((string) $announcement['title']) ?></div>
                            <div class="small text-secondary mb-1">Por <?= h((string) $announcement['created_by_name']) ?> em <?= h((string) $announcement['created_at']) ?></div>
                            <div><?= nl2br(h((string) $announcement['body'])) ?></div>
                        </li>
                    <?php endforeach; else: ?>
                        <li class="list-group-item shopfloor-list-item text-secondary">Sem comunicados ativos.</li>
                    <?php endif; ?>
                </ul>

                <?php if ($canManageAnnouncements): ?>
                    <h3 class="h6">Publicar comunicado</h3>
                    <form method="post" class="vstack gap-2 mb-4" data-user-picker-modal-target="#shopfloorAnnouncementUsersModal" data-user-picker-input-name="target_user_ids[]" data-user-picker-all-label="Todos os utilizadores Shopfloor" data-user-picker-selected-suffix="utilizadores selecionados">
                        <input type="hidden" name="action" value="publish_announcement">
                        <input type="text" name="title" class="form-control" placeholder="Título" required>
                        <textarea name="body" class="form-control" rows="3" placeholder="Mensagem" required></textarea>
                        <div>
                            <label class="form-label mb-1">Direcionado a utilizadores (opcional)</label>
                            <div class="user-picker-meta">
                                <div class="form-text mt-0 js-user-picker-summary user-picker-summary">Todos os utilizadores Shopfloor</div>
                                <div class="user-picker-chips js-user-picker-chips"></div>
                            </div>
                            <button
                                type="button"
                                class="btn btn-outline-secondary w-100 d-flex justify-content-between align-items-center"
                                data-bs-toggle="modal"
                                data-bs-target="#shopfloorAnnouncementUsersModal"
                            >
                                <span class="text-start">Selecionar utilizadores</span>
                                <span class="badge text-bg-dark js-user-picker-count">0</span>
                            </button>
                            <div class="d-none js-user-picker-hidden-inputs"></div>
                            <div class="form-text">Se não selecionar ninguém, o comunicado fica visível para todos os utilizadores do Shopfloor.</div>
                        </div>
                        <button type="submit" class="btn btn-outline-primary">Publicar</button>
                    </form>

                    <div class="modal fade" id="shopfloorAnnouncementUsersModal" tabindex="-1" aria-labelledby="shopfloorAnnouncementUsersModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <div>
                                        <h3 class="modal-title fs-5" id="shopfloorAnnouncementUsersModalLabel">Escolher utilizadores</h3>
                                        <p class="text-muted small mb-0">Pesquise e selecione vários utilizadores para direcionar o comunicado.</p>
                                    </div>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row g-2 align-items-center mb-3">
                                        <div class="col-md-8">
                                            <input type="search" class="form-control js-user-picker-search" placeholder="Pesquisar utilizador">
                                        </div>
                                        <div class="col-md-4">
                                            <div class="d-flex flex-wrap gap-2 justify-content-md-end">
                                                <button type="button" class="btn btn-outline-secondary btn-sm js-user-picker-select-all">Selecionar todos</button>
                                                <button type="button" class="btn btn-outline-secondary btn-sm js-user-picker-clear-all">Limpar</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="user-picker-modal-list border rounded p-2">
                                        <?php foreach ($announcementTargetUsers as $targetUser): ?>
                                            <?php $targetLabel = (string) ($targetUser['name'] . ' ' . $targetUser['username']); ?>
                                            <?php $targetLabelSearch = function_exists('mb_strtolower') ? mb_strtolower($targetLabel) : strtolower($targetLabel); ?>
                                            <label class="user-picker-option border px-2 py-2 rounded" data-user-option data-user-id="<?= (int) $targetUser['id'] ?>" data-user-label="<?= h($targetLabelSearch) ?>">
                                                <input class="form-check-input user-picker-checkbox js-user-picker-checkbox" type="checkbox" value="<?= (int) $targetUser['id'] ?>">
                                                <span class="user-picker-meta-label flex-grow-1">
                                                    <span class="d-block fw-semibold js-user-picker-name"><?= h((string) $targetUser['name']) ?></span>
                                                    <span class="d-block text-muted small"><?= h((string) $targetUser['username']) ?></span>
                                                </span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <button type="button" class="btn btn-dark js-user-picker-apply">Aplicar</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <h3 class="h6">Gerir comunicados</h3>
                    <ul class="list-group list-group-flush">
                        <?php if ($managedAnnouncements): foreach ($managedAnnouncements as $announcement): ?>
                            <li class="list-group-item shopfloor-list-item">
                                <div class="d-flex justify-content-between align-items-start gap-2 mb-1">
                                    <div class="fw-semibold"><?= h((string) $announcement['title']) ?></div>
                                    <span class="badge <?= ((int) $announcement['is_active'] === 1) ? 'text-bg-success' : 'text-bg-secondary' ?>"><?= ((int) $announcement['is_active'] === 1) ? 'Ativo' : 'Inativo' ?></span>
                                </div>
                                <div class="small text-secondary mb-1">Por <?= h((string) $announcement['created_by_name']) ?> em <?= h((string) $announcement['created_at']) ?></div>
                                <div class="small text-secondary mb-2">
                                    <?= (string) $announcement['audience'] === 'targeted' ? ('Direcionado a ' . (int) $announcement['target_count'] . ' utilizador(es).') : 'Visível para todos os utilizadores Shopfloor.' ?>
                                </div>
                                <div class="d-flex gap-2">
                                    <form method="post">
                                        <input type="hidden" name="action" value="toggle_announcement">
                                        <input type="hidden" name="announcement_id" value="<?= (int) $announcement['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-secondary"><?= ((int) $announcement['is_active'] === 1) ? 'Desativar' : 'Ativar' ?></button>
                                    </form>
                                    <form method="post" onsubmit="return confirm('Eliminar este comunicado?');">
                                        <input type="hidden" name="action" value="delete_announcement">
                                        <input type="hidden" name="announcement_id" value="<?= (int) $announcement['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Eliminar</button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; else: ?>
                            <li class="list-group-item shopfloor-list-item text-secondary">Sem comunicados para gerir.</li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
        </div>
    </section>

    <section class="mb-4" aria-labelledby="dailyHistoryHeading">
        <div class="d-flex align-items-center gap-2 mb-3">
            <i class="bi bi-clock-history text-primary" aria-hidden="true"></i>
            <h2 class="h4 mb-0" id="dailyHistoryHeading">Histórico do dia</h2>
        </div>
        <div class="row g-3">
            <div class="col-xl-6">
                <div class="shopfloor-panel h-100">
                    <h3 class="h5 mb-3">Histórico de pontos</h3>
                    <ul class="list-group list-group-flush">
                        <?php if ($todayEntries): foreach ($todayEntries as $entry): ?>
                            <li class="list-group-item shopfloor-list-item">
                                <?php $entryOccurredAt = (string) ($entry['occurred_at'] ?? ($entry['created_at'] ?? '')); ?>
                                <span class="fw-semibold"><?= $entry['entry_type'] === 'entrada' ? 'Entrada' : 'Saída' ?></span>
                                <span class="text-secondary small ms-2"><?= $entryOccurredAt !== '' ? h(date('H:i:s', strtotime($entryOccurredAt))) : '-' ?></span>
                                <?php if (!empty($entry['note'])): ?><div class="small text-secondary mt-1"><?= h((string) $entry['note']) ?></div><?php endif; ?>
                            </li>
                        <?php endforeach; else: ?>
                            <li class="list-group-item shopfloor-list-item text-secondary">Sem registos de ponto hoje.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="shopfloor-panel h-100">
                    <div class="shopfloor-panel-header flex-wrap gap-2">
                        <h3 class="h5 mb-0">Histórico de pausas e paragens</h3>
                        <?php if ($isAdmin || $isRh): ?><a href="shopfloor_break_reasons.php" class="btn btn-outline-primary btn-sm fw-semibold">Configurar tipos</a><?php endif; ?>
                    </div>
                    <?php if ($activeBreakEntry): ?>
                        <div class="small text-secondary mt-1 mb-3">Em curso: <?= h((string) ($activeBreakEntry['break_type'] ?? 'Pausa')) ?> · <?= h((string) ($activeBreakEntry['code'] ?? '')) ?> | <?= h((string) ($activeBreakEntry['label'] ?? '')) ?> (<?= h((string) ($activeBreakEntry['started_at'] ?? '')) ?>)</div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-sm shopfloor-table mb-0">
                            <thead><tr><th>Tipo</th><th>Código</th><th>Nome</th><th>Contagem</th><th>Tempo</th></tr></thead>
                            <tbody>
                                <?php if ($dailyBreakByReason): foreach ($dailyBreakByReason as $dailyBreakReason): ?>
                                    <tr><td><?= h((string) ($dailyBreakReason['break_type'] ?? '')) ?></td><td><?= h((string) ($dailyBreakReason['code'] ?? '')) ?></td><td><?= h((string) ($dailyBreakReason['label'] ?? '')) ?></td><td><?= (int) ($dailyBreakReason['total_count'] ?? 0) ?></td><td><?= h(format_minutes((int) ($dailyBreakReason['total_seconds'] ?? 0))) ?></td></tr>
                                <?php endforeach; else: ?>
                                    <tr><td colspan="5" class="text-secondary">Sem pausas/paragens registadas hoje.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>

</section>

<div class="modal fade" id="shopfloorClockEntryRequiredModal" tabindex="-1" aria-labelledby="shopfloorClockEntryRequiredModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title fs-5" id="shopfloorClockEntryRequiredModalLabel">Ponto de entrada necessário</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">Não pode iniciar ou retomar produção sem registar primeiro o ponto de entrada.</div>
                <p>Pretende dar entrada na empresa?</p>
                <p class="small text-secondary mb-0">Depois de registar a entrada, pode iniciar ou retomar a operação.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Agora não</button>
                <form method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="clock_entry">
                    <input type="hidden" name="entry_type" value="entrada">
                    <button type="submit" class="btn btn-primary">Sim, dar entrada</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php if ($articleArtwork): ?>
<?php
$articleArtworkPresentation = ArticleDocument::presentation((string) ($articleArtwork['file_url'] ?? ''));
$articleArtworkId = (int) $articleArtwork['id'];
$articleArtworkPageUrl = 'article_artwork.php?id=' . $articleArtworkId;
$articleArtworkPath = ArticleDocument::absolutePath(__DIR__, (string) ($articleArtwork['file_url'] ?? ''));
$articleArtworkPageCount = $articleArtworkPresentation['kind'] === 'pdf' ? ArticleDocument::pageCount($articleArtworkPath) : 1;
?>
<div class="modal fade shopfloor-artwork-modal" id="articleArtworkModal" tabindex="-1" aria-labelledby="articleArtworkModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen-lg-down modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header"><div><h2 class="modal-title fs-5" id="articleArtworkModalLabel">Maquete do artigo</h2><p class="small text-secondary mb-0"><?= h((string) ($selectedOf['product_code'] ?? '')) ?> · <?= h((string) ($articleArtwork['title'] ?? 'Maquete de produção')) ?></p></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button></div>
            <div class="modal-body text-center bg-light p-0"><?php if ($articleArtworkPresentation['kind'] === 'pdf'): ?><div class="shopfloor-artwork-pdf-preview" data-artwork-viewer data-page-url="<?=h($articleArtworkPageUrl)?>" data-page-count="<?=$articleArtworkPageCount?>"><div class="shopfloor-artwork-toolbar" role="toolbar" aria-label="Controlos da maquete"><button type="button" class="btn btn-light" data-artwork-page-previous aria-label="Página anterior"><i class="bi bi-chevron-left"></i></button><output data-artwork-page-current aria-live="polite">1 / <?=$articleArtworkPageCount?></output><button type="button" class="btn btn-light" data-artwork-page-next aria-label="Página seguinte"><i class="bi bi-chevron-right"></i></button><span class="shopfloor-artwork-toolbar-divider"></span><button type="button" class="btn btn-light" data-artwork-zoom-out aria-label="Reduzir"><i class="bi bi-zoom-out"></i></button><output data-artwork-zoom-value aria-live="polite">100%</output><button type="button" class="btn btn-light" data-artwork-zoom-in aria-label="Ampliar"><i class="bi bi-zoom-in"></i></button><button type="button" class="btn btn-light" data-artwork-zoom-reset>Repor</button></div><div class="shopfloor-artwork-stage" data-artwork-stage><div data-artwork-content><img src="<?=h($articleArtworkPageUrl.'&page=1')?>" class="shopfloor-artwork-page" data-artwork-image alt="Página 1 de <?=$articleArtworkPageCount?> da maquete do artigo <?= h((string) ($selectedOf['product_code'] ?? '')) ?>"></div></div><p data-artwork-status aria-live="polite">A carregar página 1…</p></div><?php else: ?><img src="<?= h($articleArtworkPageUrl.'&original=1') ?>" class="shopfloor-artwork-preview" alt="Maquete do artigo <?= h((string) ($selectedOf['product_code'] ?? '')) ?>"><?php endif; ?></div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary btn-lg" data-bs-dismiss="modal">Fechar</button><a href="<?= h($articleArtworkPageUrl.'&original=1') ?>" target="_blank" rel="noopener" class="btn btn-primary btn-lg"><i class="bi bi-download me-1"></i>Abrir PDF original</a></div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="modal fade" id="shopfloorCalculatorModal" tabindex="-1" aria-labelledby="shopfloorCalculatorLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered shopfloor-calculator-dialog">
        <div class="modal-content shopfloor-calculator">
            <div class="modal-header"><h2 class="modal-title fs-5" id="shopfloorCalculatorLabel"><i class="bi bi-calculator me-2"></i>Calculadora</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button></div>
            <div class="modal-body">
                <div class="shopfloor-calculator-screen" aria-live="polite"><div data-calculator-expression>&nbsp;</div><output data-calculator-display>0</output></div>
                <div class="shopfloor-calculator-keys" aria-label="Teclado da calculadora">
                    <?php foreach ([['C','clear','utility'],['⌫','backspace','utility'],['÷','/','operator'],['×','*','operator'],['7','7',''],['8','8',''],['9','9',''],['−','-','operator'],['4','4',''],['5','5',''],['6','6',''],['+','+','operator'],['1','1',''],['2','2',''],['3','3',''],['=','=','equals'],['0','0','zero'],[',','.',''],['±','sign','utility']] as $calculatorKey): ?><button type="button" class="btn <?= $calculatorKey[2] === 'equals' ? 'btn-primary' : ($calculatorKey[2] === 'operator' ? 'btn-warning' : 'btn-light') ?> <?= $calculatorKey[2] === 'zero' ? 'is-zero' : '' ?>" data-calculator-key="<?= h($calculatorKey[1]) ?>"><?= h($calculatorKey[0]) ?></button><?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="justificationLightbox" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content bg-dark border-0">
            <div class="modal-header border-0">
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body text-center pt-0">
                <img src="" alt="Anexo da justificação" id="justificationLightboxImage" class="img-fluid rounded">
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="justificationLightbox" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content bg-dark border-0">
            <div class="modal-header border-0">
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body text-center pt-0">
                <img src="" alt="Anexo da justificação" id="justificationLightboxImage" class="img-fluid rounded">
            </div>
        </div>
    </div>
</div>

<script>
(() => {
    const modalElement = document.getElementById('shopfloorClockEntryRequiredModal');
    const hasOpenClockEntry = <?= $hasOpenClockEntryToday ? 'true' : 'false' ?>;
    const showRequiredModal = <?= $showClockEntryRequiredModal ? 'true' : 'false' ?>;
    const showModal = () => {
        if (!modalElement || typeof bootstrap === 'undefined') return false;
        bootstrap.Modal.getOrCreateInstance(modalElement).show();
        return true;
    };

    document.addEventListener('submit', (event) => {
        const action = event.target.querySelector('input[name="action"]');
        if (!hasOpenClockEntry && action && ['start_of_operation', 'resume_operation'].includes(action.value) && showModal()) {
            event.preventDefault();
        }
    });
    window.addEventListener('load', () => {
        if (showRequiredModal) showModal();
    }, { once: true });
})();

(() => {
    const indicators = document.querySelectorAll('[data-daily-indicator]');
    if (!indicators.length) return;
    const refresh = async () => {
        try {
            const response = await fetch('shopfloor_daily_indicators.php', { headers: { Accept: 'application/json' }, cache: 'no-store' });
            if (!response.ok) return;
            const payload = await response.json();
            indicators.forEach((indicator) => {
                const value = payload[indicator.dataset.dailyIndicator];
                if (value !== undefined) indicator.textContent = String(value);
            });
        } catch (error) {
            // Keep the last server-rendered values when the connection is unavailable.
        }
    };
    window.setInterval(refresh, 1000);
    refresh();
})();

(() => {
    window.addEventListener('load', () => {
        const notification = document.querySelector('[data-shopfloor-notification]');
        if (notification && typeof bootstrap !== 'undefined') {
            bootstrap.Toast.getOrCreateInstance(notification, { autohide: true, delay: 7000 }).show();
        }
    }, { once: true });
})();

(() => {
    const form = document.querySelector('[data-of-picker-form]');
    const search = form?.querySelector('[data-of-search]');
    const idInput = form?.querySelector('[data-of-id]');
    const options = Array.from(document.querySelectorAll('#shopfloorOfOptions option'));
    if (!form || !search || !idInput) return;
    const selectOrder = () => {
        const match = options.find((option) => option.value === search.value);
        idInput.value = match?.dataset.id || '';
        return Boolean(match);
    };
    search.addEventListener('pointerdown', () => window.setTimeout(() => search.focus(), 0));
    search.addEventListener('focus', () => search.select());
    search.addEventListener('input', selectOrder);
    search.addEventListener('change', () => { if (selectOrder()) form.requestSubmit(); });
    form.addEventListener('submit', (event) => { if (!selectOrder()) { event.preventDefault(); search.focus(); search.setCustomValidity('Selecione uma ordem de fabrico da lista.'); search.reportValidity(); } else { search.setCustomValidity(''); } });
})();

(() => {
    const modal = document.getElementById('shopfloorCalculatorModal');
    if (!modal) return;
    const display = modal.querySelector('[data-calculator-display]');
    const expression = modal.querySelector('[data-calculator-expression]');
    let current = '0'; let stored = null; let operator = null; let replace = false;
    const format = (value) => String(value).replace('.', ',');
    const render = () => { display.textContent = format(current); expression.textContent = stored === null ? '\u00a0' : `${format(stored)} ${operator === '*' ? '×' : operator === '/' ? '÷' : operator}`; };
    const calculate = () => {
        if (stored === null || !operator) return;
        const left = Number(stored); const right = Number(current); let result;
        if (operator === '+') result = left + right;
        if (operator === '-') result = left - right;
        if (operator === '*') result = left * right;
        if (operator === '/') result = right === 0 ? NaN : left / right;
        current = Number.isFinite(result) ? String(Number(result.toPrecision(12))) : 'Erro'; stored = null; operator = null; replace = true;
    };
    const press = (key) => {
        if (/^\d$/.test(key)) { current = replace || current === '0' || current === 'Erro' ? key : current + key; replace = false; }
        else if (key === '.') { if (replace || current === 'Erro') { current = '0.'; replace = false; } else if (!current.includes('.')) current += '.'; }
        else if (['+','-','*','/'].includes(key)) { if (stored !== null && !replace) calculate(); stored = current; operator = key; replace = true; }
        else if (key === '=') calculate();
        else if (key === 'clear') { current = '0'; stored = null; operator = null; replace = false; }
        else if (key === 'backspace') { current = replace || current === 'Erro' || current.length === 1 ? '0' : current.slice(0, -1); replace = false; }
        else if (key === 'sign' && current !== '0' && current !== 'Erro') current = current.startsWith('-') ? current.slice(1) : '-' + current;
        render();
    };
    modal.querySelectorAll('[data-calculator-key]').forEach((button) => button.addEventListener('click', () => press(button.dataset.calculatorKey)));
    modal.addEventListener('shown.bs.modal', () => modal.querySelector('[data-calculator-key="7"]')?.focus());
    render();
})();

document.querySelectorAll('[data-auto-show-checklist]').forEach((modalElement) => {
    if (typeof bootstrap !== 'undefined') {
        bootstrap.Modal.getOrCreateInstance(modalElement, { backdrop: 'static', keyboard: false }).show();
    }
});

(() => {
    const formatDuration = (totalSeconds) => {
        const seconds = Math.max(0, Math.floor(totalSeconds));
        const hours = String(Math.floor(seconds / 3600)).padStart(2, '0');
        const minutes = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
        return `${hours}:${minutes}:${String(seconds % 60).padStart(2, '0')}`;
    };
    document.querySelectorAll('[data-production-timer]').forEach((timer) => {
        let elapsed = Number(timer.dataset.elapsedSeconds || 0);
        const running = timer.dataset.running === '1';
        timer.textContent = formatDuration(elapsed);
        if (running) {
            window.setInterval(() => { elapsed += 1; timer.textContent = formatDuration(elapsed); }, 1000);
        }
    });

    document.querySelectorAll('[data-productivity]').forEach((indicator) => {
        const card = indicator.closest('.shopfloor-operation-card');
        const quantityInput = card ? card.querySelector('[data-productivity-quantity]') : null;
        const rejectedInput = card ? card.querySelector('[data-productivity-rejected]') : null;
        const value = indicator.querySelector('[data-productivity-value]');
        const detail = indicator.querySelector('[data-productivity-detail]');
        const bar = indicator.querySelector('[data-productivity-bar]');
        const plannedQuantity = Number(indicator.dataset.plannedQuantity || 0);
        const plannedMinutes = Number(indicator.dataset.plannedMinutes || 0);
        const initialActualMinutes = Number(indicator.dataset.actualMinutes || 0);
        const running = indicator.dataset.running === '1';
        const loadedAt = Date.now();
        const realizedQuantity = Number(indicator.dataset.realizedQuantity || 0);
        const rejectedQuantity = Number(indicator.dataset.rejectedQuantity || 0);

        const refreshProductivity = () => {
            const quantity = realizedQuantity + Number(quantityInput?.value || 0);
            const rejected = rejectedQuantity + Number(rejectedInput?.value || 0);
            const actualMinutes = initialActualMinutes + (running ? (Date.now() - loadedAt) / 60000 : 0);
            if (plannedQuantity <= 0 || plannedMinutes <= 0 || actualMinutes <= 0) {
                value.textContent = '—';
                detail.textContent = 'Sem dados suficientes para calcular.';
                bar.style.width = '0%';
                return;
            }
            const percentage = Math.min(200, (quantity * plannedMinutes) / (plannedQuantity * actualMinutes) * 100);
            value.textContent = `${percentage.toLocaleString('pt-PT', { maximumFractionDigits: 0 })}%`;
            detail.textContent = `${quantity.toLocaleString('pt-PT')} OK / ${rejected.toLocaleString('pt-PT')} NOK / ${plannedQuantity.toLocaleString('pt-PT', { maximumFractionDigits: 2 })} OF`;
            bar.style.width = `${Math.min(100, Math.max(0, percentage))}%`;
            bar.classList.toggle('bg-success', percentage >= 100);
            bar.classList.toggle('bg-warning', percentage >= 90 && percentage < 100);
            bar.classList.toggle('bg-productivity-orange', percentage >= 80 && percentage < 90);
            bar.classList.toggle('bg-danger', percentage < 80);
            indicator.querySelector('.progress').setAttribute('aria-valuenow', String(Math.min(200, Math.max(0, Math.round(percentage)))));
        };

        quantityInput?.addEventListener('input', refreshProductivity);
        rejectedInput?.addEventListener('input', refreshProductivity);
        refreshProductivity();
        if (running) window.setInterval(refreshProductivity, 1000);
    });
})();

document.querySelectorAll('[data-material-consumption-form]').forEach((form) => {
    const refreshUnit = (row) => {
        const material = row.querySelector('[data-consumption-material]');
        const unit = material?.selectedOptions[0]?.dataset.unit || 'un.';
        row.querySelectorAll('[data-consumption-unit]').forEach((element) => { element.textContent = unit; });
    };
    form.querySelectorAll('[data-consumption-row]').forEach(refreshUnit);
    form.addEventListener('change', (event) => {
        if (event.target.matches('[data-consumption-material]')) refreshUnit(event.target.closest('[data-consumption-row]'));
    });
    form.addEventListener('click', (event) => {
        const addButton = event.target.closest('[data-add-consumption-row]');
        if (addButton) {
            const template = form.querySelector('[data-consumption-row-template]');
            const row = template.content.firstElementChild.cloneNode(true);
            form.querySelector('[data-consumption-rows]').appendChild(row);
            refreshUnit(row);
            row.querySelector('select').focus();
            return;
        }
        const removeButton = event.target.closest('[data-remove-consumption-row]');
        if (removeButton && !removeButton.disabled) removeButton.closest('[data-consumption-row]').remove();
    });
});

document.querySelectorAll('[id^="materialConsumptionModal-"]').forEach((modal) => {
    const unitForm=modal.querySelector('[data-unit-consumption-form]');
    const directForm=modal.querySelector('[data-material-consumption-form]');
    const choose=(type)=>{
        const direct=type==='DIRECT'; directForm?.classList.toggle('d-none',!direct); unitForm?.classList.toggle('d-none',direct);
        if(!direct&&unitForm){unitForm.elements.unit_type.value=type;unitForm.querySelector('[data-unit-label]').textContent=type==='ROLL'?'Nº da etiqueta do rolo':'Nº da lata';unitForm.elements.label_number.focus();}
    };
    modal.querySelectorAll('[data-consumption-mode]').forEach(button=>button.addEventListener('click',()=>choose(button.dataset.consumptionMode)));
    const lookup=async()=>{if(!unitForm)return;const type=unitForm.elements.unit_type.value;const label=unitForm.elements.label_number.value.trim();const result=unitForm.querySelector('[data-unit-result]');const confirm=unitForm.querySelector('[data-confirm-unit]');if(!label)return;
        result.className='mt-3 alert alert-info';result.textContent='A pesquisar…';confirm.classList.add('d-none');
        try{const response=await fetch(`shopfloor.php?action=lookup_stock_unit&unit_type=${encodeURIComponent(type)}&label_number=${encodeURIComponent(label)}`,{headers:{Accept:'application/json'}});const data=await response.json();if(!response.ok||!data.ok)throw new Error(data.message||'Etiqueta não encontrada.');const u=data.unit;result.className='mt-3 alert alert-success';result.innerHTML='';const title=document.createElement('strong');title.textContent=`✓ ${type==='ROLL'?'Rolo':'Lata'} ${u.barcode}`;const details=document.createElement('div');details.className='mt-2';details.textContent=`${u.article_code} · ${u.description} — Disponível: ${Number(u.weight_kg).toLocaleString('pt-PT',{maximumFractionDigits:3})} kg${u.metres!==undefined?' · '+Number(u.metres).toLocaleString('pt-PT')+' m':''} · Estado: ${u.status}`;result.append(title,details);confirm.classList.remove('d-none');}catch(error){result.className='mt-3 alert alert-danger';result.textContent=`✕ ${error.message}`;}
    };
    unitForm?.querySelector('[data-lookup-unit]')?.addEventListener('click',lookup);
    unitForm?.elements.label_number?.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();lookup();}});
});

(() => {
    const modal=document.getElementById('productionLabelModal'), form=document.getElementById('stockLabelForm');
    if(!modal||!form)return;
    const result=form.querySelector('[data-label-result]'), actions=form.querySelector('[data-label-actions]'), fields=form.querySelector('[data-label-adjust]'), toggle=document.getElementById('labelAdjust');
    let request=0;
    const reset=()=>{request++;actions.hidden=true;fields.hidden=true;fields.disabled=true;toggle.checked=false;result.textContent='';};
    form.elements.label_number.addEventListener('input',reset);
    modal.querySelectorAll('[data-label-type]').forEach(button=>button.addEventListener('click',()=>{
        reset();form.elements.unit_type.value=button.dataset.labelType;
        modal.querySelectorAll('[data-label-type]').forEach(option=>{const active=option===button;option.classList.toggle('btn-primary',active);option.classList.toggle('btn-outline-primary',!active);option.setAttribute('aria-pressed',String(active));});
        form.querySelector('[data-label-prompt]').textContent=button.dataset.labelType==='ROLL'?'Nº da etiqueta do rolo':'Nº da lata';form.elements.label_number.value='';form.elements.label_number.focus();
    }));
    toggle.addEventListener('change',()=>{fields.hidden=!toggle.checked;fields.disabled=!toggle.checked;});
    const lookup=async()=>{
        reset();const token=request,type=form.elements.unit_type.value,label=form.elements.label_number.value.trim();if(!label)return;
        result.textContent='A pesquisar…';
        try{const response=await fetch(`shopfloor.php?action=lookup_stock_unit&unit_type=${encodeURIComponent(type)}&label_number=${encodeURIComponent(label)}`);const data=await response.json();if(token!==request)return;if(!response.ok||!data.ok)throw new Error(data.message||'Etiqueta não encontrada.');
            const u=data.unit;result.textContent=`${u.article_code} · ${u.description} — ${u.weight_kg} kg${type==='ROLL'?' · '+u.metres+' m':''} · ${u.status}`;
            form.elements.expected_weight.value=u.weight_kg;form.elements.expected_metres.value=u.metres||0;form.elements.weight_kg.value=u.weight_kg;form.elements.metres.value=u.metres||0;form.elements.metres.required=type==='ROLL';form.querySelector('[data-label-metres]').hidden=type!=='ROLL';
            form.querySelector('[data-label-print]').href=<?= (new CentralPrinting($pdo))->enabled() ? "true" : "false" ?> ? ('print_label.php?kind='+(type==='ROLL'?'roll':'ink')+'&id='+encodeURIComponent(u.id)) : (type==='ROLL'?'raw_material_roll_label.php?printed_label_id=':'raw_material_ink_label.php?label_id=')+encodeURIComponent(u.id)+'&raw_material_id='+encodeURIComponent(u.raw_material_id)+'&print=1';actions.hidden=false;
            toggle.disabled=['IN_USE','BLOCKED','CONSUMED'].includes(u.status);
        }catch(error){if(token===request)result.textContent=error.message;}
    };
    form.querySelector('[data-label-search]').addEventListener('click',lookup);
    form.elements.label_number.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();lookup();}});
    form.addEventListener('submit',event=>{if(actions.hidden||!toggle.checked){event.preventDefault();lookup();}});
})();

(() => {
    const typeSelect = document.getElementById('absenceRequestType');
    const form = document.getElementById('absenceRequestForm');
    if (!typeSelect || !form) {
        return;
    }

    const fullDayFields = form.querySelectorAll('.absence-full-days-field');
    const intervalFields = form.querySelectorAll('.absence-time-range-field');
    const startDateInput = form.querySelector('input[name="start_date"]');
    const endDateInput = form.querySelector('input[name="end_date"]');
    const singleDateInput = form.querySelector('input[name="single_date"]');
    const startTimeInput = form.querySelector('input[name="start_time"]');
    const endTimeInput = form.querySelector('input[name="end_time"]');
    const reasonSelect = document.getElementById('absenceReasonSelect');
    const reasonPicker = document.getElementById('absenceReasonPicker');

    const refreshFields = () => {
        const isInterval = typeSelect.value === 'Intervalo de tempo';

        fullDayFields.forEach((field) => {
            field.classList.toggle('d-none', isInterval);
        });
        intervalFields.forEach((field) => {
            field.classList.toggle('d-none', !isInterval);
        });

        if (startDateInput) {
            startDateInput.required = !isInterval;
        }
        if (endDateInput) {
            endDateInput.required = !isInterval;
        }
        if (singleDateInput) {
            singleDateInput.required = isInterval;
        }
        if (startTimeInput) {
            startTimeInput.required = isInterval;
        }
        if (endTimeInput) {
            endTimeInput.required = isInterval;
        }
    };

    typeSelect.addEventListener('change', refreshFields);
    refreshFields();

    const applyReasonColor = (selectedOption = null) => {
        if (!reasonSelect || !reasonPicker) {
            return;
        }
        const resolvedOption = selectedOption || reasonSelect.options[reasonSelect.selectedIndex];
        const selectedColor = resolvedOption?.dataset?.color || '#0f172a';
        const toggleButton = reasonPicker.querySelector('[data-role="toggle"]');
        if (toggleButton) {
            toggleButton.style.color = selectedColor;
        }
    };

    const setupReasonPicker = () => {
        if (!reasonSelect || !reasonPicker) {
            return;
        }

        const toggleButton = reasonPicker.querySelector('[data-role="toggle"]');
        const menu = reasonPicker.querySelector('[data-role="menu"]');
        const searchInput = reasonPicker.querySelector('[data-role="search"]');
        const options = Array.from(reasonPicker.querySelectorAll('[data-role="option"]'));
        if (!toggleButton || !menu || !searchInput || options.length === 0) {
            return;
        }

        const closeMenu = () => {
            menu.classList.add('d-none');
        };
        const openMenu = () => {
            menu.classList.remove('d-none');
            searchInput.focus();
        };

        toggleButton.addEventListener('click', () => {
            if (menu.classList.contains('d-none')) {
                openMenu();
            } else {
                closeMenu();
            }
        });

        options.forEach((optionButton) => {
            optionButton.addEventListener('click', () => {
                const value = optionButton.getAttribute('data-value') || '';
                const labelElement = optionButton.querySelector('span:last-child');
                const label = (labelElement?.textContent || '').trim();
                reasonSelect.value = value;
                toggleButton.textContent = label || 'Selecionar motivo';
                applyReasonColor({ dataset: { color: optionButton.getAttribute('data-color') || '#0f172a' } });
                closeMenu();
            });
        });

        searchInput.addEventListener('input', () => {
            const term = searchInput.value.trim().toLowerCase();
            options.forEach((optionButton) => {
                const haystack = optionButton.getAttribute('data-search') || '';
                optionButton.classList.toggle('d-none', term !== '' && !haystack.includes(term));
            });
        });

        document.addEventListener('click', (event) => {
            if (!(event.target instanceof Node)) {
                return;
            }
            if (!reasonPicker.contains(event.target)) {
                closeMenu();
            }
        });
    };

    reasonSelect?.addEventListener('change', () => applyReasonColor());
    setupReasonPicker();
    applyReasonColor();
})();

(() => {
    window.addEventListener('load', () => {
        const modalElement = document.getElementById('justificationLightbox');
        const imageElement = document.getElementById('justificationLightboxImage');
        if (!modalElement || !imageElement || typeof bootstrap === 'undefined') {
            return;
        }

        const lightboxModal = new bootstrap.Modal(modalElement);
        document.querySelectorAll('[data-lightbox-image]').forEach((link) => {
            link.addEventListener('click', (event) => {
                event.preventDefault();
                const imageUrl = link.getAttribute('data-lightbox-image');
                if (!imageUrl) {
                    return;
                }
                imageElement.src = imageUrl;
                lightboxModal.show();
            });
        });

        modalElement.addEventListener('hidden.bs.modal', () => {
            imageElement.src = '';
        });
    }, { once: true });
})();

(() => {
    window.addEventListener('load', () => {
        const storageKey = 'gestisser_shopfloor_work_center_id';
        const modalElement = document.getElementById('workCenterModal');
        const forms = Array.from(document.querySelectorAll('.js-work-center-form'));
        const selectedServerId = <?= (int) $selectedWorkCenterId ?>;
        const selectionInvalid = <?= isset($_GET['work_center_error']) ? 'true' : 'false' ?>;

        const storage = {
            get: () => { try { return window.localStorage.getItem(storageKey) || ''; } catch (error) { return ''; } },
            set: (value) => { try { window.localStorage.setItem(storageKey, value); } catch (error) {} },
            clear: () => { try { window.localStorage.removeItem(storageKey); } catch (error) {} }
        };

        if (selectionInvalid) {
            storage.clear();
        }

        forms.forEach((form) => {
            form.addEventListener('submit', () => {
                storage.set(form.querySelector('[name="work_center_id"]')?.value || '');
            });
        });

        if (!selectedServerId) {
            const cachedId = storage.get();
            const cachedForm = forms.find((form) => form.querySelector('[name="work_center_id"]')?.value === cachedId);
            if (cachedForm && !selectionInvalid) {
                cachedForm.submit();
                return;
            }

            if (modalElement && typeof bootstrap !== 'undefined') {
                bootstrap.Modal.getOrCreateInstance(modalElement, { backdrop: 'static', keyboard: false }).show();
            }
        } else if (storage.get() !== String(selectedServerId)) {
            storage.set(String(selectedServerId));
        }
    }, { once: true });
})();

(() => {
    window.addEventListener('load', () => {
        const modalElement = document.getElementById('shopfloorAnnouncementAcknowledgeModal');
        if (!modalElement || typeof bootstrap === 'undefined') {
            return;
        }

        const announcementModal = bootstrap.Modal.getOrCreateInstance(modalElement, {
            backdrop: 'static',
            keyboard: false
        });

        modalElement.addEventListener('hide.bs.modal', (event) => {
            event.preventDefault();
        });

        announcementModal.show();
    }, { once: true });
})();
(() => {
    const modal=document.getElementById('productGoodsLabelModal');
    if(!modal)return;
    modal.addEventListener('show.bs.modal',(event)=>{if(window.crypto?.getRandomValues){const bytes=crypto.getRandomValues(new Uint8Array(16));modal.querySelector('[name=central_request_key]').value=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');}const button=event.relatedTarget;document.getElementById('productLabelOperationId').value=button?.dataset.productLabelOperation||'';document.getElementById('productLabelQuantity').value=button?.dataset.productLabelQuantity||'';});
    modal.querySelectorAll('[data-copy-step]').forEach((button)=>button.addEventListener('click',()=>{const input=document.getElementById('productLabelCopies');input.value=Math.max(1,Math.min(99,Number(input.value||1)+Number(button.dataset.copyStep)));}));
})();
</script>
<?php if ($articleArtwork && $articleArtworkPresentation['kind'] === 'pdf'): ?><script src="assets/artwork-pdf-viewer.js?v=<?=h((string)(@filemtime(__DIR__.'/assets/artwork-pdf-viewer.js')?:'1'))?>" defer></script><?php endif; ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
